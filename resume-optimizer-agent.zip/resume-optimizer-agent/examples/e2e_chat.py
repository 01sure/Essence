# -*- coding: utf-8 -*-
"""v2.1.0 沟通中心 + 新布局：接口与页面元素端到端验证"""
import json
import sys
import urllib.parse
import urllib.request

BASE = "http://127.0.0.1:8001"
fails = []


def check(cond, msg):
    print(("PASS  " if cond else "FAIL  ") + msg)
    if not cond:
        fails.append(msg)


def get(url):
    with urllib.request.urlopen(BASE + url, timeout=15) as r:
        return r.status, r.read().decode("utf-8", "replace")


def post(url, payload):
    req = urllib.request.Request(BASE + url, data=json.dumps(payload).encode(),
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return r.status, json.loads(r.read().decode())


JD = open("examples/jd.txt", encoding="utf-8").read()
RESUME = open("examples/resume.txt", encoding="utf-8").read()

# ---------- 1. 页面元素（新布局） ----------
_, html = get("/")
for cls, label in [("sidebar", "侧边主导航栏"), ("topbar", "顶部辅助导航栏"),
                   ("side-nav", "侧边导航菜单"), ("tb-actions", "顶栏操作区")]:
    check(f'class="{cls}"' in html, f"包含 {label}")

for eid in ["tbTitle", "inputToggle", "inputPanel", "page-chat",
            "helloBtn", "replyBtn", "followBtn", "diagBtn",
            "sceneGrid", "hrMessage", "helloOut", "replyOut", "followOut", "diagOut"]:
    check(f'id="{eid}"' in html, f"页面元素 #{eid}")

# 6 个主导航项
for p in ["dashboard", "optimize", "chat", "interview", "kb", "admin"]:
    check(f'data-page="{p}"' in html, f"侧边导航项 {p}")
check("switchChatTab" in html, "沟通中心子页切换函数存在")
check('data-ctab="hello"' in html and 'data-ctab="diag"' in html, "沟通中心 4 个子页签")

# ---------- 2. 沟通接口 ----------
st, hello = post("/api/chat/hello", {"jd": JD, "resume": RESUME})
check(st == 200, "POST /api/chat/hello 可用")
n = len(hello.get("scripts", []))
check(n == 5, f"打招呼语 5 种风格（实际 {n}）")
check(any("热情" in s["style"] or "示好" in s["style"] for s in hello["scripts"]), "含「热情示好（舔狗式）」风格")
check(len(hello.get("hr_insight", "")) > 20, "含 HR 视角洞察")
check(len(hello.get("avoid", [])) >= 3, "含避雷清单")
for s in hello["scripts"]:
    check(20 <= s["chars"] <= 200, f"话术长度合理：{s['style']} {s['chars']} 字")

for scene in ["ask_salary", "invite_interview", "reject", "doubt_match"]:
    st, r = post("/api/chat/reply", {"jd": JD, "resume": RESUME, "scenario": scene})
    ok = st == 200 and len(r.get("scripts", [])) == 3 and len(r.get("hr_intent", "")) > 10
    check(ok, f"POST /api/chat/reply 场景 {scene}")

for rnd in (1, 2, 3):
    st, f = post("/api/chat/followup", {"jd": JD, "resume": RESUME, "round_no": rnd})
    ok = st == 200 and len(f.get("scripts", [])) >= 2 and f.get("timing")
    check(ok, f"POST /api/chat/followup 第 {rnd} 轮")

st, diag = post("/api/chat/diagnose", {"jd": JD, "resume": RESUME})
check(st == 200, "POST /api/chat/diagnose 可用")
check(0 <= diag.get("score", -1) <= 100, f"匹配分合法（{diag.get('score')}）")
check(len(diag.get("plan_30d", [])) >= 3, "含 30 天提升计划")
check(len(diag.get("hr_verdict", "")) > 10, "含 HR 判定")

# ---------- 3. 话术历史 CRUD ----------
st, saved = post("/api/chat/save", {"kind": "hello", "scene": "打招呼", "style": "简洁专业版",
                                    "content": "e2e 测试话术内容", "role": "测试岗"})
check(st == 200 and saved.get("id"), "POST /api/chat/save 可用")
sid = saved["id"]
st, lst = get("/api/chat/scripts")
check(st == 200 and any(x["id"] == sid for x in json.loads(lst)), "GET /api/chat/scripts 可用")

# 清理
req = urllib.request.Request(BASE + f"/api/chat/scripts/{sid}", method="DELETE")
with urllib.request.urlopen(req, timeout=10) as r:
    check(r.status == 200, "DELETE /api/chat/scripts/{id} 可用")

print()
if fails:
    print(f"共 {len(fails)} 项失败")
    for f in fails:
        print("  -", f)
    sys.exit(1)
print("沟通中心端到端检查全部通过 ✔")
