# -*- coding: utf-8 -*-
"""v2.0.0 一站式求职系统：页面元素 + 核心 API 端到端验证脚本"""
import sys
import json
import urllib.request

BASE = "http://127.0.0.1:8001"
fails = []

def check(cond, msg):
    print(("PASS  " if cond else "FAIL  ") + msg)
    if not cond:
        fails.append(msg)

def get(url):
    with urllib.request.urlopen(BASE + url, timeout=10) as r:
        return r.status, r.read().decode("utf-8", "replace")

def post(url, payload):
    req = urllib.request.Request(BASE + url, data=json.dumps(payload).encode(),
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return r.status, json.loads(r.read().decode())

# ---------- 1. 页面元素检查 ----------
_, html = get("/")
REQ_IDS = [
    # 全局输入区
    "jdInput", "resumeInput", "runBtn", "greetBtn", "ivBtn", "askBtn",
    "jdPasteImgs", "resumePasteImgs", "fileInput",
    # 6 个页面容器（v2.2.0：新增 review 复盘 + insight 数据洞察）
    "page-dashboard", "page-optimize", "page-chat", "page-interview",
    "page-kb", "page-admin", "page-review", "page-insight",
    # 新布局：侧边主导航 + 顶部辅助栏
    "tbTitle", "inputToggle", "inputPanel", "fab",
    # 沟通中心
    "helloBtn", "replyBtn", "followBtn", "diagBtn", "sceneGrid",
    # 面试准备页
    "ivWrap", "ivEmpty", "ivStats",
    # 知识库页（v2.3.0：智能喂数据整理入库）
    "kbDocs", "kbQuestion", "kbAnswer", "kbCount", "kbRaw", "kbPasteImgs", "kbPreview", "kbIngestBtn",
    # 后台管理
    "admin-jobs", "admin-resumes", "admin-greetings", "admin-interviews", "admin-chats",
    "statGrid", "recentJobs",
    # 面试复盘 + 数据洞察（v2.2.0）
    "rvRaw", "rvCompany", "rvPosition", "rvBtn",
    "itab-defects", "itab-projects", "itab-compete", "itab-parses",
    "defectsOut", "competeOut", "parsesOut",
    # 记录中心（v2.4.0 默认主页）
    "page-record", "recRaw", "recWall", "recBtn", "recFileInput", "recFilters",
    # 智能投递（v2.5.0 新增板块）
    "page-delivery", "dvProfile", "dvJobs", "dvPlats", "dvStartBtn", "dvLog", "dvStrategy", "dvApproveJobs",
    # 结果面板
    "panel-analysis", "panel-optimized", "panel-diff", "panel-trace",
]
missing = [i for i in REQ_IDS if f'id="{i}"' not in html]
check(len(missing) == 0, f"关键元素齐全（缺失: {missing or '无'}）")

NAV_PAGES = ["delivery", "record", "dashboard", "optimize", "chat", "interview", "review", "insight", "kb", "admin"]
nav_ok = all(f'data-page="{p}"' in html for p in NAV_PAGES)
check(nav_ok, "侧边主导航 10 页齐全（含智能投递 + 记录中心）")
check('class="sidebar"' in html and 'class="topbar"' in html, "侧边主导航 + 顶部辅助栏布局")

for feat, kw in [("Ctrl+V 粘贴图片", "paste"), ("上传识别", "extract"),
                 ("localStorage 持久化", "localStorage"), ("一键复制", "clipboard")]:
    check(kw in html, f"前端包含「{feat}」能力")

# ---------- 2. 核心 API 冒烟 ----------
_, health = get("/api/health")
h = json.loads(health)
check(h.get("version") == "2.5.0", f"版本 2.5.0（实际 {h.get('version')}）")
check(len(h.get("modules", [])) == 10, f"10 个功能模块（实际 {len(h.get('modules', []))}）")

# 面试准备（规则模式）
jd = "招聘AI应用工程师，要求熟悉 Python、FastAPI、RAG、LangChain、向量数据库，有 LLM 部署经验"
resume = ("XX同学，软件技术专科应届生。熟悉 Python 与 FastAPI，掌握 Flask。"
          "实习经历：360 大模型部署，负责 Qwen 模型 Docker 化部署与推理优化；"
          "中诺测试负责接口测试；智盾一体化安全防御平台驻场项目负责后端开发。")
st, iv = post("/api/interview/prepare", {"jd": jd, "resume": resume})
check(st == 200, "POST /api/interview/prepare 可用")
n = len(iv.get("questions", [])) if isinstance(iv, dict) else 0
check(n >= 10, f"面试题目生成 >= 10 道（实际 {n}）")

# 知识库问答
def post_form(url, fields):
    data = urllib.parse.urlencode(fields).encode()
    req = urllib.request.Request(BASE + url, data=data,
                                 headers={"Content-Type": "application/x-www-form-urlencoded"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return r.status, json.loads(r.read().decode())

st, kb_add = post_form("/api/kb/add", {"title": "e2e测试文档", "content": "本项目采用 FastAPI 构建后端，使用 RAG 检索增强生成提升回答准确性，向量数据库存储文档片段。"})
check(st == 200, "POST /api/kb/add 可用")
st, ask = post("/api/kb/ask", {"question": "后端用什么框架？"})
ans = ask.get("answer", "") if isinstance(ask, dict) else ""
check(st == 200 and len(ans) > 0, f"知识库问答有返回（{len(ans)} 字）")
check("FastAPI" in ans, "知识库回答命中 FastAPI 片段")

# 上传识别（multipart）—— 回归项：/api/extract 路由曾意外丢失导致 404
def post_file(url, path):
    boundary = "----e2eboundary20260909"
    with open(path, "rb") as f:
        data = f.read()
    head = (f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="{path}"\r\n'
            "Content-Type: application/octet-stream\r\n\r\n").encode()
    body = head + data + f"\r\n--{boundary}--\r\n".encode()
    req = urllib.request.Request(BASE + url, data=body,
                                 headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return r.status, json.loads(r.read().decode())

st, ex = post_file("/api/extract", "examples/resume.txt")
check(st == 200 and ex.get("chars", 0) > 10, f"POST /api/extract 可用（txt 识别 {ex.get('chars')} 字）")

# 后台管理 dashboard
st, dash = get("/api/dashboard")
d = json.loads(dash)
check(st == 200, "GET /api/dashboard 可用")
check("jobs_total" in d and "resumes" in d and "interviews" in d and "kb_docs" in d,
      "dashboard 统计字段齐全")

print()
if fails:
    print(f"共 {len(fails)} 项失败")
    for f in fails:
        print("  -", f)
    sys.exit(1)
print("全部端到端检查通过 ✔")
