"""生成文档识别模式的测试样本：图片(JPG)/Word/PDF/Txt。可重复运行。"""
from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

BASE = Path(__file__).resolve().parent

JD_TEXT = """AI 应用开发工程师（应届/初级）

岗位职责：
1. 负责基于大模型（LLM）的 AI 应用开发，如知识库问答、智能客服等场景；
2. 参与 RAG 检索增强方案的落地，包括文档解析、向量化、检索链路调优；
3. 完成 Prompt 工程优化与效果评测。

任职要求：
1. 熟练掌握 Python，熟悉 FastAPI；
2. 熟悉 LangChain 与 Agent 开发；
3. 熟悉向量数据库与 Embedding；
4. 了解 Docker 部署。"""

RESUME_TEXT = """XX同学
电话：138****0000 | 求职意向：AI 应用开发工程师

专业技能
- Python、Java、SQL
- FastAPI、Spring Boot
- Docker、Linux、Git
- 大模型部署、模型推理、KV-Cache

实习经历
360 公司 · 大模型部署实习生（2025.03 - 2025.06）
- 负责 Qwen 大模型的 Docker 容器化部署与推理服务搭建
- 通过 KV-Cache 优化推理性能，降低显存占用"""


def make_jpg(path: Path) -> None:
    """白底黑字图片模拟招聘 JD 截图。"""
    font_path = "C:/Windows/Fonts/msyh.ttc"
    try:
        font = ImageFont.truetype(font_path, 26)
    except OSError:
        font = ImageFont.truetype("C:/Windows/Fonts/simhei.ttf", 26)
    lines = JD_TEXT.splitlines()
    line_h = 40
    w, h = 880, len(lines) * line_h + 60
    img = Image.new("RGB", (w, h), "white")
    d = ImageDraw.Draw(img)
    y = 30
    for ln in lines:
        d.text((40, y), ln, fill="black", font=font)
        y += line_h
    img.save(path, "JPEG", quality=92)
    print("jpg ->", path)


def make_docx(path: Path) -> None:
    import docx
    from docx.shared import Pt

    d = docx.Document()
    d.add_heading("XX同学", level=0)
    d.add_paragraph("求职意向：AI 应用开发工程师")
    d.add_heading("专业技能", level=1)
    for item in ["Python、Java、SQL", "FastAPI、Spring Boot", "Docker、Linux、Git", "大模型部署、模型推理、KV-Cache"]:
        d.add_paragraph(item, style="List Bullet")
    d.add_heading("实习经历", level=1)
    d.add_paragraph("360 公司 · 大模型部署实习生（2025.03 - 2025.06）")
    d.add_paragraph("负责 Qwen 大模型的 Docker 容器化部署与推理服务搭建", style="List Bullet")
    d.add_heading("技能一览", level=1)
    table = d.add_table(rows=2, cols=2)
    table.cell(0, 0).text = "方向"
    table.cell(0, 1).text = "掌握程度"
    table.cell(1, 0).text = "大模型部署"
    table.cell(1, 1).text = "熟练"
    d.save(str(path))
    print("docx ->", path)


def make_pdf(path: Path) -> None:
    """手写最小 PDF（ASCII 文本层），用于验证 pypdf 提取链路。"""
    content = "Resume test: Python FastAPI Docker RAG Agent"
    body = f"BT /F1 12 Tf 72 720 Td ({content}) Tj ET"
    pdf = (
        "%PDF-1.4\n"
        "1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n"
        "2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n"
        "3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 612 792]/Contents 4 0 R"
        "/Resources<</Font<</F1 5 0 R>>>>>>endobj\n"
        f"4 0 obj<</Length {len(body)}>>stream\n{body}\nendstream endobj\n"
        "5 0 obj<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>endobj\n"
        "trailer<</Root 1 0 R/Size 6>>\n"
        "startxref\n0\n"
        "%%EOF"
    )
    path.write_text(pdf, encoding="latin-1")
    print("pdf ->", path)


if __name__ == "__main__":
    make_jpg(BASE / "test_jd.jpg")
    make_docx(BASE / "test_resume.docx")
    make_pdf(BASE / "test_resume.pdf")
    (BASE / "test_jd.txt").write_text(JD_TEXT, encoding="utf-8")
    print("txt ->", BASE / "test_jd.txt")
    print("DONE")
