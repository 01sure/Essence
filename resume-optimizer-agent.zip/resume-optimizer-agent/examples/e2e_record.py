# -*- coding: utf-8 -*-
"""v2.4.0 记录中心：随手记求职/面试 → 自动提取归纳 → 入库 → 列表/筛选/删除 端到端验证"""
import sys
import os
import json
import urllib.request
import urllib.parse

BASE = "http://127.0.0.1:8001"
fails = []

def check(cond, msg):
    print(("PASS  " if cond else "FAIL  ") + msg)
    if not cond:
        fails.append(msg)

def get(url):
    with urllib.request.urlopen(BASE + url, timeout=10) as r:
        return r.status, json.loads(r.read().decode())

def post_multipart(url, fields=None, files=None):
    """fields: dict[str,str]; files: list[(fieldname, filename, bytes)]"""
    boundary = "----e2erecord20260909"
    body = b""
    for k, v in (fields or {}).items():
        body += f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n'.encode()
        body += v.encode() + b"\r\n"
    for fname, fn, data in (files or []):
        body += (f'--{boundary}\r\nContent-Disposition: form-data; name="{fname}"; '
                  f'filename="{fn}"\r\nContent-Type: application/octet-stream\r\n\r\n').encode()
        body += data + b"\r\n"
    body += f"--{boundary}--\r\n".encode()
    req = urllib.request.Request(BASE + url, data=body,
                                 headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return r.status, json.loads(r.read().decode())

def delete(url):
    req = urllib.request.Request(BASE + url, method="DELETE")
    with urllib.request.urlopen(req, timeout=10) as r:
        return r.status, json.loads(r.read().decode())

# ---------- 0. 版本 ----------
_, h = get("/api/health")
check(h.get("version") == "2.4.0", f"版本 2.4.0（实际 {h.get('version')}）")
check("记录中心" in h.get("modules", []), "功能模块含「记录中心」")

# ---------- 1. 纯文本记一笔（求职记录，触发已投递识别） ----------
raw_job = "今天投递了腾讯的AI应用工程师岗位，要求熟悉Python、FastAPI、LangChain、RAG。hr说一周内给回复。"
st, r1 = post_multipart("/api/record/add", {"raw": raw_job, "kind": "求职记录"})
check(st == 200, "POST /api/record/add 可用（纯文本）")
check(r1.get("id", 0) > 0, f"返回落库 id（{r1.get('id')}）")
check(r1.get("kind") == "求职记录", f"类型识别=求职记录（实际 {r1.get('kind')}）")
check(r1.get("status") == "已投递", f"进度识别=已投递（实际 {r1.get('status')}）")
check(r1.get("position") == "AI应用工程师", f"岗位识别=AI应用工程师（实际 {r1.get('position')!r}）")
check(len(r1.get("points", [])) >= 1, f"归纳要点 >=1 条（{len(r1.get('points', []))}）")

# ---------- 2. 面试记录（触发面试中 + 面试记录类型） ----------
raw_iv = "字节跳动二面复盘：面试官问了RAG的检索召回优化和LangChain Agent的异常处理，答得一般，需要补流式处理。"
st, r2 = post_multipart("/api/record/add", {"raw": raw_iv, "kind": "面试记录"})
check(st == 200, "POST /api/record/add 可用（面试记录）")
check(r2.get("kind") == "面试记录", f"类型识别=面试记录（实际 {r2.get('kind')}）")
check(r2.get("status") == "面试中", f"进度识别=面试中（实际 {r2.get('status')}）")

# ---------- 3. 文件上传识别（复用 txt，走 doc_parse 路径） ----------
txt_path = "examples/resume.txt"
if os.path.exists(txt_path):
    with open(txt_path, "rb") as f:
        data = f.read()
    st, r3 = post_multipart("/api/record/add",
                            {"raw": "", "kind": ""},
                            files=[("files", "resume.txt", data)])
    check(st == 200, "POST /api/record/add 可用（上传 txt 文件识别）")
    check(r3.get("chars", 0) > 10, f"文件识别后原文字数 >10（{r3.get('chars')}）")
    check(r3.get("method") in ("plain_text", "ocr", "pdf_text", "docx_text"), f"识别方式={r3.get('method')}")
else:
    check(False, "examples/resume.txt 不存在，跳过文件上传用例")

# ---------- 4. 列表 + 筛选 ----------
st, items = get("/api/records")
check(st == 200, "GET /api/records 可用")
check(len(items) >= 3, f"列表至少 3 条（实际 {len(items)}）")
all_have_points = all(isinstance(it.get("points"), list) for it in items)
check(all_have_points, "每条记录的 points 均为数组（JSON 已反序列化）")

st, only_iv = get("/api/records?kind=" + urllib.parse.quote("面试记录"))
check(st == 200, "GET /api/records?kind=面试记录 可用")
check(all(it.get("kind") == "面试记录" for it in only_iv), "筛选仅返回面试记录")

# ---------- 5. 删除 ----------
del_id = r1.get("id")
st, _ = delete(f"/api/records/{del_id}")
check(st == 200, f"DELETE /api/records/{del_id} 可用")
st, after = get("/api/records")
ids = [it["id"] for it in after]
check(del_id not in ids, "删除后该记录不再出现在列表")

print()
if fails:
    print(f"共 {len(fails)} 项失败")
    for f in fails:
        print("  -", f)
    sys.exit(1)
print("记录中心端到端检查全部通过 ✔")
