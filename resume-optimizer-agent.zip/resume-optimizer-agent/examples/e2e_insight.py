# -*- coding: utf-8 -*-
"""v2.2.0 数据洞察 / 面试复盘 / 项目库 / 解析存档：接口与页面元素端到端验证"""
import json
import sys
import urllib.parse
import urllib.request

BASE = "http://127.0.0.1:8001"
fails = []


def check(cond, msg):
    print(("PASS  " if cond else "FAIL  ") + msg)
    if not cond:
        fails.append(msg)


def get(url):
    with urllib.request.urlopen(BASE + url, timeout=15) as r:
        return r.status, r.read().decode("utf-8", "replace")


def post(url, payload):
    req = urllib.request.Request(BASE + url, data=json.dumps(payload).encode(),
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return r.status, json.loads(r.read().decode())


def post_form(url, fields):
    data = urllib.parse.urlencode(fields).encode()
    req = urllib.request.Request(BASE + url, data=data,
                                 headers={"Content-Type": "application/x-www-form-urlencoded"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return r.status, json.loads(r.read().decode())


def delete(url):
    req = urllib.request.Request(BASE + url, method="DELETE")
    with urllib.request.urlopen(req, timeout=10) as r:
        return r.status, r.read().decode("utf-8", "replace")


JD = open("examples/jd.txt", encoding="utf-8").read()
RESUME = open("examples/resume.txt", encoding="utf-8").read()

# ---------- 1. 页面元素 ----------
_, html = get("/")
for eid in ["page-review", "page-insight", "itab-defects", "itab-projects", "itab-compete", "itab-parses",
            "rvRaw", "rvCompany", "rvPosition", "rvBtn", "rvHistory", "rvStatus",
            "recJd", "defectsOut", "competeOut", "parsesOut", "loadDefects", "loadCompetitiveness",
            "loadParseRuns", "runReviewAnalyze", "saveReviewToKb"]:
    check(f'id="{eid}"' in html or eid + "(" in html, f"页面元素 #{eid}")
for p in ["review", "insight"]:
    check(f'data-page="{p}"' in html, f"侧边导航 {p}")

# ---------- 2. 解析存档：optimize 自动落库 ----------
st, opt = post("/api/optimize", {"jd": JD, "resume": RESUME})
check(st == 200, "POST /api/optimize 可用")
check(opt.get("meta", {}).get("parse_run_id", 0) > 0, "optimize 自动写入 parse_run_id")

st, runs = get("/api/parse/runs")
runs = json.loads(runs)
check(st == 200 and len(runs) >= 1, f"GET /api/parse/runs 返回 {len(runs)} 条")
check(runs[0].get("score") == opt["analysis"]["overall_score"], "解析记录与本次分数一致")
check(json.loads(runs[0].get("missing") or "[]"), "解析记录含 missing 详情")

# ---------- 3. 缺陷追踪 ----------
st, d = post("/api/insight/defects", {"resume": RESUME})
check(st == 200, "POST /api/insight/defects 可用")
check(d.get("total_runs", 0) >= 1, f"总解析轮次 {d.get('total_runs')}")
check(len(d.get("defects", [])) > 0, f"发现 {len(d.get('defects', []))} 项缺陷")
check(d.get("top_action"), "含 top_action")

# ---------- 4. 项目库 CRUD + 项目推荐 ----------
# 先清掉可能存在的 e2e 项目
st, projs = get("/api/projects")
projs = json.loads(projs)
for p in projs:
    if p.get("name", "").startswith("e2e-"):
        delete(f"/api/projects/{p['id']}")

st, newp = post("/api/projects", {
    "name": "e2e-示例RAG项目", "role": "独立开发",
    "tags": "RAG,LangChain,FastAPI,Python", "summary": "知识库问答",
    "bullets": ["文档解析与分块", "FastAPI 对外服务"], "starred": True
})
check(st == 200 and newp.get("id"), "POST /api/projects 创建项目成功")
pid = newp["id"]

# PUT 用 @app.put，必须显式 method=PUT
req = urllib.request.Request(BASE + f"/api/projects/{pid}", method="PUT",
                             data=json.dumps({"name": "e2e-示例RAG项目v2"}).encode(),
                             headers={"Content-Type": "application/json"})
with urllib.request.urlopen(req, timeout=10) as r:
    check(r.status == 200, "PUT /api/projects/{id} 可用")

st, rec = post("/api/insight/projects/recommend", {"jd": JD})
check(st == 200, "POST /api/insight/projects/recommend 可用")
check(len(rec.get("recommendations", [])) >= 1, f"推荐 {len(rec.get('recommendations', []))} 个项目")
check(any(p.get("name", "").startswith("e2e-") for p in rec.get("recommendations", [])),
      "我们创建的项目出现在推荐里")
check(len(rec.get("new_project_ideas", [])) >= 1, f"建议补做 {len(rec.get('new_project_ideas', []))} 个项目")

# ---------- 5. 竞争力评估 ----------
st, c = get("/api/insight/competitiveness")
c = json.loads(c)
check(st == 200, "GET /api/insight/competitiveness 可用")
check(0 <= c.get("score", -1) <= 100, f"竞争力分 {c.get('score')}")
check(c.get("level"), "含等级")
check(isinstance(c.get("history"), list), "含历史分数")

# ---------- 6. 面试复盘分析 ----------
review_raw = (
    "面试官问：你对 RAG 的整体链路了解吗？我答了文档解析和向量检索。但是问 Rerank 重排序时没答上来，不太清楚具体怎么做。"
    "又问 vLLM 推理优化，我说没用过，忘了。"
)
st, rv = post("/api/review/analyze", {"raw": review_raw, "company": "e2e-公司", "position": "AI工程师", "resume": RESUME})
check(st == 200, "POST /api/review/analyze 可用")
check(rv.get("score", 0) < 70, f"复盘评分 {rv.get('score')}（< 70，因有卡壳）")
check(len(rv.get("questions", [])) >= 1, f"识别到 {len(rv.get('questions', []))} 个问题")
check(len(rv.get("weaknesses", [])) >= 1, f"识别到 {len(rv.get('weaknesses', []))} 个弱点")
check(len(rv.get("actions", [])) >= 1, f"给出 {len(rv.get('actions', []))} 个改进项")
check(len(rv.get("resume_feedback", [])) >= 1, "含简历反哺建议")

# ---------- 7. 复盘保存与历史 ----------
st, sv = post("/api/review/save", {"review": rv, "raw": review_raw, "job_id": 0})
check(st == 200 and sv.get("id"), "POST /api/review/save 可用")
rid = sv["id"]

st, lst = get("/api/reviews")
lst = json.loads(lst)
check(any(x["id"] == rid for x in lst), f"GET /api/reviews 包含刚保存的（{rid}）")

st, _ = delete(f"/api/reviews/{rid}")
check(st == 200, "DELETE /api/reviews/{id} 可用")

# ---------- 8. 上传识别 + 复盘（multipart） ----------
def post_file(url, path, extra=None):
    boundary = "----e2eboundaryV220"
    with open(path, "rb") as f:
        data = f.read()
    parts = []
    for k, v in (extra or {}).items():
        parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode())
    parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="{path}"\r\nContent-Type: application/octet-stream\r\n\r\n'.encode())
    parts.append(data)
    parts.append(f'\r\n--{boundary}--\r\n'.encode())
    req = urllib.request.Request(BASE + url, data=b"".join(parts),
                                 headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return r.status, json.loads(r.read().decode())

st, ru = post_file("/api/review/upload", "examples/test_jd.txt",
                   {"company": "e2e-公司", "position": "AI工程师", "resume": RESUME})
check(st == 200 and ru.get("score", 0) > 0, f"POST /api/review/upload 成功（评分 {ru.get('score')}）")

# 清理项目库
delete(f"/api/projects/{pid}")

print()
if fails:
    print(f"共 {len(fails)} 项失败")
    for f in fails:
        print("  -", f)
    sys.exit(1)
print("v2.2.0 数据洞察 + 复盘 端到端全部通过 ✔")
