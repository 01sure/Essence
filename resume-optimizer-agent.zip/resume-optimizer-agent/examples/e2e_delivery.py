"""智能投递模块端到端测试（mock 模式，无需真实账号）。

覆盖：健康检查 → 简历画像 → 定向策略 → 平台会话 → 连接 → 搜索+匹配 → 审批 → 启动投递 → 日志。
运行：python examples/e2e_delivery.py  （服务需在 127.0.0.1:8001 运行）
"""
from __future__ import annotations

import json
import sys
import time
import urllib.parse
import urllib.request
import urllib.error

BASE = "http://127.0.0.1:8001"
PROFILE = (
    "XX同学，软件技术专科，现转向 AI 应用工程师方向。熟悉 Python、FastAPI、LangChain、RAG 检索增强，"
    "做过企业级知识库问答系统（向量库 + n-gram），用 Docker 部署过 Qwen 等开源大模型，有 360 大模型交付与"
    "军工客户驻场经验。目标岗位：AI 应用开发工程师 / 大模型应用工程师，薪资 8-16K，base 深圳。"
)

passed = 0
failed = 0


def check(name: str, cond: bool, extra: str = ""):
    global passed, failed
    if cond:
        passed += 1
        print(f"  ✓ {name}")
    else:
        failed += 1
        print(f"  ✗ {name}  {extra}")


def api(method: str, path: str, data=None, json_body=None, raw=False):
    url = BASE + path
    headers = {}
    body = None
    if json_body is not None:
        body = json.dumps(json_body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    elif data is not None:
        body = urllib.parse.urlencode(data).encode("utf-8")
        headers["Content-Type"] = "application/x-www-form-urlencoded"
    req = urllib.request.Request(url, data=body, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            txt = r.read().decode("utf-8")
            return r.status, (txt if raw else json.loads(txt))
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8")


def main():
    print("=== 智能投递 e2e（mock）===")

    # 1) 健康检查
    st, h = api("GET", "/api/health")
    check("health 200", st == 200)
    check("version=2.5.0", h.get("version") == "2.5.0", h.get("version"))
    check("modules 含 智能投递", "智能投递" in h.get("modules", []))

    # 2) 简历画像
    st, _ = api("POST", "/api/delivery/profile", json_body={"content": PROFILE})
    check("保存简历画像 200", st == 200)
    st, p = api("GET", "/api/delivery/profile")
    check("读取简历画像 chars>20", p.get("chars", 0) > 20, str(p.get("chars")))

    # 3) 定向策略
    st, s = api("GET", "/api/delivery/strategy")
    check("定向策略 200", st == 200, str(st))
    check("策略含 platforms", isinstance(s.get("platforms"), list) and len(s["platforms"]) > 0)

    # 4) 平台会话
    st, sess = api("GET", "/api/delivery/sessions")
    check("会话含 3 平台", len(sess) == 3, str(len(sess)))
    check("含 boss 会话", any(x["platform"] == "boss" for x in sess))

    # 5) 连接（mock）
    st, c = api("POST", "/api/delivery/connect", data={"platform": "boss"})
    check("连接 boss mock ok", st == 200 and c.get("status") == "ready", str(c))
    st, sess = api("GET", "/api/delivery/sessions")
    boss = next(x for x in sess if x["platform"] == "boss")
    check("boss 会话 ready", boss["status"] == "ready")

    # 6) 搜索 + 匹配
    st, r = api("POST", "/api/delivery/search",
                data={"platform": "boss", "keyword": "AI 应用开发工程师", "city": "深圳"})
    check("搜索 200", st == 200, str(st))
    check("返回岗位 >0", r.get("count", 0) > 0, str(r.get("count")))
    check("匹配模式有效", r.get("mode") in ("LLM", "规则引擎"), str(r.get("mode")))
    jobs = r.get("jobs", [])
    check("岗位带 match_score", all(isinstance(j.get("match_score"), int) for j in jobs))
    check("岗位带 id", all(j.get("id") for j in jobs))

    # 7) 岗位落库（本次搜索返回的岗位应均已持久化；允许历史运行遗留行）
    st, jl = api("GET", "/api/delivery/jobs", data={"platform": "boss"})
    jl_ids = {x["id"] for x in jl}
    check("搜索岗位均已落库", len(jl) >= len(jobs) and all(j["id"] in jl_ids for j in jobs),
          f"list={len(jl)} searched={len(jobs)}")

    # 8) 自动批准（阈值 60）
    st, a = api("POST", "/api/delivery/approve", json_body={"auto_threshold": 60})
    check("自动批准 ok", st == 200, str(st))
    check("批准数量 >0", a.get("approved", 0) > 0, str(a.get("approved")))
    st, appr = api("GET", "/api/delivery/jobs", data={"platform": "boss", "status": "approved"})
    check("approved 岗位落库", len(appr) > 0, str(len(appr)))

    # 9) 启动投递（mock）
    st, _ = api("POST", "/api/delivery/start", data={"platform": "boss"})
    check("启动投递 200", st == 200, str(st))
    # 轮询直到完成或超时
    done = False
    for _ in range(40):
        st, stt = api("GET", "/api/delivery/status")
        if not stt.get("running"):
            done = True
            break
        time.sleep(2)
    check("投递活动结束（running=false）", done)
    st, appr = api("GET", "/api/delivery/jobs", data={"platform": "boss", "status": "applied"})
    check("有岗位状态=applied", len(appr) > 0, str(len(appr)))

    # 10) 日志
    st, logs = api("GET", "/api/delivery/logs?limit=100")
    check("日志 200", st == 200)
    check("日志含 apply", any(l.get("action") == "apply" for l in logs), str(len(logs)))
    check("日志含防拦截延时(wait)", any(l.get("action") == "wait" for l in logs))

    # 11) 停止（幂等）
    st, _ = api("POST", "/api/delivery/stop")
    check("停止 200", st == 200)

    print(f"\n=== 结果：通过 {passed} / 失败 {failed} ===")
    if failed:
        print("存在失败项，请检查服务日志")
        sys.exit(1)
    print("✅ 智能投递 mock 全流程通过")


if __name__ == "__main__":
    main()
