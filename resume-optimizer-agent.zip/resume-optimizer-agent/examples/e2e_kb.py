# -*- coding: utf-8 -*-
"""v2.3.0 知识库智能整理（喂数据 → 识别 + 归纳）端到端验证脚本。

覆盖：
- POST /api/kb/ingest 纯文本（paste）
- POST /api/kb/ingest 上传 txt 文件
- POST /api/kb/ingest 上传 Excel（xlsx）
- POST /api/kb/ingest 上传 PPT（pptx）
- POST /api/kb/ingest 上传图片（OCR）
- POST /api/kb/ingest 多文件（txt + 图片）混合
- 用整理结果入库 /api/kb/add → 列表 /api/kb/list → 问答 /api/kb/ask
- 删除 /api/kb/{id}（回归：kb_delete 曾误用未导入符号导致 NameError）
"""
import json
import sys
import tempfile
import uuid
import urllib.parse
import urllib.request
from pathlib import Path

BASE = "http://127.0.0.1:8001"
fails = []


def check(cond, msg):
    print(("PASS  " if cond else "FAIL  ") + msg)
    if not cond:
        fails.append(msg)


def _get(url):
    with urllib.request.urlopen(BASE + url, timeout=20) as r:
        return r.status, json.loads(r.read().decode())


def _post_json(url, payload):
    req = urllib.request.Request(BASE + url, data=json.dumps(payload).encode(),
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return r.status, json.loads(r.read().decode())


def _post_form(url, fields):
    data = urllib.parse.urlencode(fields).encode()
    req = urllib.request.Request(BASE + url, data=data,
                                 headers={"Content-Type": "application/x-www-form-urlencoded"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return r.status, json.loads(r.read().decode())


def _post_multipart(url, fields, files):
    """fields: [(name, value)]；files: [(name, filename, bytes)]（同名可多次以构成列表）。"""
    boundary = "----e2ekb" + uuid.uuid4().hex
    buf = b""
    for name, value in fields:
        buf += (f"--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\"\r\n\r\n"
                f"{value}\r\n").encode("utf-8")
    for name, filename, data in files:
        buf += (f"--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\"; "
                f"filename=\"{filename}\"\r\nContent-Type: application/octet-stream\r\n\r\n").encode("utf-8")
        buf += data + b"\r\n"
    buf += f"--{boundary}--\r\n".encode("utf-8")
    req = urllib.request.Request(BASE + url, data=buf,
                                 headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
    with urllib.request.urlopen(req, timeout=120) as r:
        return r.status, json.loads(r.read().decode())


def _delete(url):
    req = urllib.request.Request(BASE + url, method="DELETE")
    with urllib.request.urlopen(req, timeout=20) as r:
        return r.status, json.loads(r.read().decode())


raw_text = ("XX 科技有限公司，专注企业级知识库与智能客服。技术栈：Python、FastAPI、LangChain、RAG、"
            "向量数据库（Milvus）。岗位要求：熟悉 RAG 检索增强、Prompt 工程、Docker 部署，"
            "有 LLM 应用落地经验优先。")

# ---------- 1. 纯文本喂入（paste） ----------
st, d = _post_multipart("/api/kb/ingest", [("raw", raw_text)], [])
check(st == 200, f"ingest 纯文本可用（status {st}）")
check(isinstance(d, dict) and d.get("chars", 0) > 50, f"识别字数 {d.get('chars')}")
check(d.get("method") == "paste", f"来源方式 paste（实际 {d.get('method')}）")
check(d.get("title", "").strip() != "", "自动生成标题非空")
check(d.get("summary", "").strip() != "", "自动生成摘要非空")
check(isinstance(d.get("points", []), list) and len(d.get("points", [])) >= 1, "自动归纳要点 ≥1")
check("## 原文" in d.get("content", ""), "content 含结构化 Markdown（摘要/要点/原文）")
check("FastAPI" in d.get("tags", ""), "自动识别技术标签含 FastAPI")

# ---------- 2. 上传 txt 文件 ----------
with open("examples/resume.txt", "rb") as f:
    txt_data = f.read()
st, d = _post_multipart("/api/kb/ingest", [], [("files", "resume.txt", txt_data)])
check(st == 200, f"ingest 上传 txt 可用（status {st}）")
check(d.get("method") == "plain_text", f"txt 识别方式 plain_text（实际 {d.get('method')}）")
check(d.get("source") == "resume.txt", f"source 为文件名（实际 {d.get('source')}）")

# ---------- 2.5 上传 Excel（xlsx） ----------
def _make_xlsx():
    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "岗位要求"
    ws.append(["技能", "要求"])
    ws.append(["Python", "熟练"])
    ws.append(["FastAPI", "掌握"])
    ws.append(["RAG", "有项目经验"])
    p = Path(tempfile.gettempdir()) / "e2e_kb.xlsx"
    wb.save(str(p))
    return p.read_bytes()

xlsx_data = _make_xlsx()
st, d = _post_multipart("/api/kb/ingest", [], [("files", "岗位要求.xlsx", xlsx_data)])
check(st == 200, f"ingest 上传 Excel 可用（status {st}）")
check(d.get("method") == "xlsx_text", f"xlsx 识别方式 xlsx_text（实际 {d.get('method')}）")
check("FastAPI" in d.get("raw_text", ""), "Excel 解析出单元格内容（含 FastAPI）")

# ---------- 2.6 上传 PPT（pptx） ----------
def _make_pptx():
    from pptx import Presentation
    prs = Presentation()
    s = prs.slides.add_slide(prs.slide_layouts[1])
    s.shapes.title.text = "公司介绍"
    s.placeholders[1].text = "专注 AI 知识库与 RAG 检索增强"
    p = Path(tempfile.gettempdir()) / "e2e_kb.pptx"
    prs.save(str(p))
    return p.read_bytes()

pptx_data = _make_pptx()
st, d = _post_multipart("/api/kb/ingest", [], [("files", "公司介绍.pptx", pptx_data)])
check(st == 200, f"ingest 上传 PPT 可用（status {st}）")
check(d.get("method") == "pptx_text", f"pptx 识别方式 pptx_text（实际 {d.get('method')}）")
check("RAG" in d.get("raw_text", ""), "PPT 解析出文本（含 RAG）")

# ---------- 3. 上传图片（OCR） ----------
with open("examples/test_jd.jpg", "rb") as f:
    img_data = f.read()
st, d = _post_multipart("/api/kb/ingest", [], [("files", "test_jd.jpg", img_data)])
check(st == 200, f"ingest 上传图片可用（status {st}）")
check(d.get("method") == "ocr", f"图片识别方式 ocr（实际 {d.get('method')}）")
check(d.get("chars", 0) >= 10, f"OCR 识别出 {d.get('chars')} 字")

# ---------- 4. 多文件混合（txt + jd.txt） ----------
with open("examples/jd.txt", "rb") as f:
    jd_data = f.read()
st, d = _post_multipart("/api/kb/ingest", [],
                        [("files", "resume.txt", txt_data), ("files", "jd.txt", jd_data)])
check(st == 200, f"ingest 多文件混合可用（status {st}）")
check(d.get("chars", 0) > 100, f"多文件拼接识别 {d.get('chars')} 字")

# ---------- 5. 用整理结果入库 → 列表 → 问答 ----------
st, d = _post_multipart("/api/kb/ingest", [("raw", raw_text)], [])
title, tags, content = d["title"], d["tags"], d["content"]
st, saved = _post_form("/api/kb/add", [("title", title), ("content", content), ("tags", tags)])
check(st == 200 and saved.get("ok"), "整理结果可入库 /api/kb/add")
doc_id = saved.get("id", 0)

st, lst = _get("/api/kb/list")
check(st == 200 and any(x["id"] == doc_id for x in lst), "知识库列表含新入库文档")

st, ask = _post_json("/api/kb/ask", {"question": "这家公司用什么技术栈？"})
ans = ask.get("answer", "")
check(st == 200 and len(ans) > 0, f"知识库问答有返回（{len(ans)} 字）")
check(any(k in ans for k in ("FastAPI", "LangChain", "RAG")), "问答命中整理入库的内容")

# ---------- 6. 删除（回归 kb_delete） ----------
st, _ = _delete(f"/api/kb/{doc_id}")
check(st == 200, f"删除知识库文档可用（status {st}）")

print()
if fails:
    print(f"共 {len(fails)} 项失败")
    for f in fails:
        print("  -", f)
    sys.exit(1)
print("知识库智能整理端到端检查通过 ✔")
