"""规则引擎（无 LLM 时的确定性回退实现）。

包含：
- 技术关键词库（按类别分组，含别名）
- JD 解析：关键词提取 + 要求行识别 + 权重推断
- 简历解析：章节切分 + 技能命中
- 匹配分析：覆盖率打分 + 差距建议
- 改写引擎：动作动词锚定 + JD 关键词置顶 + 量化占位提示
- 打招呼语生成：基于 JD×简历交集要点 + 最强亮点句的 3 风格模板
"""
from __future__ import annotations

import re
from collections import OrderedDict

from app.schemas import (
    Change,
    GapItem,
    Greeting,
    JDParsed,
    MatchAnalysis,
    OptimizedResume,
    Requirement,
    ResumeParsed,
    ResumeSection,
)

# ---------------------------------------------------------------- 关键词库
# 类别 -> [(关键词, [别名])]，命中时用「关键词」作为归一化名称
KEYWORD_TAXONOMY: dict[str, list[tuple[str, list[str]]]] = {
    "编程语言": [
        ("Python", ["python", "py"]),
        ("Java", ["java"]),
        ("Golang", ["golang", "go语言"]),
        ("C/C++", ["c++", "c/c++"]),
        ("JavaScript", ["javascript", "js"]),
        ("TypeScript", ["typescript", "ts"]),
        ("SQL", ["sql"]),
        ("Shell", ["shell", "bash"]),
    ],
    "后端框架": [
        ("FastAPI", ["fastapi"]),
        ("Django", ["django"]),
        ("Flask", ["flask"]),
        ("Spring Boot", ["springboot", "spring boot", "spring"]),
        ("MyBatis", ["mybatis"]),
        ("LangChain", ["langchain"]),
        ("LangGraph", ["langgraph"]),
        ("RAG", ["rag", "检索增强"]),
    ],
    "AI/大模型": [
        ("大模型", ["大模型", "llm", "llms"]),
        ("Agent", ["agent", "智能体", "agentic"]),
        ("Prompt工程", ["prompt", "提示词"]),
        ("Embedding", ["embedding", "向量化"]),
        ("向量数据库", ["向量数据库", "milvus", "faiss", "chroma", "qdrant", "weaviate"]),
        ("模型微调", ["微调", "finetune", "fine-tune", "sft", "lora", "peft"]),
        ("Qwen", ["qwen", "通义千问"]),
        ("DeepSeek", ["deepseek"]),
        ("GLM", ["glm", "智谱"]),
        ("OpenAI API", ["openai"]),
        ("HuggingFace", ["huggingface", "transformers"]),
        ("推理优化", ["kv-cache", "vllm", "tensorrt", "推理加速"]),
        ("模型部署", ["模型部署", "模型推理", "推理服务"]),
    ],
    "数据/算法": [
        ("Pandas", ["pandas"]),
        ("NumPy", ["numpy"]),
        ("Scikit-learn", ["sklearn", "scikit-learn"]),
        ("PyTorch", ["pytorch", "torch"]),
        ("TensorFlow", ["tensorflow", "tf"]),
        ("数据分析", ["数据分析", "数据清洗", "可视化"]),
    ],
    "数据库/中间件": [
        ("MySQL", ["mysql"]),
        ("PostgreSQL", ["postgresql", "postgres"]),
        ("MongoDB", ["mongodb", "mongo"]),
        ("Redis", ["redis"]),
        ("Elasticsearch", ["elasticsearch", "es搜索引擎", "es 搜索引擎"]),
        ("Kafka", ["kafka"]),
        ("消息队列", ["消息队列", "rabbitmq", "rocketmq", "mq"]),
    ],
    "运维/云原生": [
        ("Docker", ["docker", "容器化"]),
        ("Kubernetes", ["kubernetes", "k8s"]),
        ("Linux", ["linux"]),
        ("Nginx", ["nginx"]),
        ("Git", ["git"]),
        ("CI/CD", ["ci/cd", "cicd", "jenkins", "github actions", "流水线"]),
        ("监控告警", ["prometheus", "grafana", "监控告警"]),
        ("云服务", ["阿里云", "腾讯云", "aws", "华为云", "云服务器"]),
    ],
    "测试/质量": [
        ("自动化测试", ["自动化测试", "pytest", "unittest", "selenium", "robotframework"]),
        ("接口测试", ["接口测试", "postman", "apifox", "jmeter"]),
        ("功能测试", ["功能测试", "黑盒测试", "用例设计", "测试用例"]),
        ("性能测试", ["性能测试", "压测", "压力测试"]),
    ],
    "前端": [
        ("Vue", ["vue"]),
        ("React", ["react"]),
        ("HTML/CSS", ["html", "css"]),
        ("小程序", ["小程序"]),
    ],
    "软技能/工程化": [
        ("需求分析", ["需求分析", "需求梳理"]),
        ("团队协作", ["团队协作", "协作", "跨部门"]),
        ("技术文档", ["技术文档", "文档编写", "wiki"]),
        ("敏捷开发", ["敏捷", "scrum", "迭代"]),
        ("客户沟通", ["客户沟通", "客户对接", "驻场", "现场实施"]),
        ("问题排查", ["问题排查", "故障排查", "debug", "定位问题"]),
    ],
}


def _norm(text: str) -> str:
    return text.lower()


def extract_keywords(text: str) -> OrderedDict[str, str]:
    """扫描文本，返回 {归一化关键词: 类别}（按出现顺序去重）。"""
    low = _norm(text)
    found: OrderedDict[str, str] = OrderedDict()
    for category, items in KEYWORD_TAXONOMY.items():
        for name, aliases in items:
            for alias in aliases:
                if alias in low:
                    found[name] = category
                    break
    return found


# ---------------------------------------------------------------- 权重推断
WEIGHT_STRONG = ("精通", "熟练", "优先", "加分", "深入", "扎实", "核心", "必须", "要求")
WEIGHT_MED = ("熟悉", "掌握")
WEIGHT_WEAK = ("了解", "认知", "具备", "有一定")


def infer_weight(context: str, default: str = "中") -> str:
    if any(w in context for w in WEIGHT_STRONG):
        return "高"
    if any(w in context for w in WEIGHT_WEAK):
        return "低"
    if any(w in context for w in WEIGHT_MED):
        return "中"
    return default


# ---------------------------------------------------------------- JD 解析
_SECTION_HEADER_RE = re.compile(
    r"^(?:#{1,4}\s*|\[)?(.*?)(?:\])?\s*$"
)
REQ_LINE_HINTS = ("要求", "熟悉", "掌握", "精通", "了解", "负责", "任职", "加分", "优先", "具备", "能够", "能独立")


def parse_jd_rule(raw: str) -> JDParsed:
    raw = (raw or "").strip()
    lines = [l.strip() for l in raw.splitlines() if l.strip()]

    # 岗位名称：含 工程师/开发/专家/专员/架构 的第一行（去公司名）
    role = ""
    for line in lines[:6]:
        if any(k in line for k in ("工程师", "开发", "专家", "专员", "架构师", "负责人", "经理")):
            role = line.split("：")[0].split(":")[0].strip()
            if len(role) > 24:
                role = role[:24]
            break

    # 关键词 + 权重
    seen: dict[str, Requirement] = {}
    for line in lines:
        found = extract_keywords(line)
        for kw, cat in found.items():
            if kw not in seen:
                ctx = line[:60]
                seen[kw] = Requirement(
                    keyword=kw, weight=infer_weight(ctx), matched=False, found_in=""
                )

    # 要求行识别（用于 suggestion 上下文）
    req_lines = [l for l in lines if any(h in l for h in REQ_LINE_HINTS)]

    return JDParsed(
        role=role,
        company_hint=lines[0] if lines else "",
        requirements=list(seen.values()),
        raw_text=raw,
    )


# ---------------------------------------------------------------- 简历解析
KNOWN_HEADERS = (
    "基本信息", "联系方式", "教育经历", "教育背景", "技能", "技能清单", "专业技能",
    "项目经历", "项目经验", "实习经历", "工作经历", "自我评价", "个人总结", "荣誉证书",
    "证书", "荣誉", "校园经历", "自我介绍", "个人简介", "项目",
)
PERSON_INFO_HINTS = ("电话", "邮箱", "微信", "求职意向", "性别", "年龄", "出生")


def _is_header(line: str) -> bool:
    if line.startswith("#"):
        return True
    for h in KNOWN_HEADERS:
        if h in line and len(line) <= 24:
            return True
    return False


def parse_resume_rule(raw: str) -> ResumeParsed:
    raw = (raw or "").strip()
    lines = [l.rstrip() for l in raw.splitlines() if l.strip()]
    sections: list[ResumeSection] = []
    current: ResumeSection | None = None

    for line in lines:
        if _is_header(line):
            title = re.sub(r"^#+\s*", "", line).strip()
            if not title:
                continue
            if current:
                sections.append(current)
            current = ResumeSection(title=title, lines=[])
        else:
            if current is None:
                # 头部信息：姓名/联系方式等，归入「基本信息」
                if not sections or sections[0].title != "基本信息":
                    current = ResumeSection(title="基本信息", lines=[])
                    sections.append(current)
                current.lines.append(line)
            else:
                current.lines.append(line)
    if current:
        sections.append(current)

    # 尝试识别姓名（首行无冒号且不是联系方式/邮箱）
    name = ""
    if sections and sections[0].title == "基本信息" and sections[0].lines:
        first = sections[0].lines[0]
        if not re.search(r"[:：@\d]", first) and len(first) <= 10:
            name = first.strip()

    return ResumeParsed(name=name, sections=sections, raw_text=raw)


# ---------------------------------------------------------------- 匹配分析
def analyze_match_rule(jd: JDParsed, resume: ResumeParsed) -> MatchAnalysis:
    resume_text = _norm(resume.all_text)
    coverage: dict[str, list[str]] = {}

    for req in jd.requirements:
        found_sec = ""
        evidence = ""
        low_kw = _norm(req.keyword)
        for sec in resume.sections:
            if low_kw in _norm(sec.text):
                found_sec = sec.title
                # 截取一段含关键词的原文作证据
                idx = _norm(sec.text).find(low_kw)
                evidence = sec.text[max(0, idx - 18): idx + len(req.keyword) + 24].replace("\n", " ")
                break
        req.matched = bool(found_sec)
        req.found_in = found_sec
        req.evidence = evidence.strip()
        if found_sec:
            coverage.setdefault(found_sec, []).append(req.keyword)

    matched = [r for r in jd.requirements if r.matched]
    missing = [r for r in jd.requirements if not r.matched]

    # 加权得分：高=3，中=2，低=1
    w = {"高": 3, "中": 2, "低": 1}
    total = sum(w.get(r.weight, 2) for r in jd.requirements) or 1
    got = sum(w.get(r.weight, 2) for r in matched)
    score = min(99, round(got / total * 100))

    # 建议
    suggestions: list[GapItem] = []
    for r in missing:
        if r.weight == "高":
            suggestions.append(GapItem(
                level="高",
                section="项目经历 / 技能",
                message=f"JD 高优要求「{r.keyword}」在简历中未出现：若你真实掌握，请补入技能清单并给出实际使用场景；若未掌握，建议短期内补学并做一个小 demo 再投递。",
            ))
        elif r.weight == "中":
            suggestions.append(GapItem(
                level="中",
                section="技能 / 项目经历",
                message=f"JD 提到「{r.keyword}」：建议在技能栏补充，并尽量在项目描述中体现一次真实使用。",
            ))

    # 通用建议：量化、动词
    suggestions.append(GapItem(
        level="高", section="项目经历 / 实习经历",
        message="项目描述尽量「动词开头 + 技术点 + 可量化结果」：例如『实现 XX，使耗时降低 40%』。规则引擎会帮你重构句式，数字请务必补真实值。",
    ))

    return MatchAnalysis(
        overall_score=score,
        matched=matched,
        missing=missing,
        section_coverage=coverage,
        suggestions=suggestions,
    )


# ---------------------------------------------------------------- 改写引擎
ACTION_VERBS = ("负责", "实现", "设计", "搭建", "优化", "主导", "参与", "部署", "开发", "推动", "完成", "支持", "维护", "重构", "落地", "输出", "编写")
SOFT_LEADS = ("使用", "通过", "基于", "针对", "围绕", "结合", "面向", "利用", "借助")
_BULLET_RE = re.compile(r"^[-*•·]\s*")
_NUM_BULLET_RE = re.compile(r"^\d+[.、)]\s*")
# 公司/条目标题行特征：含公司名、职位名，或以「（2025.03 - 2025.06）」日期范围结尾
_ENTRY_LINE_RE = re.compile(
    r"(公司|实习生|工程师|专员|负责人|平台|系统)[^，。；]*$|·[^，。；]*（20\d\d|（20\d\d[.年/\-]\d*[^）]*）$"
)


def _normalize_bullet(line: str) -> str:
    line = _BULLET_RE.sub("", line).strip()
    line = _NUM_BULLET_RE.sub("", line)
    return line


def _is_entry_title(line: str) -> bool:
    """条目标题行（公司/项目名），保持原样不参与动词改写。"""
    return bool(_ENTRY_LINE_RE.search(line)) and "。" not in line and "；" not in line


def _verb_anchor(line: str) -> str:
    """确保以强动词/可接受引导词开头，否则按技术点推断一个。"""
    if any(line.startswith(v) for v in ACTION_VERBS) or any(line.startswith(v) for v in SOFT_LEADS):
        return line
    if any(k in line for k in ("部署", "上线", "容器", "docker", "推理")):
        return "负责" + line
    if any(k in line for k in ("测试", "用例", "缺陷", "回归")):
        return "负责" + line
    if any(k in line for k in ("开发", "编写", "编码", "实现", "脚本")):
        return "负责" + line
    if any(k in line for k in ("学习", "研究", "调研")):
        return "持续学习" + line if not line.startswith("持续") else line
    return "负责" + line


def rewrite_section_rule(
    sec: ResumeSection, jd: JDParsed, matched_kws: list[str]
) -> tuple[str, list[Change]]:
    """返回 (新文本, 变更列表)。

    - 体验类章节（项目/实习/工作）：要点做动词锚定 + 量化占位提示；条目标题行原样保留
    - 技能类章节：只做 JD 命中关键词置顶，不加动词、不加量化提示
    - 其他章节（基本信息/教育/自我评价）：原样保留
    """
    if sec.title in ("基本信息", "联系方式") or "教育" in sec.title or "评价" in sec.title or "总结" in sec.title:
        return sec.text, []

    lines = [l for l in sec.lines if l.strip()]
    if not lines:
        return "", []

    is_skill_section = "技能" in sec.title
    is_experience = any(k in sec.title for k in ("项目", "实习", "工作"))

    new_lines: list[str] = []
    changes: list[Change] = []
    entry_title = False

    for orig in lines:
        b = _normalize_bullet(orig)
        if not b:
            new_lines.append(orig)
            continue

        # 条目标题行（公司/项目名）：保留原样，前置空行分隔
        if _is_entry_title(orig):
            if new_lines and new_lines[-1] != "":
                new_lines.append("")
            new_lines.append(orig)
            entry_title = True
            continue

        if is_skill_section:
            # 技能行只做「命中置顶」，不做动词/量化改写
            new_lines.append(orig if _BULLET_RE.match(orig) or _NUM_BULLET_RE.match(orig) else "- " + orig)
            continue

        if not is_experience:
            new_lines.append(orig)
            continue

        optimized = _verb_anchor(b)
        # 量化占位：正文要点无数字时提示补真实数据
        if not re.search(r"\d", optimized):
            optimized += "（补充：真实量化结果）"

        if optimized != b:
            changes.append(Change(
                section=sec.title,
                original=orig.strip(),
                optimized=optimized,
                reason="动作动词锚定 + 量化提示",
            ))
        new_lines.append("- " + optimized if _BULLET_RE.match(orig) or _NUM_BULLET_RE.match(orig) else optimized)

    # 技能类章节：把 JD 命中的关键词置顶
    if is_skill_section and matched_kws:
        skills_ordered = []
        rest = []
        for line in new_lines:
            line_low = _norm(line)
            if any(_norm(k) in line_low for k in matched_kws):
                skills_ordered.append(line)
            else:
                rest.append(line)
        new_lines = skills_ordered + rest
        changes.append(Change(
            section=sec.title, original=sec.text, optimized="\n".join(new_lines),
            reason="将 JD 命中的技能关键词排序置顶，提升 HR/机器筛选命中率",
        ))

    return "\n".join(new_lines), changes


def assemble_rule(
    resume: ResumeParsed, jd: JDParsed, analysis: MatchAnalysis
) -> OptimizedResume:
    """按 JD 相关度重排章节 + 逐段改写。"""
    changes: list[Change] = []
    new_sections: list[tuple[str, str]] = []

    priority = {"项目经历": 0, "项目经验": 0, "实习经历": 1, "工作经历": 1,
                "专业技能": 2, "技能": 2, "技能清单": 2,
                "基本信息": 3, "教育经历": 4, "教育背景": 4,
                "自我评价": 5, "个人总结": 5, "证书": 6, "荣誉证书": 6}

    matched_kws = [r.keyword for r in analysis.matched]

    for sec in resume.sections:
        text, sec_changes = rewrite_section_rule(sec, jd, matched_kws)
        changes.extend(sec_changes)
        new_sections.append((sec.title, text))

    new_sections.sort(key=lambda t: priority.get(t[0], 9))

    parts = [f"# {resume.name or '候选人姓名'}"]
    # 基本信息放最前
    for title, text in new_sections:
        if title == "基本信息" and text:
            parts[0] = f"# {resume.name or '候选人姓名'}\n\n{text}"
    for title, text in new_sections:
        if not text or title == "基本信息":
            continue
        parts.append(f"## {title}\n\n{text}")

    content = "\n\n".join(parts)
    return OptimizedResume(content=content, changes=changes)


# ---------------------------------------------------------------- 打招呼语
_QUANT_HINT = re.compile(r"（补充：真实量化结果）|（建议补充真实量化结果[^）]*）")


def _clean_highlight(line: str, limit: int = 48) -> str:
    line = _QUANT_HINT.sub("", line).strip()
    line = re.sub(r"\s+", " ", line)
    return line if len(line) <= limit else line[:limit] + "…"


def _best_highlight(resume: ResumeParsed, matched_kws: list[str]) -> str:
    """从体验类章节中挑出与 JD 关键词交集最多的一句话作亮点。"""
    best_line, best_score = "", 0
    for sec in resume.sections:
        if not any(k in sec.title for k in ("项目", "实习", "工作")):
            continue
        for line in sec.lines:
            raw = _normalize_bullet(line)
            if not raw or _is_entry_title(line):
                continue
            score = sum(1 for k in matched_kws if _norm(k) in _norm(raw))
            if score > best_score:
                best_score, best_line = score, raw
    return _clean_highlight(best_line)


def generate_greetings_rule(
    jd: JDParsed, resume: ResumeParsed, analysis: MatchAnalysis
) -> list[Greeting]:
    """基于「JD ∩ 简历」的交集要点生成 3 种风格的打招呼语。

    模板原则：只引用简历中真实存在的经历，不虚构。
    """
    name = resume.name.strip()
    role = re.sub(r"（[^）]*）", "", jd.role).strip() or "贵司在招岗位"
    matched_kws = [r.keyword for r in analysis.matched if r.weight in ("高", "中")]
    kw_str = "、".join(matched_kws[:4]) or "相关技术"
    hl = _best_highlight(resume, [r.keyword for r in analysis.matched])
    name_part = f"{name}，" if name else ""

    greetings: list[Greeting] = []

    # 1) 简洁版：礼貌 + 匹配度一句话
    content1 = (
        f"您好！我是{name}，我对贵司的{role}招聘信息很感兴趣，"
        f"技术栈与岗位要求匹配度较高（{kw_str}等）。"
    )
    if hl:
        content1 += f"{hl}，"
    content1 += "方便的话希望与您进一步沟通，期待您的回复！"
    greetings.append(Greeting(style="简洁版", content=content1))

    # 2) 亮点版：最强实践开场
    head = f"其中{hl}。" if hl else ""
    content2 = (
        f"您好！我是{name}，应聘贵司的{role}岗位。"
        f"我有{kw_str}方向的真实项目/实习实践，{head}"
        "可快速上手，期待与您面聊机会！"
    )
    greetings.append(Greeting(style="亮点版", content=content2))

    # 3) 诚恳版：态度 + 可塑性强
    content3 = (
        f"您好！{name_part}我对贵司的{role}岗位非常感兴趣。"
        f"在{kw_str}方向有实际项目与实习实践（{hl or '有完整的项目落地经历'}），"
        "学习能力强、能快速适应团队节奏。"
        "恳请您抽空看一下我的简历，期待有机会交流，谢谢！"
    )
    greetings.append(Greeting(style="诚恳版", content=content3))

    return greetings
