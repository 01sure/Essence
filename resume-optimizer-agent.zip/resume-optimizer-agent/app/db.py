"""SQLite 数据层：求职系统业务表 + 通用访问辅助。

表：
- job_records       求职记录（公司 / 岗位 / JD / 状态 / 创建时间）
- resume_versions   简历版本（多版本管理，is_active 标记当前版本）
- greeting_history  打招呼语历史（挂在求职记录下）
- interview_plans   面试准备计划（问题清单以 JSON 存储）
- kb_docs           知识库文档（公司资料 / 面经 / 岗位说明等）

设计原则：
- 零额外依赖：标准库 sqlite3，文件落在项目 data/agent.db
- 每次操作短连接（读写都开新连接），天然线程安全，量级对本地工具完全够用
- 返回 dict 而非模型对象，前端/接口层再决定如何序列化
"""
from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

DB_DIR = Path(__file__).resolve().parent.parent / "data"
DB_PATH = DB_DIR / "agent.db"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS job_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company TEXT NOT NULL DEFAULT '',
    position TEXT NOT NULL DEFAULT '',
    jd TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'active',          -- active / interviewing / offer / archived
    note TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS resume_versions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    label TEXT NOT NULL DEFAULT '',
    content TEXT NOT NULL DEFAULT '',
    is_active INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS greeting_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id INTEGER NOT NULL DEFAULT 0,              -- 0 表示未关联求职记录
    style TEXT NOT NULL DEFAULT '',
    content TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS interview_plans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id INTEGER NOT NULL DEFAULT 0,
    resume_id INTEGER NOT NULL DEFAULT 0,
    role TEXT NOT NULL DEFAULT '',
    questions TEXT NOT NULL DEFAULT '[]',           -- JSON 数组
    llm_mode INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS kb_docs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL DEFAULT '',
    content TEXT NOT NULL DEFAULT '',
    source TEXT NOT NULL DEFAULT '',                -- 来源：文件名 / paste
    tags TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS chat_scripts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id INTEGER NOT NULL DEFAULT 0,
    kind TEXT NOT NULL DEFAULT '',                -- hello / reply / followup / diagnose
    scene TEXT NOT NULL DEFAULT '',               -- 场景：ask_salary / 第2轮追问 ...
    style TEXT NOT NULL DEFAULT '',               -- 风格：简洁专业版 / 热情示好版 ...
    content TEXT NOT NULL DEFAULT '',
    role TEXT NOT NULL DEFAULT '',
    llm_mode INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- 每次 JD×简历解析的快照：缺陷追踪 / 竞争力趋势的数据源
CREATE TABLE IF NOT EXISTS parse_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id INTEGER NOT NULL DEFAULT 0,
    resume_id INTEGER NOT NULL DEFAULT 0,
    label TEXT NOT NULL DEFAULT '',            -- 公司/岗位标签
    role TEXT NOT NULL DEFAULT '',
    jd_text TEXT NOT NULL DEFAULT '',
    resume_text TEXT NOT NULL DEFAULT '',
    score INTEGER NOT NULL DEFAULT 0,
    matched TEXT NOT NULL DEFAULT '',          -- JSON array
    missing TEXT NOT NULL DEFAULT '',          -- JSON array [{keyword, weight}]
    optimized TEXT NOT NULL DEFAULT '',        -- 本次生成的简历全文
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- 项目库：简历项目的结构化沉淀，供「按 JD 推荐更适合的项目」匹配打分
CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL DEFAULT '',
    role TEXT NOT NULL DEFAULT '',             -- 项目中担任的角色
    tags TEXT NOT NULL DEFAULT '',             -- 技术标签，逗号分隔
    summary TEXT NOT NULL DEFAULT '',          -- 一句话简介
    bullets TEXT NOT NULL DEFAULT '',          -- JSON array 要点
    starred INTEGER NOT NULL DEFAULT 0,        -- 是否重点展示
    source TEXT NOT NULL DEFAULT 'manual',     -- manual / resume
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- 面试复盘：面试后上传记录 → 总结提炼 → 反哺缺陷与知识库
CREATE TABLE IF NOT EXISTS interview_reviews (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id INTEGER NOT NULL DEFAULT 0,
    company TEXT NOT NULL DEFAULT '',
    position TEXT NOT NULL DEFAULT '',
    raw_text TEXT NOT NULL DEFAULT '',
    summary TEXT NOT NULL DEFAULT '',          -- 整体总结
    questions TEXT NOT NULL DEFAULT '',        -- JSON 被问到的问题
    weaknesses TEXT NOT NULL DEFAULT '',       -- JSON 暴露的盲点
    actions TEXT NOT NULL DEFAULT '',          -- JSON 改进项
    score INTEGER NOT NULL DEFAULT 0,          -- 表现自评 0-100
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- 记录中心：随手记一条求职/面试 → 自动提取归纳 → 卡片墙展示
CREATE TABLE IF NOT EXISTS records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kind TEXT NOT NULL DEFAULT '求职记录',         -- 求职记录 / 面试记录
    company TEXT NOT NULL DEFAULT '',
    position TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT '',              -- 进度：待投递/已投递/面试中/offer/拒信/已复盘
    title TEXT NOT NULL DEFAULT '',
    raw_text TEXT NOT NULL DEFAULT '',            -- 用户喂入的原文（图片OCR/文件/粘贴）
    summary TEXT NOT NULL DEFAULT '',             -- 自动归纳摘要
    points TEXT NOT NULL DEFAULT '[]',           -- JSON 数组：归纳要点
    tags TEXT NOT NULL DEFAULT '',               -- 标签，逗号分隔
    source TEXT NOT NULL DEFAULT '',             -- 来源：图片OCR / 文件名 / paste
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE INDEX IF NOT EXISTS idx_greeting_job ON greeting_history(job_id);
CREATE INDEX IF NOT EXISTS idx_interview_job ON interview_plans(job_id);
CREATE INDEX IF NOT EXISTS idx_job_updated ON job_records(updated_at);
CREATE INDEX IF NOT EXISTS idx_chat_kind ON chat_scripts(kind);
CREATE INDEX IF NOT EXISTS idx_record_kind ON records(kind);
CREATE INDEX IF NOT EXISTS idx_record_created ON records(created_at);

-- 智能投递：用户自己的简历画像（固定单行，作为匹配基准）
CREATE TABLE IF NOT EXISTS delivery_profile (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    content TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- 智能投递：平台登录会话状态机（手动扫码登录后保存 cookie）
CREATE TABLE IF NOT EXISTS delivery_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    platform TEXT NOT NULL,                  -- boss / liepin / zhilian
    status TEXT NOT NULL DEFAULT 'disconnected',  -- disconnected/connecting/qr_ready/ready/expired/error
    cookies_path TEXT NOT NULL DEFAULT '',
    qr_path TEXT NOT NULL DEFAULT '',
    last_login TEXT NOT NULL DEFAULT '',
    expires_at TEXT NOT NULL DEFAULT '',
    message TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_ds_platform ON delivery_sessions(platform);

-- 智能投递：检索到的岗位 + 匹配结果 + 审批/投递状态
CREATE TABLE IF NOT EXISTS delivery_jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    platform TEXT NOT NULL DEFAULT '',
    job_key TEXT NOT NULL DEFAULT '',        -- 平台岗位唯一标识（去重用）
    title TEXT NOT NULL DEFAULT '',
    company TEXT NOT NULL DEFAULT '',
    city TEXT NOT NULL DEFAULT '',
    salary TEXT NOT NULL DEFAULT '',
    url TEXT NOT NULL DEFAULT '',
    jd_text TEXT NOT NULL DEFAULT '',
    match_score INTEGER NOT NULL DEFAULT 0,
    reasons TEXT NOT NULL DEFAULT '[]',      -- JSON 数组：匹配理由
    tags TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'pending',  -- pending/approved/skipped/applied/failed
    note TEXT NOT NULL DEFAULT '',           -- 针对性投递备注（打招呼语 / 简历亮点）
    applied_at TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_dj_platform ON delivery_jobs(platform);
CREATE INDEX IF NOT EXISTS idx_dj_status ON delivery_jobs(status);

-- 智能投递：投递活动审计日志（防拦截诊断 + 透明可追溯）
CREATE TABLE IF NOT EXISTS delivery_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    platform TEXT NOT NULL DEFAULT '',
    action TEXT NOT NULL DEFAULT '',         -- login/search/match/apply/skip/error/pause
    target TEXT NOT NULL DEFAULT '',
    detail TEXT NOT NULL DEFAULT '',
    level TEXT NOT NULL DEFAULT 'info',      -- info/warn/error
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_dl_created ON delivery_log(created_at);

-- 智能投递：安全控制器配置（日上限 / 阈值 / 延时等）
CREATE TABLE IF NOT EXISTS delivery_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL DEFAULT ''
);
"""


def init_db() -> None:
    """建库建表（幂等）。"""
    DB_DIR.mkdir(parents=True, exist_ok=True)
    with _conn() as conn:
        conn.executescript(_SCHEMA)


def _conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _rows_to_dicts(rows: Iterable[sqlite3.Row]) -> list[dict[str, Any]]:
    return [dict(r) for r in rows]


# ================================================================ 求职记录
def job_create(company: str, position: str, jd: str = "", note: str = "") -> int:
    with _conn() as conn:
        cur = conn.execute(
            "INSERT INTO job_records(company, position, jd, note) VALUES(?,?,?,?)",
            (company, position, jd, note),
        )
        return int(cur.lastrowid)


def job_list(status: str = "") -> list[dict[str, Any]]:
    with _conn() as conn:
        if status:
            rows = conn.execute(
                "SELECT * FROM job_records WHERE status=? ORDER BY updated_at DESC", (status,)
            ).fetchall()
        else:
            rows = conn.execute("SELECT * FROM job_records ORDER BY updated_at DESC").fetchall()
    return _rows_to_dicts(rows)


def job_get(job_id: int) -> dict[str, Any] | None:
    with _conn() as conn:
        row = conn.execute("SELECT * FROM job_records WHERE id=?", (job_id,)).fetchone()
    return dict(row) if row else None


def job_update(job_id: int, **fields: Any) -> bool:
    allowed = {"company", "position", "jd", "status", "note"}
    updates = {k: v for k, v in fields.items() if k in allowed}
    if not updates:
        return False
    updates["updated_at"] = _now()
    cols = ", ".join(f"{k}=?" for k in updates)
    with _conn() as conn:
        cur = conn.execute(
            f"UPDATE job_records SET {cols} WHERE id=?", (*updates.values(), job_id)
        )
        return cur.rowcount > 0


def job_delete(job_id: int) -> bool:
    with _conn() as conn:
        cur = conn.execute("DELETE FROM job_records WHERE id=?", (job_id,))
        return cur.rowcount > 0


# ================================================================ 简历版本
def resume_create(label: str, content: str) -> int:
    with _conn() as conn:
        conn.execute("UPDATE resume_versions SET is_active=0")
        cur = conn.execute(
            "INSERT INTO resume_versions(label, content, is_active) VALUES(?,?,1)",
            (label, content),
        )
        return int(cur.lastrowid)


def resume_list() -> list[dict[str, Any]]:
    with _conn() as conn:
        rows = conn.execute("SELECT * FROM resume_versions ORDER BY created_at DESC").fetchall()
    return _rows_to_dicts(rows)


def resume_get(resume_id: int) -> dict[str, Any] | None:
    with _conn() as conn:
        row = conn.execute("SELECT * FROM resume_versions WHERE id=?", (resume_id,)).fetchone()
    return dict(row) if row else None


def resume_activate(resume_id: int) -> bool:
    with _conn() as conn:
        conn.execute("UPDATE resume_versions SET is_active=0")
        cur = conn.execute("UPDATE resume_versions SET is_active=1 WHERE id=?", (resume_id,))
        return cur.rowcount > 0


def resume_delete(resume_id: int) -> bool:
    with _conn() as conn:
        cur = conn.execute("DELETE FROM resume_versions WHERE id=?", (resume_id,))
        return cur.rowcount > 0


def resume_active() -> dict[str, Any] | None:
    with _conn() as conn:
        row = conn.execute(
            "SELECT * FROM resume_versions WHERE is_active=1 ORDER BY created_at DESC LIMIT 1"
        ).fetchone()
    return dict(row) if row else None


# ================================================================ 打招呼语历史
def greeting_save(job_id: int, style: str, content: str) -> int:
    with _conn() as conn:
        cur = conn.execute(
            "INSERT INTO greeting_history(job_id, style, content) VALUES(?,?,?)",
            (job_id, style, content),
        )
        return int(cur.lastrowid)


def greeting_list(job_id: int = 0) -> list[dict[str, Any]]:
    with _conn() as conn:
        if job_id:
            rows = conn.execute(
                "SELECT * FROM greeting_history WHERE job_id=? ORDER BY created_at DESC",
                (job_id,),
            ).fetchall()
        else:
            rows = conn.execute("SELECT * FROM greeting_history ORDER BY created_at DESC LIMIT 100").fetchall()
    return _rows_to_dicts(rows)


def greeting_delete(greeting_id: int) -> bool:
    with _conn() as conn:
        cur = conn.execute("DELETE FROM greeting_history WHERE id=?", (greeting_id,))
        return cur.rowcount > 0


# ================================================================ 面试准备计划
def interview_save(job_id: int, resume_id: int, role: str, questions: list[dict], llm_mode: bool) -> int:
    with _conn() as conn:
        cur = conn.execute(
            "INSERT INTO interview_plans(job_id, resume_id, role, questions, llm_mode) VALUES(?,?,?,?,?)",
            (job_id, resume_id, role, json.dumps(questions, ensure_ascii=False), int(llm_mode)),
        )
        return int(cur.lastrowid)


def interview_list(job_id: int = 0) -> list[dict[str, Any]]:
    with _conn() as conn:
        if job_id:
            rows = conn.execute(
                "SELECT * FROM interview_plans WHERE job_id=? ORDER BY created_at DESC LIMIT 20",
                (job_id,),
            ).fetchall()
        else:
            rows = conn.execute("SELECT * FROM interview_plans ORDER BY created_at DESC LIMIT 50").fetchall()
    result = []
    for r in _rows_to_dicts(rows):
        try:
            r["questions"] = json.loads(r["questions"])
        except (TypeError, json.JSONDecodeError):
            r["questions"] = []
        result.append(r)
    return result


def interview_delete(plan_id: int) -> bool:
    with _conn() as conn:
        cur = conn.execute("DELETE FROM interview_plans WHERE id=?", (plan_id,))
        return cur.rowcount > 0


# ================================================================ 知识库文档
def kb_create(title: str, content: str, source: str = "", tags: str = "") -> int:
    with _conn() as conn:
        cur = conn.execute(
            "INSERT INTO kb_docs(title, content, source, tags) VALUES(?,?,?,?)",
            (title, content, source, tags),
        )
        return int(cur.lastrowid)


def kb_list() -> list[dict[str, Any]]:
    with _conn() as conn:
        rows = conn.execute(
            "SELECT id, title, source, tags, length(content) AS chars, created_at FROM kb_docs ORDER BY created_at DESC"
        ).fetchall()
    return _rows_to_dicts(rows)


def kb_get(doc_id: int) -> dict[str, Any] | None:
    with _conn() as conn:
        row = conn.execute("SELECT * FROM kb_docs WHERE id=?", (doc_id,)).fetchone()
    return dict(row) if row else None


def kb_delete(doc_id: int) -> bool:
    with _conn() as conn:
        cur = conn.execute("DELETE FROM kb_docs WHERE id=?", (doc_id,))
        return cur.rowcount > 0


# ================================================================ 仪表盘统计
def dashboard() -> dict[str, Any]:
    with _conn() as conn:
        jobs_total = conn.execute("SELECT COUNT(*) c FROM job_records").fetchone()["c"]
        jobs_active = conn.execute("SELECT COUNT(*) c FROM job_records WHERE status='active'").fetchone()["c"]
        resumes = conn.execute("SELECT COUNT(*) c FROM resume_versions").fetchone()["c"]
        greetings = conn.execute("SELECT COUNT(*) c FROM greeting_history").fetchone()["c"]
        interviews = conn.execute("SELECT COUNT(*) c FROM interview_plans").fetchone()["c"]
        kb_docs = conn.execute("SELECT COUNT(*) c FROM kb_docs").fetchone()["c"]
        recent = conn.execute(
            "SELECT id, company, position, status, updated_at FROM job_records ORDER BY updated_at DESC LIMIT 5"
        ).fetchall()
    chats = conn.execute("SELECT COUNT(*) c FROM chat_scripts").fetchone()["c"]
    parses = conn.execute("SELECT COUNT(*) c FROM parse_runs").fetchone()["c"]
    projects = conn.execute("SELECT COUNT(*) c FROM projects").fetchone()["c"]
    reviews = conn.execute("SELECT COUNT(*) c FROM interview_reviews").fetchone()["c"]
    avg_score = conn.execute("SELECT COALESCE(AVG(score),0) s FROM parse_runs").fetchone()["s"]
    return {
        "jobs_total": jobs_total,
        "jobs_active": jobs_active,
        "resumes": resumes,
        "greetings": greetings,
        "interviews": interviews,
        "kb_docs": kb_docs,
        "chats": chats,
        "parses": parses,
        "projects": projects,
        "reviews": reviews,
        "avg_score": round(avg_score or 0),
        "recent_jobs": _rows_to_dicts(recent),
    }


# ================================================================ 沟通话术历史
def chat_save(
    kind: str, scene: str, style: str, content: str, role: str = "", job_id: int = 0, llm_mode: bool = False
) -> int:
    with _conn() as conn:
        cur = conn.execute(
            "INSERT INTO chat_scripts(job_id, kind, scene, style, content, role, llm_mode) VALUES(?,?,?,?,?,?,?)",
            (job_id, kind, scene, style, content, role, 1 if llm_mode else 0),
        )
        return cur.lastrowid or 0


def chat_list(kind: str = "", limit: int = 50) -> list[dict[str, Any]]:
    with _conn() as conn:
        if kind:
            rows = conn.execute(
                "SELECT * FROM chat_scripts WHERE kind=? ORDER BY id DESC LIMIT ?", (kind, limit)
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM chat_scripts ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
    return _rows_to_dicts(rows)


def chat_delete(script_id: int) -> bool:
    with _conn() as conn:
        cur = conn.execute("DELETE FROM chat_scripts WHERE id=?", (script_id,))
        return cur.rowcount > 0


# ================================================================ 解析快照
def parse_save(
    label: str, role: str, jd_text: str, resume_text: str, score: int,
    matched: list[str], missing: list[dict], optimized: str = "",
    job_id: int = 0, resume_id: int = 0,
) -> int:
    with _conn() as conn:
        cur = conn.execute(
            "INSERT INTO parse_runs(job_id, resume_id, label, role, jd_text, resume_text,"
            " score, matched, missing, optimized) VALUES(?,?,?,?,?,?,?,?,?,?)",
            (job_id, resume_id, label, role, jd_text, resume_text, score,
             json.dumps(matched, ensure_ascii=False),
             json.dumps(missing, ensure_ascii=False), optimized),
        )
        return cur.lastrowid or 0


def parse_list(limit: int = 30) -> list[dict[str, Any]]:
    with _conn() as conn:
        rows = conn.execute(
            "SELECT id, job_id, label, role, score, matched, missing, created_at"
            " FROM parse_runs ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
    return _rows_to_dicts(rows)


def parse_get(run_id: int) -> dict[str, Any] | None:
    with _conn() as conn:
        row = conn.execute("SELECT * FROM parse_runs WHERE id=?", (run_id,)).fetchone()
    return dict(row) if row else None


def parse_delete(run_id: int) -> bool:
    with _conn() as conn:
        cur = conn.execute("DELETE FROM parse_runs WHERE id=?", (run_id,))
        return cur.rowcount > 0


# ================================================================ 项目库
def project_create(
    name: str, role: str = "", tags: str = "", summary: str = "",
    bullets: list[str] | None = None, starred: bool = False, source: str = "manual",
) -> int:
    with _conn() as conn:
        cur = conn.execute(
            "INSERT INTO projects(name, role, tags, summary, bullets, starred, source)"
            " VALUES(?,?,?,?,?,?,?)",
            (name, role, tags, summary, json.dumps(bullets or [], ensure_ascii=False),
             1 if starred else 0, source),
        )
        return cur.lastrowid or 0


def project_list() -> list[dict[str, Any]]:
    with _conn() as conn:
        rows = conn.execute("SELECT * FROM projects ORDER BY starred DESC, id DESC").fetchall()
    return _rows_to_dicts(rows)


def project_update(project_id: int, **fields: Any) -> bool:
    allowed = {"name", "role", "tags", "summary", "bullets", "starred", "source"}
    cols = [k for k in fields if k in allowed]
    if not cols:
        return False
    if "bullets" in fields and isinstance(fields["bullets"], list):
        fields["bullets"] = json.dumps(fields["bullets"], ensure_ascii=False)
    if "starred" in fields:
        fields["starred"] = 1 if fields["starred"] else 0
    with _conn() as conn:
        cur = conn.execute(
            f"UPDATE projects SET {', '.join(c + '=?' for c in cols)} WHERE id=?",
            [fields[c] for c in cols] + [project_id],
        )
        return cur.rowcount > 0


def project_delete(project_id: int) -> bool:
    with _conn() as conn:
        cur = conn.execute("DELETE FROM projects WHERE id=?", (project_id,))
        return cur.rowcount > 0


# ================================================================ 面试复盘
def review_save(
    company: str, position: str, raw_text: str, summary: str,
    questions: list[str], weaknesses: list[str], actions: list[str],
    score: int = 0, job_id: int = 0,
) -> int:
    with _conn() as conn:
        cur = conn.execute(
            "INSERT INTO interview_reviews(job_id, company, position, raw_text, summary,"
            " questions, weaknesses, actions, score) VALUES(?,?,?,?,?,?,?,?,?)",
            (job_id, company, position, raw_text, summary,
             json.dumps(questions, ensure_ascii=False),
             json.dumps(weaknesses, ensure_ascii=False),
             json.dumps(actions, ensure_ascii=False), score),
        )
        return cur.lastrowid or 0


def review_list(limit: int = 30) -> list[dict[str, Any]]:
    with _conn() as conn:
        rows = conn.execute(
            "SELECT id, job_id, company, position, score, summary, created_at"
            " FROM interview_reviews ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
    return _rows_to_dicts(rows)


def review_get(rid: int) -> dict[str, Any] | None:
    with _conn() as conn:
        row = conn.execute("SELECT * FROM interview_reviews WHERE id=?", (rid,)).fetchone()
    return dict(row) if row else None


def review_delete(rid: int) -> bool:
    with _conn() as conn:
        cur = conn.execute("DELETE FROM interview_reviews WHERE id=?", (rid,))
        return cur.rowcount > 0


# ================================================================ 记录中心
def record_create(
    kind: str, company: str, position: str, status: str,
    title: str, raw_text: str, summary: str,
    points: list[str] | None = None, tags: str = "", source: str = "",
) -> int:
    """新增一条求职/面试记录（已归纳好的结构化数据落库）。"""
    with _conn() as conn:
        cur = conn.execute(
            "INSERT INTO records(kind, company, position, status, title, raw_text, summary,"
            " points, tags, source) VALUES(?,?,?,?,?,?,?,?,?,?)",
            (kind, company, position, status, title, raw_text, summary,
             json.dumps(points or [], ensure_ascii=False), tags, source),
        )
        return cur.lastrowid or 0


def _parse_record(row: sqlite3.Row) -> dict[str, Any]:
    r = dict(row)
    try:
        r["points"] = json.loads(r["points"]) if r.get("points") else []
    except (TypeError, json.JSONDecodeError):
        r["points"] = []
    return r


def record_get(rid: int) -> dict[str, Any] | None:
    with _conn() as conn:
        row = conn.execute("SELECT * FROM records WHERE id=?", (rid,)).fetchone()
    return _parse_record(row) if row else None


def record_list(kind: str = "", status: str = "", limit: int = 200) -> list[dict[str, Any]]:
    """按类型 / 进度筛选，时间倒序返回。points 字段已反序列化为数组。"""
    sql = "SELECT * FROM records"
    clauses: list[str] = []
    params: list[Any] = []
    if kind:
        clauses.append("kind=?")
        params.append(kind)
    if status:
        clauses.append("status=?")
        params.append(status)
    if clauses:
        sql += " WHERE " + " AND ".join(clauses)
    sql += " ORDER BY created_at DESC LIMIT ?"
    params.append(limit)
    with _conn() as conn:
        rows = conn.execute(sql, params).fetchall()
    return [_parse_record(r) for r in rows]


def record_delete(rid: int) -> bool:
    with _conn() as conn:
        cur = conn.execute("DELETE FROM records WHERE id=?", (rid,))
        return cur.rowcount > 0


# ================================================================ 智能投递：简历画像
def delivery_profile_get() -> str:
    """返回用户自己的简历画像文本（无则空字符串）。"""
    with _conn() as conn:
        row = conn.execute("SELECT content FROM delivery_profile WHERE id=1").fetchone()
    return row["content"] if row else ""


def delivery_profile_set(content: str) -> None:
    """写入 / 更新简历画像（固定单行 id=1）。"""
    with _conn() as conn:
        conn.execute(
            "INSERT INTO delivery_profile(id, content, updated_at) VALUES(1,?,?) "
            "ON CONFLICT(id) DO UPDATE SET content=excluded.content, updated_at=excluded.updated_at",
            (content, _now()),
        )


# ================================================================ 智能投递：平台会话
def delivery_session_upsert(
    platform: str, status: str = "disconnected", cookies_path: str = "",
    qr_path: str = "", last_login: str = "", expires_at: str = "",
    message: str = "",
) -> dict[str, Any]:
    with _conn() as conn:
        row = conn.execute("SELECT * FROM delivery_sessions WHERE platform=?", (platform,)).fetchone()
        if row:
            conn.execute(
                "UPDATE delivery_sessions SET status=?, cookies_path=?, qr_path=?, last_login=?,"
                " expires_at=?, message=?, updated_at=? WHERE platform=?",
                (status, cookies_path, qr_path, last_login, expires_at, message, _now(), platform),
            )
        else:
            conn.execute(
                "INSERT INTO delivery_sessions(platform, status, cookies_path, qr_path, last_login,"
                " expires_at, message) VALUES(?,?,?,?,?,?,?)",
                (platform, status, cookies_path, qr_path, last_login, expires_at, message),
            )
        row = conn.execute("SELECT * FROM delivery_sessions WHERE platform=?", (platform,)).fetchone()
    return dict(row)


def delivery_session_get(platform: str) -> dict[str, Any] | None:
    with _conn() as conn:
        row = conn.execute("SELECT * FROM delivery_sessions WHERE platform=?", (platform,)).fetchone()
    return dict(row) if row else None


def delivery_session_list() -> list[dict[str, Any]]:
    with _conn() as conn:
        rows = conn.execute("SELECT * FROM delivery_sessions ORDER BY platform").fetchall()
    return _rows_to_dicts(rows)


def delivery_session_clear(platform: str) -> bool:
    with _conn() as conn:
        cur = conn.execute("DELETE FROM delivery_sessions WHERE platform=?", (platform,))
        return cur.rowcount > 0


# ================================================================ 智能投递：岗位 + 匹配
def delivery_job_create(
    platform: str, job_key: str, title: str, company: str = "", city: str = "",
    salary: str = "", url: str = "", jd_text: str = "", match_score: int = 0,
    reasons: list[str] | None = None, tags: str = "", status: str = "pending", note: str = "",
) -> int:
    """新增 / 更新一条岗位（按 platform+job_key 去重）。"""
    with _conn() as conn:
        existing = conn.execute(
            "SELECT id FROM delivery_jobs WHERE platform=? AND job_key=?", (platform, job_key)
        ).fetchone()
        if existing:
            conn.execute(
                "UPDATE delivery_jobs SET title=?, company=?, city=?, salary=?, url=?, jd_text=?,"
                " match_score=?, reasons=?, tags=?, status=?, note=? WHERE id=?",
                (title, company, city, salary, url, jd_text, match_score,
                 json.dumps(reasons or [], ensure_ascii=False), tags, status, note, existing["id"]),
            )
            return int(existing["id"])
        cur = conn.execute(
            "INSERT INTO delivery_jobs(platform, job_key, title, company, city, salary, url, jd_text,"
            " match_score, reasons, tags, status, note) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (platform, job_key, title, company, city, salary, url, jd_text, match_score,
             json.dumps(reasons or [], ensure_ascii=False), tags, status, note),
        )
        return int(cur.lastrowid)


def _parse_job(row: sqlite3.Row) -> dict[str, Any]:
    r = dict(row)
    try:
        r["reasons"] = json.loads(r["reasons"]) if r.get("reasons") else []
    except (TypeError, json.JSONDecodeError):
        r["reasons"] = []
    return r


def delivery_job_list(platform: str = "", status: str = "", limit: int = 300) -> list[dict[str, Any]]:
    sql = "SELECT * FROM delivery_jobs"
    clauses: list[str] = []
    params: list[Any] = []
    if platform:
        clauses.append("platform=?")
        params.append(platform)
    if status:
        clauses.append("status=?")
        params.append(status)
    if clauses:
        sql += " WHERE " + " AND ".join(clauses)
    sql += " ORDER BY match_score DESC, created_at DESC LIMIT ?"
    params.append(limit)
    with _conn() as conn:
        rows = conn.execute(sql, params).fetchall()
    return [_parse_job(r) for r in rows]


def delivery_job_get(job_id: int) -> dict[str, Any] | None:
    with _conn() as conn:
        row = conn.execute("SELECT * FROM delivery_jobs WHERE id=?", (job_id,)).fetchone()
    return _parse_job(row) if row else None


def delivery_job_update(job_id: int, **fields: Any) -> bool:
    allowed = {"status", "match_score", "reasons", "tags", "note", "applied_at"}
    cols = [k for k in fields if k in allowed]
    if not cols:
        return False
    if "reasons" in fields and isinstance(fields["reasons"], list):
        fields["reasons"] = json.dumps(fields["reasons"], ensure_ascii=False)
    with _conn() as conn:
        cur = conn.execute(
            f"UPDATE delivery_jobs SET {', '.join(c + '=?' for c in cols)} WHERE id=?",
            [fields[c] for c in cols] + [job_id],
        )
        return cur.rowcount > 0


def delivery_job_delete(job_id: int) -> bool:
    with _conn() as conn:
        cur = conn.execute("DELETE FROM delivery_jobs WHERE id=?", (job_id,))
        return cur.rowcount > 0


# ================================================================ 智能投递：审计日志 + 设置
def delivery_log_add(
    platform: str, action: str, target: str = "", detail: str = "", level: str = "info"
) -> int:
    with _conn() as conn:
        cur = conn.execute(
            "INSERT INTO delivery_log(platform, action, target, detail, level) VALUES(?,?,?,?,?)",
            (platform, action, target, detail, level),
        )
        return int(cur.lastrowid)


def delivery_log_list(limit: int = 200) -> list[dict[str, Any]]:
    with _conn() as conn:
        rows = conn.execute(
            "SELECT * FROM delivery_log ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
    return _rows_to_dicts(rows)


def delivery_setting_get(key: str, default: str = "") -> str:
    with _conn() as conn:
        row = conn.execute("SELECT value FROM delivery_settings WHERE key=?", (key,)).fetchone()
    return row["value"] if row else default


def delivery_setting_set(key: str, value: str) -> None:
    with _conn() as conn:
        conn.execute(
            "INSERT INTO delivery_settings(key, value) VALUES(?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value),
        )
