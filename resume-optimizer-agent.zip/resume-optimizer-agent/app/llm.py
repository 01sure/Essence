"""LLM 客户端：OpenAI 兼容 Chat Completions 调用。

- 支持任意 OpenAI 兼容端点（DeepSeek / Qwen / GLM / Ollama ...）
- 内置 JSON 模式（response_format={"type":"json_object"}），解析失败时容错
- 规则引擎回退由各 tool 自行处理（llm_enabled=False 时调用方不进入 LLM 分支）
"""
from __future__ import annotations

import json
import logging
from typing import Any

import httpx

from app.config import settings

logger = logging.getLogger("resume-agent.llm")

SYSTEM_PROMPT = (
    "你是一名资深的简历优化专家，服务于求职者。"
    "你擅长把技术简历改写得具体、量化、贴合目标岗位的 JD，"
    "同时坚持真实原则：绝不虚构经历与数据。"
)


class LLMError(Exception):
    pass


async def chat_json(
    messages: list[dict[str, str]],
    *,
    temperature: float = 0.3,
    max_tokens: int = 4000,
    system: str = SYSTEM_PROMPT,
) -> dict[str, Any]:
    """调用 LLM，要求返回合法 JSON 对象（dict）。失败抛 LLMError。"""
    if not settings.llm_enabled:
        raise LLMError("LLM 未配置（缺少 LLM_BASE_URL / LLM_API_KEY）")

    body: dict[str, Any] = {
        "model": settings.llm_model,
        "messages": [{"role": "system", "content": system}] + messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
        "response_format": {"type": "json_object"},
    }
    url = settings.llm_base_url.rstrip("/") + "/chat/completions"
    headers = {"Authorization": f"Bearer {settings.llm_api_key}"}

    try:
        async with httpx.AsyncClient(timeout=120) as client:
            resp = await client.post(url, json=body, headers=headers)
            resp.raise_for_status()
            data = resp.json()
    except httpx.HTTPError as e:
        raise LLMError(f"LLM 请求失败: {e}") from e

    try:
        content = data["choices"][0]["message"]["content"]
        parsed = json.loads(content)
        if not isinstance(parsed, dict):
            raise ValueError("返回内容不是 JSON 对象")
        return parsed
    except (KeyError, IndexError, json.JSONDecodeError, ValueError) as e:
        raise LLMError(f"LLM 返回解析失败: {e}") from e
