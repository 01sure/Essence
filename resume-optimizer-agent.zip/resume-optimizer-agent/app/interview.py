"""面试准备模块：根据 JD × 简历 智能生成面试题与参考回答要点。

两条模式：
- 规则模式（无 LLM）：内置关键词题库 + 简历项目深挖 + 开放题，可离线演示
- LLM 模式：JD+简历+命中关键词交给大模型，生成更贴近真实面试的题目与参考回答

输出分类：
- 技术基础：由 JD 技术要求关键词命中内置题库生成
- 项目深挖：从简历「项目/实习/工作」章节提取要点，按 STAR 框架追问
- 开放问题：自我介绍 / 职业规划 / 岗位理解等高频开放题
"""
from __future__ import annotations

import logging
import re
from typing import Any

from app import llm
from app.config import settings
from app.schemas import InterviewPlan, InterviewQuestion, JDParsed, ResumeParsed, ResumeSection

logger = logging.getLogger("resume-agent.interview")

# ================================================================ 题库
# 每个条目：question（题目） / difficulty（易中难） / points（回答要点）
_INTERVIEW_BANK: dict[str, list[dict[str, Any]]] = {
    "python": [
        {
            "question": "Python 中 GIL 是什么？对多线程程序有什么影响？如何绕开它？",
            "difficulty": "中",
            "points": [
                "GIL 是 CPython 解释器的全局解释器锁，同一时刻只允许一个线程执行字节码",
                "CPU 密集型任务多线程无法并行，I/O 密集型（网络/文件）多线程依然有效",
                "绕开方案：多进程 multiprocessing、asyncio 协程、C 扩展释放 GIL",
            ],
        },
        {
            "question": "装饰器的原理是什么？你写过哪些实际用到的装饰器？",
            "difficulty": "中",
            "points": [
                "装饰器本质是接收函数并返回新函数的高阶函数，语法糖 @deco 等价于 f = deco(f)",
                "用 functools.wraps 保留原函数元信息",
                "实际场景：鉴权、日志、重试、限流、缓存（写一个重试装饰器作为例子）",
            ],
        },
        {
            "question": "列表推导式与生成器表达式的区别？内存占用差异？",
            "difficulty": "易",
            "points": [
                "列表推导式立即生成完整列表，占用内存；生成器表达式惰性求值，按需产出",
                "海量数据用生成器（如逐行读文件），小数据用列表更快",
            ],
        },
    ],
    "fastapi": [
        {
            "question": "FastAPI 相比 Flask/Django 的核心优势是什么？",
            "difficulty": "中",
            "points": [
                "基于 Pydantic 自动做请求校验与文档（OpenAPI 自动生成）",
                "async/await 原生支持，高并发 I/O 场景性能更好",
                "类型提示驱动：声明即校验即文档，开发效率高",
            ],
        },
        {
            "question": "FastAPI 的依赖注入（Depends）如何工作？你用它解决过什么问题？",
            "difficulty": "中",
            "points": [
                "Depends 声明依赖，FastAPI 按函数签名自动解析并注入",
                "典型用途：数据库会话管理、鉴权、公共参数复用、单例服务",
                "可分层复用（函数依赖嵌套），也支持 yield 做资源清理",
            ],
        },
        {
            "question": "如何给 FastAPI 接口做并发控制与限流？",
            "difficulty": "难",
            "points": [
                "简单场景：中间件 + 内存计数；分布式场景用 Redis 滑动窗口/令牌桶",
                "LLM 服务常配并发信号量（asyncio.Semaphore）保护上游 API",
                "重试 + 退避策略（tenacity 或自定义）",
            ],
        },
    ],
    "langchain": [
        {
            "question": "LangChain 的核心组件有哪些？Chain 和 Agent 的区别？",
            "difficulty": "中",
            "points": [
                "核心组件：Model（模型封装）、Prompt（模板）、Chain（流程编排）、Agent（决策式执行）、Memory（记忆）、Retriever（检索）",
                "Chain 是固定流程（写死的调用顺序）；Agent 让 LLM 自主决定调哪些工具、按什么顺序",
                "Agent 适合工具多、流程不固定的场景；Chain 适合稳定流水线",
            ],
        },
        {
            "question": "LangChain 中如何实现结构化输出？",
            "difficulty": "中",
            "points": [
                "with_structured_output / output_parser + Pydantic 模型",
                "底层用 function calling 或 JSON mode 约束",
                "解析失败要兜底：重试或规则回退",
            ],
        },
    ],
    "rag": [
        {
            "question": "讲一下 RAG 的完整流程，和微调相比有什么优缺点？",
            "difficulty": "中",
            "points": [
                "流程：文档切块 → 向量化入库 → 查询向量化 → 相似度检索 → 拼接 Prompt → 生成回答",
                "优点：知识可实时更新、可溯源、成本低、不改变模型本身；缺点：检索质量决定上限、多跳问题弱",
                "与微调对比：RAG 管「知识」，微调管「风格/能力」，常组合使用",
            ],
        },
        {
            "question": "RAG 检索不准确怎么办？你会怎么优化？",
            "difficulty": "难",
            "points": [
                "切块策略：按语义/标题切，块大小 300-800 token，重叠 10-20%",
                "检索优化：混合检索（向量+BM25 关键词）、重排序（rerank）、HyDE（先让 LLM 生成假设答案再检索）",
                "Query 改写：意图识别、多查询扩展、会话历史拼接",
                "评估：建立评测集，用命中率/答案相关度持续迭代",
            ],
        },
        {
            "question": "向量检索的相似度计算方式有哪些？各自适用场景？",
            "difficulty": "中",
            "points": [
                "余弦相似度（最常用，对向量长度不敏感）、内积（配合归一化后等价余弦）、欧氏距离",
                "BGE/M3E 等中文 Embedding 模型常用余弦；faiss 里内积在归一化后更快",
            ],
        },
    ],
    "大模型": [
        {
            "question": "大模型部署有哪些关键点？推理优化手段你知道哪些？",
            "difficulty": "中",
            "points": [
                "部署关键点：显存占用（权重+KV Cache）、并发与吞吐、首token延迟、流式输出",
                "优化手段：量化（INT8/INT4）、vLLM/TensorRT-LLM 推理框架、KV Cache 复用、continuous batching",
                "生产环境：Docker 容器化 + GPU 调度 + 健康检查与自动扩缩容",
            ],
        },
        {
            "question": "Prompt 工程常用技巧有哪些？",
            "difficulty": "易",
            "points": [
                "角色设定 + 明确任务 + 输出格式约束（JSON schema）",
                "Few-shot 示例、思维链（CoT）、约束负面行为（如：不要编造）",
                "温度/上下文长度等参数配合；复杂任务拆步骤",
            ],
        },
    ],
    "agent": [
        {
            "question": "Agent 与普通 API 调用的本质区别是什么？你如何设计一个 Agent？",
            "difficulty": "中",
            "points": [
                "普通调用是一次性请求-响应；Agent 是「循环决策」：观察 → 思考 → 行动 → 再观察",
                "设计要点：工具抽象（输入输出约束）、编排循环、轨迹可观测、失败回退、安全边界",
                "举例：本项目 5 工具编排 + trace 记录 + LLM/规则双模式，就是 Agent 的最小完整实现",
            ],
        },
        {
            "question": "ReAct 模式是什么？Function Calling 和它有什么关系？",
            "difficulty": "难",
            "points": [
                "ReAct = Reasoning + Acting：让模型边推理边调用工具，推理指导行动、行动结果反馈推理",
                "Function Calling 是模型输出层支持的结构化工具调用能力，是实现 ReAct 循环的机制之一",
                "也可以手写 JSON 格式约束实现，不依赖厂商专属能力",
            ],
        },
    ],
    "向量数据库": [
        {
            "question": "向量数据库和普通数据库的区别？选型时看什么？",
            "difficulty": "中",
            "points": [
                "向量库以向量索引（HNSW/IVF）为核心，支持 ANN 近似最近邻检索，普通库只做精确匹配",
                "选型看：亿级规模与召回率（HNSW 参数）、过滤能力（metadata filter）、部署方式（本地/云）",
                "轻量场景 Chroma/FAISS（本地文件），生产级 Milvus/Qdrant/Weaviate",
            ],
        },
        {
            "question": "HNSW 索引的原理一句话概括？",
            "difficulty": "难",
            "points": [
                "分层跳表思想：多层图，上层稀疏长跳、下层稠密细找，兼顾检索速度与召回",
                "构建参数 M（连接数）与 efConstruction 权衡内存与召回",
            ],
        },
    ],
    "docker": [
        {
            "question": "镜像与容器的区别？如何编写一个高效的 Dockerfile？",
            "difficulty": "中",
            "points": [
                "镜像是只读模板（分层存储），容器是镜像的运行实例（可写层）",
                "高效 Dockerfile：多阶段构建、合并 RUN、.dockerignore、固定基础镜像 tag、非 root 用户运行",
                "Python 项目：requirements 先 COPY 先装依赖（利用层缓存），再 COPY 代码",
            ],
        },
        {
            "question": "容器编排你了解吗？K8s 的基本概念？",
            "difficulty": "中",
            "points": [
                "K8s 核心：Pod（最小调度单位）、Deployment（副本管理）、Service（网络访问）、ConfigMap/Secret（配置）",
                "声明式：写 YAML 描述期望状态，控制器不断收敛到期望状态",
                "轻量替代：docker-compose 适合单机多容器",
            ],
        },
    ],
    "embedding": [
        {
            "question": "什么是 Embedding？如何选择 Embedding 模型？",
            "difficulty": "中",
            "points": [
                "Embedding 把文本映射为稠密向量，语义相近的文本向量距离近",
                "选择看：语言支持（中文用 BGE/M3E）、维度与最大长度、检索效果（MTEB 基准）、部署成本",
                "注意：入库与查询必须用同一个模型",
            ],
        },
    ],
    "微调": [
        {
            "question": "什么是 LoRA 微调？和全参微调的区别？",
            "difficulty": "中",
            "points": [
                "LoRA 冻结原权重，只训练低秩分解矩阵，显存占用小、训练快",
                "全参微调效果好但成本高，小团队常用 LoRA/QLoRA（4bit 量化 + LoRA）",
                "微调目的：风格对齐/领域能力增强，而不是注入新知识（新知识用 RAG）",
            ],
        },
    ],
    "部署": [
        {
            "question": "一个 AI 服务从开发到上线要经过哪些环节？",
            "difficulty": "中",
            "points": [
                "模型选型 → 推理服务封装（API）→ 容器化 → 部署（GPU 服务器/云）→ 监控告警 → 迭代",
                "上线前：压测（QPS/延迟/显存）、容错（超时重试、降级）、安全（鉴权、内容过滤）",
                "上线后：日志与指标监控、版本灰度、模型效果回归",
            ],
        },
    ],
    "flask": [
        {
            "question": "Flask 和 FastAPI 你会怎么选？",
            "difficulty": "易",
            "points": [
                "Flask 轻量灵活、生态老；FastAPI 自带校验/文档/async，现代 API 优先 FastAPI",
                "老项目维护选 Flask，新项目（尤其 AI 服务）选 FastAPI",
            ],
        },
    ],
    "java": [
        {
            "question": "Java 的 Spring Boot 和 Python 技术栈你更倾向哪个？为什么转向 AI 方向？",
            "difficulty": "中",
            "points": [
                "Java 强类型、生态成熟、适合企业级稳定服务；Python 在 AI/数据处理生态碾压式优势",
                "转向原因：AI 应用层开发语言栈几乎都是 Python，且 Agent/RAG 生态迭代极快",
            ],
        },
    ],
    "sql": [
        {
            "question": "SQL 优化的一般思路？",
            "difficulty": "中",
            "points": [
                "先看执行计划 EXPLAIN，定位全表扫描/大排序",
                "加索引（覆盖索引）、避免 SELECT *、分页优化（游标/延迟关联）、避免函数作用于索引列",
                "数据量大考虑分库分表或换列存/数仓方案",
            ],
        },
    ],
    "redis": [
        {
            "question": "Redis 常见使用场景？缓存穿透/击穿/雪崩怎么解决？",
            "difficulty": "中",
            "points": [
                "场景：缓存、限流、分布式锁、消息队列（List/Stream）、排行榜（ZSet）",
                "穿透：缓存空值/布隆过滤器；击穿：互斥锁/逻辑过期；雪崩：过期时间加随机、多级缓存、限流降级",
            ],
        },
    ],
    "linux": [
        {
            "question": "线上服务出问题，你的排查思路是什么？",
            "difficulty": "中",
            "points": [
                "顺序：看监控指标（CPU/内存/磁盘/网络）→ 日志（应用日志/系统日志）→ 进程状态（top/ps）",
                "网络问题：ping/telnet/ss；IO：iostat；内存：free + 大对象分析",
                "先止血（重启/降级/扩容）再定位根因，避免在排查中扩大故障",
            ],
        },
    ],
    "测试": [
        {
            "question": "你如何保证自己写的接口质量？",
            "difficulty": "易",
            "points": [
                "单测覆盖核心逻辑 + 接口测试（pytest + httpx）",
                "异常路径：参数校验、超时、上游失败降级",
                "配合类型检查与代码评审",
            ],
        },
    ],
    "k8s": [
        {
            "question": "Pod 重启的策略有哪些？什么场景用哪种？",
            "difficulty": "中",
            "points": [
                "Always（默认，服务常驻）/ OnFailure（任务型，失败才重启）/ Never（批处理一次性）",
                "配合探针（liveness/readiness）实现健康检查",
            ],
        },
    ],
}

# JD 关键词 → 题库键 的别名映射（归一化后匹配）
_ALIAS_MAP: dict[str, str] = {
    "python": "python", "py": "python",
    "fastapi": "fastapi", "flask": "flask",
    "langchain": "langchain", "langchain4j": "langchain",
    "rag": "rag", "检索增强": "rag", "知识库问答": "rag",
    "大模型": "大模型", "llm": "大模型", "qwen": "大模型", "通义千问": "大模型",
    "agent": "agent", "智能体": "agent",
    "向量数据库": "向量数据库", "向量库": "向量数据库", "faiss": "向量数据库",
    "docker": "docker", "容器": "docker", "容器化": "docker",
    "embedding": "embedding", "向量化": "embedding",
    "微调": "微调", "模型微调": "微调", "lora": "微调",
    "部署": "部署", "推理部署": "部署",
    "java": "java", "springboot": "java", "spring": "java",
    "sql": "sql", "mysql": "sql",
    "redis": "redis",
    "linux": "linux", "shell": "linux",
    "测试": "测试", "功能测试": "测试",
    "k8s": "k8s", "kubernetes": "k8s",
}

_GENERAL_QUESTIONS: list[dict[str, Any]] = [
    {
        "category": "开放问题",
        "question": "请做个 1 分钟自我介绍（围绕岗位要求组织，结尾给一个记忆点）。",
        "difficulty": "易",
        "points": [
            "结构：我是谁（背景）+ 我做过什么（与岗位最相关的 2 段经历）+ 我为什么适合（技术栈匹配 + 亮点）",
            "用 STAR 讲一个最能证明能力的项目，量化结果优先",
            "结尾埋钩子：如「我最近在做 X，刚好覆盖贵司这个岗位的核心技术点」",
        ],
    },
    {
        "category": "开放问题",
        "question": "你对我们公司和这个岗位的理解是什么？为什么选择我们？",
        "difficulty": "中",
        "points": [
            "提前查公司官网/产品，说 1-2 个具体业务点（不要只说「发展好」）",
            "结合岗位：说明岗位职责与自身能力/兴趣的契合点",
            "展示意愿度：能为公司带来什么（技术/效率/新想法）",
        ],
    },
    {
        "category": "开放问题",
        "question": "你的职业规划是什么？未来 1-3 年想做什么？",
        "difficulty": "易",
        "points": [
            "短期（1年）：尽快上手业务，成为团队内 AI 应用开发的主力",
            "中期（2-3年）：深入大模型应用工程（RAG/Agent 架构），能独立负责一个方向",
            "落地：结合当前正在做的事（练手项目、开源、面经）体现执行力",
        ],
    },
    {
        "category": "开放问题",
        "question": "你最大的优点和缺点是什么？",
        "difficulty": "中",
        "points": [
            "优点：结合具体事例（如：学习能力强——从 Java 转 Python 用 X 周做出 Y 项目）",
            "缺点：选一个真实但不致命的缺点，并给出正在改进的具体动作（如：代码追求完美导致进度慢 → 现在用先跑通再优化的节奏）",
            "忌：说「我最大的缺点是太追求完美」这种包装式回答",
        ],
    },
]

_EXPERIENCE_SECTION_KEYWORDS = ("项目", "实习", "工作", "经历", "实践")


def _norm(text: str) -> str:
    return re.sub(r"[\s\-_/·：:（）()]", "", text).lower()


def _match_bank_keyword(raw_kw: str) -> str | None:
    """把 JD 提取的关键词映射到题库键，找不到返回 None。"""
    n = _norm(raw_kw)
    if n in _ALIAS_MAP:
        return _ALIAS_MAP[n]
    for key in _INTERVIEW_BANK:
        if key in n or n in _norm(key):
            return key
    return None


def _extract_experience_points(resume: ResumeParsed) -> list[str]:
    """从体验类章节提取要点句子（用于项目深挖题）。"""
    points: list[str] = []
    for sec in resume.sections:
        if not any(k in sec.title for k in _EXPERIENCE_SECTION_KEYWORDS):
            continue
        for line in sec.lines:
            line = line.strip().lstrip("-*•· ").strip()
            if len(line) >= 12 and not re.search(r"^\d{4}", line) and "公司" not in line[:8]:
                points.append(line)
        # 章节标题本身也作为素材（如项目名）
        if sec.title and not any(t == sec.title for t in points):
            points.append(f"项目：{sec.title}")
    # 去重保序，最多取 6 条
    seen: set[str] = set()
    uniq: list[str] = []
    for p in points:
        if p not in seen:
            seen.add(p)
            uniq.append(p)
    return uniq[:6]


def _star_question(point: str, idx: int) -> dict[str, Any]:
    return {
        "category": "项目深挖",
        "question": f"你在「{point[:28]}{'…' if len(point) > 28 else ''}」中具体负责什么？用了什么方案？结果如何？",
        "difficulty": "中",
        "points": [
            "用 STAR 组织：背景 → 任务 → 动作（技术方案/分工）→ 结果（量化）",
            "讲清楚个人贡献：我负责 X，完成了 Y，带来了 Z 的收益，不要只说团队做了什么",
            "准备 1-2 个技术细节（遇到什么难点、怎么解决），面试官一定会追问",
        ],
        "related_resume": point,
    }


# ================================================================ 规则模式
def prepare_interview_rule(jd: JDParsed, resume: ResumeParsed) -> InterviewPlan:
    """规则模式：题库命中 + 简历项目深挖 + 开放题。"""
    questions: list[InterviewQuestion] = []
    used_bank_keys: set[str] = set()

    # 1. 技术基础题：按 JD 权重排序（高权重关键词优先出题）
    ordered = sorted(
        jd.requirements,
        key=lambda r: {"高": 0, "中": 1, "低": 2}.get(r.weight, 3),
    )
    for req in ordered:
        key = _match_bank_keyword(req.keyword)
        if not key or key in used_bank_keys:
            continue
        used_bank_keys.add(key)
        for t in _INTERVIEW_BANK.get(key, [])[:2]:
            questions.append(InterviewQuestion(
                category="技术基础",
                question=t["question"],
                keywords=[req.keyword],
                difficulty=t["difficulty"],
                answer_points=t["points"],
            ))
        if len(questions) >= 10:
            break

    # 2. 项目深挖题：从简历提取要点
    for i, point in enumerate(_extract_experience_points(resume)):
        t = _star_question(point, i)
        questions.append(InterviewQuestion(
            category="项目深挖",
            question=t["question"],
            keywords=[],
            difficulty=t["difficulty"],
            answer_points=t["points"],
            related_resume=t["related_resume"],
        ))

    # 3. 开放题
    for g in _GENERAL_QUESTIONS[:3]:
        questions.append(InterviewQuestion(
            category="开放问题",
            question=g["question"],
            keywords=[],
            difficulty=g["difficulty"],
            answer_points=g["points"],
        ))

    stats = _stats(questions)
    return InterviewPlan(
        llm_mode=False,
        role=jd.role,
        total=len(questions),
        stats=stats,
        questions=questions,
    )


def _stats(questions: list[InterviewQuestion]) -> dict[str, int]:
    s: dict[str, int] = {}
    for q in questions:
        s[q.category] = s.get(q.category, 0) + 1
    return s


# ================================================================ LLM 模式
async def prepare_interview_llm(jd: JDParsed, resume: ResumeParsed) -> InterviewPlan | None:
    """LLM 模式：让大模型生成贴近真实面试的题目与参考回答。失败返回 None。"""
    jd_summary = "\n".join(f"- {r.keyword}({r.weight})" for r in jd.requirements[:15])
    resume_text = resume.all_text[:6000]
    data = await llm.chat_json(
        [
            {
                "role": "user",
                "content": (
                    "你是资深 AI 面试官。根据目标 JD 与候选人简历，生成一份模拟面试问题清单，输出 JSON：\n"
                    '{"questions": [{"category": "技术基础|项目深挖|开放问题", '
                    '"question": "面试题", "keywords": ["相关技术关键词"], "difficulty": "易|中|难", '
                    '"answer_points": ["参考回答要点1", "要点2", "要点3"], "related_resume": "若为项目题，对应简历原文片段"}]}\n\n'
                    "要求：\n"
                    "1. 技术基础题严格基于 JD 技术要求出题，8-10 题\n"
                    "2. 项目深挖题基于简历真实经历，追问技术方案、难点与量化结果，3-4 题\n"
                    "3. 开放题 2-3 题（自我介绍/职业规划/为什么选我们）\n"
                    "4. answer_points 给真实可讲的答题要点，不要空洞套话\n"
                    "5. 绝不虚构简历中不存在的经历\n\n"
                    f"目标岗位：{jd.role}\nJD 要求：\n{jd_summary}\n\n候选人简历：\n{resume_text}"
                ),
            }
        ],
        max_tokens=6000,
        temperature=0.5,
    )
    raw_qs = data.get("questions", [])
    questions = [
        InterviewQuestion(
            category=q.get("category", "开放问题"),
            question=q.get("question", ""),
            keywords=[str(k) for k in q.get("keywords", [])],
            difficulty=q.get("difficulty", "中"),
            answer_points=[str(p) for p in q.get("answer_points", [])],
            related_resume=q.get("related_resume", ""),
        )
        for q in raw_qs
        if q.get("question")
    ]
    if not questions:
        return None
    return InterviewPlan(
        llm_mode=True,
        role=jd.role,
        total=len(questions),
        stats=_stats(questions),
        questions=questions,
    )


# ================================================================ 编排入口
async def prepare_interview(jd_raw: str, resume_raw: str) -> InterviewPlan:
    """面试准备主入口：解析 → 生成（LLM 优先，规则兜底）。"""
    from app.agent import tool_parse_jd, tool_parse_resume

    jd, _ = await tool_parse_jd(jd_raw)
    resume, _ = await tool_parse_resume(resume_raw)

    if settings.llm_enabled:
        try:
            plan = await prepare_interview_llm(jd, resume)
            if plan:
                return plan
            logger.warning("interview LLM 未返回有效结果，回退规则引擎")
        except llm.LLMError as e:
            logger.warning("interview 走 LLM 失败，回退规则引擎: %s", e)
    return prepare_interview_rule(jd, resume)
