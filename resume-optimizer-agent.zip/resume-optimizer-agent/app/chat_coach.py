"""沟通策略引擎：以「顶尖 HR 换位思考」的视角生成求职沟通话术。

四个能力：
- 打招呼语（hello）：5 种风格，含「热情示好（舔狗式）」，含 HR 视角洞察与避雷提示
- HR 回复应答（reply）：7 种 HR 常见场景 × 3 种语气，先解读 HR 真实意图再给话术
- 已读不回追问（followup）：3 轮递进，从轻量提醒 → 带新信息 → 体面收尾
- 不匹配诊断（diagnose）：区分「简历没写好」和「能力真缺」，给 30 天提升计划

设计原则：
1. 真人感：短句、口语、有称呼、手机一屏能看完（60-120 字），不写书面八股
2. 真实：只引用简历里真实存在的经历，不虚构公司名、数字、成果
3. 有分寸：热情示好可以低头，但自尊不丢——「配合度高」≠「随便给」
两条模式：LLM 优先（更贴 JD），规则兜底（离线可用）
"""
from __future__ import annotations

import logging
import re
from typing import Any

from app import llm
from app.config import settings
from app.schemas import (
    ChatHelloResult,
    ChatReplyResult,
    ChatScript,
    DiagnoseResult,
    FollowupResult,
    GapAdvice,
    JDParsed,
    MatchAnalysis,
    ResumeParsed,
)
from app.tools.rule_engine import (
    _best_highlight,
    _clean_highlight,
    analyze_match_rule,
    parse_jd_rule,
    parse_resume_rule,
)

logger = logging.getLogger("resume-agent.chat_coach")

# ================================================================ HR 视角洞察
# 站在 HR 的角度：每天几十上百条消息，平均 2 秒决定点不点开
HR_INSIGHT = (
    "HR 扫一条打招呼消息只有 2 秒：第一行没料 → 直接划走。"
    "他们真正在意的是「你能不能干活、来了能不能上手」，不是你多想学习。"
    "所以：把最强的一句经历放前面、带上岗位 JD 里的关键词、说清到岗时间和薪资态度，回复率最高。"
)

AVOID_LIST = [
    "「请问贵司还招人吗」——海投感最强，等于告诉 HR 你没做功课",
    "长篇自我介绍 + 整段经历复制——HR 不会读，只会觉得你不会沟通",
    "空喊「我学习能力强/我很热爱」——没有证据的形容词一律当废话",
    "一上来问薪资福利作息——顺序错了，先证明价值再谈条件",
    "群发模板连公司名、岗位名都不改——一眼看穿，直接进黑名单",
]


def _fmt_kws(words: list[str], n: int = 3) -> str:
    ws = [w for w in words if w]
    return "、".join(ws[:n]) if ws else "相关技术"


def _role_clean(role: str) -> str:
    return re.sub(r"（[^）]*）|\([^)]*\)", "", role or "").strip() or "贵司在招岗位"


def _company_of(jd: JDParsed) -> str:
    """从 JD 首行/原文里猜公司名，猜不到就用中性称呼。"""
    m = re.search(r"公司[:：]\s*([^\n，,。]{2,20})", jd.raw_text)
    if m:
        return m.group(1).strip()
    hint = (jd.company_hint or "").strip()
    hint = re.sub(r"公司[:：]?", "", hint).strip()
    if hint and len(hint) <= 20 and "招聘" not in hint:
        return hint
    return "贵司"


def _sp(text: str) -> str:
    """中文与英文/数字之间补一个空格。

    真人用手机精心编辑的消息通常排版干净，中英文挤在一起会显得像机器生成的。
    """
    text = re.sub(r"([\u4e00-\u9fa5])([A-Za-z0-9])", r"\1 \2", text)
    text = re.sub(r"([A-Za-z0-9])([\u4e00-\u9fa5])", r"\1 \2", text)
    return text


def _script(style: str, tone: str, content: str, tip: str) -> ChatScript:
    content = re.sub(r"\n{3,}", "\n\n", content).strip()
    content = _sp(content)
    # 截断产生的省略号后面不要紧跟标点（「…。」「…）」读起来很别扭）
    content = content.replace("…。", "…").replace("…，", "…").replace("…、", "…")
    content = content.replace("…）", "）").replace("…)", ")")
    return ChatScript(style=style, tone=tone, content=content, tip=tip, chars=len(content))


def _short_hl(hl: str, limit: int = 22) -> str:
    """亮点句在话术里要短——整句塞进去会把消息撑成一大坨。"""
    hl = (hl or "").strip()
    if not hl:
        return ""
    return hl if len(hl) <= limit else hl[:limit].rstrip("，,。、") + "…"


# ================================================================ 一、打招呼语
def generate_hellos_rule(
    jd: JDParsed, resume: ResumeParsed, analysis: MatchAnalysis
) -> ChatHelloResult:
    name = (resume.name or "").strip()
    role = _role_clean(jd.role)
    company = _company_of(jd)
    matched = [r.keyword for r in analysis.matched if r.weight in ("高", "中")]
    kws = _fmt_kws(matched, 3)
    hl_full = _best_highlight(resume, [r.keyword for r in analysis.matched])
    if not hl_full:
        hl_full = _clean_highlight(_first_experience_line(resume))
    hl = _short_hl(hl_full)  # 话术里用短版，避免把消息撑成一坨
    kw1, kw2 = (matched + ["核心技术", "业务落地"])[:2]

    scripts: list[ChatScript] = []

    # 1) 简洁专业版：三行说清"我是谁/能干啥/要什么"
    c1 = (
        f"您好，我是{name}，应聘{role}。\n"
        f"{kws}这几个方向我在真实项目里都用过"
        + (f"，{hl}" if hl else "")
        + "。\n方便的话想和您进一步沟通，盼回复。"
    )
    scripts.append(_script(
        "简洁专业版", "专业", c1,
        "三行内讲完「我是谁 / 我能干啥 / 我要什么」，HR 两秒扫完就懂，是回复率最高的写法。",
    ))

    # 2) 亮点冲击版：最强经历放首行
    c2 = (
        f"{hl or '我做过一段和这个岗位比较对口的项目'}。\n"
        f"——这段经历和贵司{role}要求的{kws}比较对口，我是{name}，想争取这个岗位的机会。"
    )
    scripts.append(_script(
        "亮点冲击版", "专业", c2,
        "聊天列表只显示首行，开头没料直接被划走。把最硬的一句经历放第一行，点开率明显更高。",
    ))

    # 3) 诚恳真诚版：主动承认劣势，再用证据拉回注意力
    c3 = (
        f"您好，我是{name}。坦白说我在资历上不算最突出的，但{kws}这些是实打实做过项目的"
        + (f"（{hl}）" if hl else "")
        + "，上手会比较快，也不怕啃新东西。\n很想争取一个沟通机会，麻烦您了！"
    )
    scripts.append(_script(
        "诚恳真诚版", "诚恳", c3,
        "应届/转行首选。主动承认短板反而降低 HR 防备，紧接着用「具体做过什么」把注意力拉回能力。",
    ))

    # 4) 热情示好版（舔狗式）：具体夸 + 配合度高，但自尊不丢
    c4 = (
        f"您好～关注{company}有一段时间了，{role}这个方向我很感兴趣。\n"
        f"我的{kws}和岗位要求比较匹配，到岗时间和薪资都可以配合商量。\n"
        "特别希望能有机会跟您聊聊，麻烦您抽空看看，谢谢！"
    )
    scripts.append(_script(
        "热情示好版", "热情", c4,
        "核心是「具体夸 + 愿意配合」，不是空喊贵司很好。提到公司名/业务方向，HR 一眼看出不是海投。"
        "分寸：说「可以商量」而不是「随便给」，后者只会显得不自信。",
    ))

    # 5) 提问互动版：把推销变成请教
    c5 = (
        f"您好，我是{name}，想应聘{role}。\n"
        f"想先请教一下：这个岗位目前更偏{kw1}还是{kw2}？\n"
        f"我之前的经验主要在{kws}这一块，想确认下匹配度再正式投递，麻烦您了。"
    )
    scripts.append(_script(
        "提问互动版", "诚恳", c5,
        "用一个具体问题开场，把「推销」变成「请教」。HR 更愿意回答一个问题，而不是直接答应约面试。",
    ))

    return ChatHelloResult(
        llm_mode=False,
        role=role,
        company=company,
        matched_keywords=matched[:6],
        highlight=hl_full,
        scripts=scripts,
        hr_insight=HR_INSIGHT,
        avoid=AVOID_LIST,
    )


def _first_experience_line(resume: ResumeParsed) -> str:
    for sec in resume.sections:
        if any(k in sec.title for k in ("项目", "实习", "工作")):
            for line in sec.lines:
                if re.match(r"^[-*•·]\s*", line) and len(line) > 8:
                    return line
    return "有完整的项目落地经历"


# ================================================================ 二、HR 回复话术
# key -> 场景（HR 真实意图 + 3 种语气话术）
REPLY_SCENARIOS: dict[str, dict[str, Any]] = {
    "ask_resume": {
        "label": "HR 要简历（「发份简历看看」）",
        "intent": "没拒绝就是好信号，说明你的开场有吸引力。这一轮的目标是「降低他的阅读成本」——别只甩一个附件就完事。",
        "scripts": [
            ("专业型", "专业",
             "好的，简历已发送，您查收一下。\n里面有{kws}相关的项目细节，重点可以看「项目经历」那部分。\n有问题随时问我。",
             "主动告诉他「重点看哪」，替 HR 省时间，也暗示你懂岗位重点。"),
            ("诚恳型", "诚恳",
             "好的！简历已发，麻烦您了～\n如果哪里写得不清楚，或者想了解某个项目的更多细节，我可以再整理一份给您。",
             "留一个「我可以继续补充」的口子，给 HR 接话的空间。"),
            ("热情型", "热情",
             "好的～已发送，您方便的时候看看就行。\n如果想了解哪块细节我随时补充，需要的话我也可以整理个作品链接给您，您看着方便！",
             "把主动权交给对方（「您方便时」），热情但不催。"),
        ],
    },
    "ask_available": {
        "label": "HR 问到岗时间",
        "intent": "在判断你的「即用性」。多数岗位想尽快到岗：回答要给具体时间 + 留弹性，别只说「随时」显得敷衍。",
        "scripts": [
            ("专业型", "专业",
             "我这边比较灵活，收到 offer 后 3-5 天可以到岗，交接需要的话也能配合。",
             "给一个具体数字，HR 才好排期；再补一句能配合，显示好沟通。"),
            ("诚恳型", "诚恳",
             "目前时间上是空的，一周内就能到岗，如果需要提前也可以协调，主要看您的安排。",
             "强调「看您安排」，把决定权给 HR，沟通成本最低。"),
            ("热情型", "热情",
             "时间上完全以你们的安排为准，我这边随时都可以，没有任何负担～您定就行！",
             "姿态放到最低，适合你真的很想要这个机会、且时间确实自由时用。"),
        ],
    },
    "ask_salary": {
        "label": "HR 问期望薪资",
        "intent": "在看你的期望是否在预算内，同时试探你的自我定价。标准动作：给区间 + 留余地，别报死数、别回避。",
        "scripts": [
            ("专业型", "专业",
             "我期望在 X–Y 这个区间（按当地同岗位水平填）。\n不过我更看重岗位做的事和成长空间，有空间的话都可以聊。",
             "区间 + 一句「可以聊」，既表态又不把话说死。X–Y 记得按你的目标薪资填真实值。"),
            ("诚恳型", "诚恳",
             "薪资这块我没有硬性要求，更想先把事情做好。\n按贵司的薪酬体系来就行，我相信做出来公司会看到的。",
             "适合应届/转行期，用态度换机会。风险是被压价，确认自己能接受再用。"),
            ("热情型", "热情",
             "薪资我不是很在意，更想先把这个机会拿到、把活干好。\n您按公司的标准定就可以，我都可以接受～",
             "示好拉满。仅在「这份工作本身的价值 > 短期薪资」时使用，比如大厂机会、想转的方向。"),
        ],
    },
    "invite_interview": {
        "label": "HR 约面试",
        "intent": "已经是明确意向了。这一轮只有一个目标：把时间敲定。别啰嗦、别临时加问题。",
        "scripts": [
            ("专业型", "专业",
             "可以的，我这边时间比较灵活。\n您看周几方便？我把时间空出来，提前做好准备。",
             "确认 + 反问时间，一步到位。"),
            ("诚恳型", "诚恳",
             "好的，谢谢您给机会！\n时间我这边都能配合，您定就行，我会提前把相关项目的细节理一遍。",
             "加一句「会提前准备」，让 HR 觉得你重视。"),
            ("热情型", "热情",
             "好的好的！随时都可以，您定时间我一定到～\n需要我提前准备什么（作品、项目说明）也可以告诉我，麻烦您安排了！",
             "热情 + 主动要准备清单，印象分很高。"),
        ],
    },
    "ask_background": {
        "label": "HR 质疑学历 / 经验年限",
        "intent": "多半是学历或年限成了顾虑。硬解释没用，标准动作是「承认 → 用证据转移注意力」。",
        "scripts": [
            ("专业型", "专业",
             "坦白说学历/年限这块我确实不占优势，我不回避。\n不过{kws}这些都是真实项目里用过的，细节我可以讲清楚，也可以现场演示。",
             "先认，再立刻把话题拽回「我能做什么」，并给一个可验证的承诺（讲细节/演示）。"),
            ("诚恳型", "诚恳",
             "是的，我资历确实浅一些。但我上手快，之前的项目也是从零跟到交付的。\n希望能给我个机会证明一下，谢谢您！",
             "「从零跟到交付」是应届最有力的证据——说明你跑过完整流程，不是只做过 demo。"),
            ("热情型", "热情",
             "确实，这块是我的短板，我认。\n但我肯学、也不挑活，给我一两周就能顶上。要不您给我个小任务试试？",
             "敢用「小任务」自证，是这类处境下最有效的一招；多数 HR 会因此多看你一眼。"),
        ],
    },
    "doubt_match": {
        "label": "HR 说「你没有 X 经验」",
        "intent": "这不是拒绝，是在给你一个说服他的机会。标准动作：承认缺口 → 说清迁移能力 → 给证据或行动承诺。",
        "scripts": [
            ("专业型", "专业",
             "您说得对，这块我确实没有正式项目经验。\n不过我在{kws}上有实践，底层思路是相通的，上手会比较快，我也有相关 demo 可以看。",
             "别硬杠「我学过」。承认 + 讲迁移 + 拿证据，才是成熟候选人的反应。"),
            ("诚恳型", "诚恳",
             "这块确实是我的短板，我认。\n我学东西比较快，给我一两周能补上来——如果可以的话，我做个小 demo 发给您看看？",
             "把「我不会」翻译成「我多久能会」，并主动交付一个可验证的东西。"),
            ("热情型", "热情",
             "您说得对，这块我确实还差一点。\n不过我真的很想争取这个机会，要不我周末补一下，做个相关的东西发给您看看？麻烦您了！",
             "愿意用私人时间补足 + 主动交付，诚意拉满。只在确实会去做的时候说。"),
        ],
    },
    "reject": {
        "label": "HR 婉拒（「不太合适」）",
        "intent": "九成是真不合适，但你的回应决定了「还有没有下次」。目标：体面收尾 + 留后路。",
        "scripts": [
            ("专业型", "专业",
             "理解的，感谢您抽空看我的简历。\n方便的话想请教下主要差在哪方面，我后面好针对性补强。祝招聘顺利～",
             "要一句反馈，是把拒绝变成信息。很多 HR 愿意说真话，这是免费的复盘。"),
            ("诚恳型", "诚恳",
             "好的，谢谢您告诉我。虽然有点遗憾，但还是感谢您花的时间。祝您招聘顺利！",
             "不纠缠、不追问，干净利落，留下好印象。"),
            ("热情型", "热情",
             "好的，谢谢您的回复～\n虽然这次没成，还是很感谢您。如果后面有更合适的岗位，希望您还能想到我，我会一直关注贵司的。祝您工作顺利！",
             "留后路的标准写法：表达持续关注，但不纠缠。同一家公司换岗再投是很常见的事。"),
        ],
    },
}

SCENARIO_ALIASES: dict[str, str] = {
    "简历": "ask_resume", "发简历": "ask_resume", "resume": "ask_resume",
    "到岗": "ask_available", "入职": "ask_available", "时间": "ask_available",
    "薪资": "ask_salary", "工资": "ask_salary", "期望": "ask_salary",
    "面试": "invite_interview", "面聊": "invite_interview",
    "学历": "ask_background", "经验": "ask_background", "年限": "ask_background",
    "不合适": "reject", "拒绝": "reject", "婉拒": "reject", "不符": "reject",
}


def draft_reply_rule(
    scenario: str, jd: JDParsed, resume: ResumeParsed, analysis: MatchAnalysis
) -> ChatReplyResult:
    key = SCENARIO_ALIASES.get(scenario.strip(), scenario if scenario in REPLY_SCENARIOS else "ask_resume")
    conf = REPLY_SCENARIOS[key]
    matched = [r.keyword for r in analysis.matched if r.weight in ("高", "中")]
    kws = _fmt_kws(matched, 3)

    scripts = [
        _script(style, tone, text.replace("{kws}", kws), tip)
        for style, tone, text, tip in conf["scripts"]
    ]
    return ChatReplyResult(
        llm_mode=False,
        scenario=key,
        scenario_label=conf["label"],
        hr_intent=conf["intent"],
        scripts=scripts,
    )


# ================================================================ 三、已读不回追问
FOLLOWUP_ROUNDS: dict[int, dict[str, Any]] = {
    1: {
        "timing": "首条消息发出 1–2 天后",
        "note": "第一轮只做「轻量提醒」：给对方一个「消息太多刷过去了」的台阶，不质问、不催、不卖惨。",
        "scripts": [
            ("轻量提醒", "诚恳",
             "您好，怕您消息多刷过去了，再来打扰一下～\n我对{role}这个岗位确实挺感兴趣的"
             + "（{hl}）" + "。\n方便的话希望有机会聊聊，不方便也没关系，祝您顺利！",
             "关键词是「不方便也没关系」——给 HR 台阶，反而更容易得到回复。"),
            ("热情跟进", "热情",
             "您好～又来打扰了，知道您比较忙。\n就是想让您知道我这边一直在关注{role}这个岗位，时间上也都配合。\n如果有机会的话希望能聊聊，麻烦您了！",
             "表达「一直在等」，适合你确实很想进这家公司时用。"),
        ],
    },
    2: {
        "timing": "第 1 轮之后再等 3–4 天",
        "note": "第二轮必须带来「新信息」——作品、进展、补充材料。否则就是重复骚扰，只会减分。",
        "scripts": [
            ("带新信息", "专业",
             "您好，又来打扰了。\n这两天我把项目里{kws}相关的部分又整理了一遍，做了一份更细的说明，如果您有空可以看看。\n还是很想争取这个机会～",
             "「我又做了点东西」比「您考虑得怎么样」有效十倍——前者是价值，后者是压力。"),
            ("热情跟进", "热情",
             "您好，再次打扰～\n我这两天把和岗位相关的项目又复盘了一下，整理了更详细的实现思路，您方便的话我可以发您看看。\n麻烦您了，谢谢！",
             "用「复盘/整理」体现主动性，同时不要求对方立刻回复。"),
        ],
    },
    3: {
        "timing": "第 2 轮之后再等 5–7 天（累计约两周）",
        "note": "第三轮是收尾：留下好印象、留好后路，然后彻底停下。发完这轮还追，就真的成骚扰了。",
        "scripts": [
            ("体面收尾", "诚恳",
             "您好，最后一次打扰～\n如果暂时不考虑也完全没关系，非常感谢您之前的时间。\n如果后续有更合适的岗位，希望还能有机会。祝您招聘顺利！",
             "「最后一次打扰」是明确的信号，HR 看了反而会觉得你体面、懂分寸。"),
            ("留后路", "专业",
             "您好，冒昧再打扰一次。\n这个岗位如果有更合适的人选完全理解，感谢您的时间。\n后面如果还有匹配的机会，希望您能想到我，我会持续关注贵司的。祝好！",
             "把这次接触存成长期资产——同一家公司换岗再投，成功率远高于冷启动。"),
        ],
    },
}


def draft_followup_rule(
    round_no: int, jd: JDParsed, resume: ResumeParsed, analysis: MatchAnalysis
) -> FollowupResult:
    rnd = FOLLOWUP_ROUNDS.get(round_no, FOLLOWUP_ROUNDS[1])
    role = _role_clean(jd.role)
    matched = [r.keyword for r in analysis.matched if r.weight in ("高", "中")]
    kws = _fmt_kws(matched, 3)
    hl = _short_hl(
        _best_highlight(resume, [r.keyword for r in analysis.matched]) or _first_experience_line(resume)
    )

    scripts = [
        _script(style, tone, text.replace("{role}", role).replace("{hl}", hl).replace("{kws}", kws), tip)
        for style, tone, text, tip in rnd["scripts"]
    ]
    return FollowupResult(
        llm_mode=False,
        round_no=round_no,
        timing=rnd["timing"],
        scripts=scripts,
        closing_note=rnd["note"],
    )


# ================================================================ 四、不匹配诊断
def diagnose_gaps_rule(
    jd: JDParsed, resume: ResumeParsed, analysis: MatchAnalysis
) -> DiagnoseResult:
    role = _role_clean(jd.role)
    score = analysis.overall_score
    matched_kws = [r.keyword for r in analysis.matched]

    hard: list[GapAdvice] = []
    soft: list[GapAdvice] = []

    for r in analysis.missing:
        if r.weight == "高":
            hard.append(GapAdvice(
                keyword=r.keyword, weight="高", kind="能力补强",
                advice=f"JD 把「{r.keyword}」放在高优先级，而简历里完全没有出现——这是 HR 筛简历时的硬扣分项。",
                action=f"两周内做一个用到 {r.keyword} 的小项目（哪怕只是 demo），写进「项目经历」，或至少在技能栏如实标注「了解/正在学」。",
            ))
        elif r.weight == "中":
            soft.append(GapAdvice(
                keyword=r.keyword, weight="中", kind="简历包装",
                advice=f"「{r.keyword}」在 JD 里被提到，简历没写。有可能你会但没写上去，这是最可惜的丢分项。",
                action=f"回忆是否用过：用过就补进技能栏 + 在项目描述里点出一次使用场景；没用过就花 3 天看官方文档跑通最小示例，再写「了解」。",
            ))

    # 表达层面的通用短板
    no_number = not re.search(r"\d", resume.all_text)
    if no_number:
        soft.append(GapAdvice(
            keyword="缺少量化结果", weight="高", kind="表达优化",
            advice="整份简历没有一个数字。HR 对「负责了 XX」无感，只对「把 XX 从 3 小时降到 20 分钟」有反应。",
            action="逐条项目回问自己：做了多少、快了多少、省了多少人天？哪怕是「写了 30 个用例、发现 12 个缺陷」也比没有强。",
        ))
    if len(matched_kws) < 3:
        soft.append(GapAdvice(
            keyword="JD 关键词对齐不足", weight="高", kind="简历包装",
            advice=f"只命中 {len(matched_kws)} 个 JD 关键词。机器初筛和人眼扫简历，都是先找关键词。",
            action="把 JD 里的技术词列出来，逐个对照：会的放进技能栏前排，不会的挑 2 个最关键的先补 demo。",
        ))

    # 30 天计划
    plan: list[str] = []
    top_hard = [g.keyword for g in hard[:2]]
    top_soft = [g.keyword for g in soft[:2]]
    if top_hard:
        plan.append(f"第 1–2 周：集中补 {('、'.join(top_hard))}。每天 2 小时，目标是跑通一个能讲清楚的最小项目，而不是看完教程。")
    if top_soft:
        plan.append(f"第 2 周：把 {('、'.join(top_soft))} 补进简历。会用的写清场景，只了解的就如实写「了解」，不装熟练。")
    plan.append("第 3 周：给每个项目补上数字（数量/耗时/性能提升/人天），没有真实数字就回去问当时的同事或翻记录，绝不编造。")
    plan.append("第 4 周：用本系统的「简历优化」针对 3 家目标公司各出一版，逐条看命中率；同时用「面试准备」把高频题过一遍。")
    plan.append("贯穿全程：把每个补强的项目同步到 GitHub，README 写清「做了什么、用了什么技术、遇到什么问题」。这是应届生唯一能对抗经验劣势的证据。")

    # HR 会怎么处理这份简历
    if score >= 70:
        verdict = "匹配度不错，HR 大概率会点开细看。这时候拼的是项目细节——把每个技术点的「为什么这么做」准备好，别在追问里露怯。"
    elif score >= 50:
        verdict = "能过初筛，但不够亮眼，属于「可有可无」的那一档。建议先补齐前 2 个高优先关键词再投，性价比更高。"
    elif score >= 30:
        verdict = "对齐度偏低，直接海投容易被刷。这份简历更适合内推或先按下面的计划补一轮，否则投 20 家也是沉没成本。"
    else:
        verdict = "当前这份简历投这个岗位性价比不高。要么换更匹配的方向投，要么集中火力补 1–2 个硬缺口再回来——方向比努力重要。"

    summary = (
        f"JD 共识别 {len(analysis.matched) + len(analysis.missing)} 项要求，命中 {len(analysis.matched)} 项、"
        f"缺失 {len(analysis.missing)} 项，综合匹配 {score} 分。"
        + (f"硬伤 {len(hard)} 项（高优先要求完全没有），可包装项 {len(soft)} 项。" if hard or soft else "")
    )

    return DiagnoseResult(
        llm_mode=False, role=role, score=score,
        hard_gaps=hard, soft_gaps=soft, plan_30d=plan,
        summary=summary, hr_verdict=verdict,
    )


# ================================================================ LLM 模式
_PERSONA = (
    "你是一位有 10 年经验的顶尖 HR，同时也是求职沟通专家。你非常清楚 HR 每天收到上百条消息时"
    "是怎么在 2 秒内决定点不点开的，也清楚候选人的哪些话会让 HR 反感。现在请站在 HR 的视角，"
    "为候选人生成沟通话术。\n"
    "硬性要求：\n"
    "1. 像真人打字：短句、口语化、有称呼，单条 60-120 字，手机一屏能看完；不要书面八股和排比句。\n"
    "2. 只使用候选人简历中真实存在的经历、技术、项目，禁止虚构公司名、数字和成果。\n"
    "3. 「热情示好」风格要有分寸：可以表达认可、配合度高，但不可自贬、不可卑微，不可说「随便给」。\n"
    "4. 每条话术都要给 tip：一句话说明「为什么这样写」或「注意什么」。\n"
)


async def _llm_json(system: str, user: str) -> dict | None:
    try:
        return await llm.chat_json(
            [{"role": "system", "content": system}, {"role": "user", "content": user}]
        )
    except Exception as e:  # noqa: BLE001
        logger.warning("LLM 生成失败，回退规则模式: %s", e)
        return None


async def generate_hellos_llm(
    jd: JDParsed, resume: ResumeParsed, analysis: MatchAnalysis
) -> ChatHelloResult | None:
    matched = [r.keyword for r in analysis.matched if r.weight in ("高", "中")]
    hl = _best_highlight(resume, [r.keyword for r in analysis.matched])
    user = (
        f"目标岗位：{jd.role}\n公司：{_company_of(jd)}\nJD 原文：\n{jd.raw_text[:1200]}\n\n"
        f"候选人姓名：{resume.name}\n简历原文：\n{resume.raw_text[:1500]}\n\n"
        f"已命中的 JD 关键词：{', '.join(matched[:8])}\n最强亮点句：{hl}\n\n"
        "请生成 5 条打招呼语，风格依次为：简洁专业版、亮点冲击版、诚恳真诚版、热情示好版（舔狗式）、提问互动版。\n"
        "返回 JSON：{\"scripts\":[{\"style\":\"\",\"tone\":\"专业/诚恳/热情\",\"content\":\"\",\"tip\":\"\"}],"
        "\"hr_insight\":\"一句话 HR 视角洞察\"}"
    )
    data = await _llm_json(_PERSONA, user)
    if not data or not data.get("scripts"):
        return None
    scripts = [
        _script(s.get("style", f"版本{i+1}"), s.get("tone", ""), s.get("content", ""), s.get("tip", ""))
        for i, s in enumerate(data["scripts"]) if s.get("content")
    ]
    if not scripts:
        return None
    return ChatHelloResult(
        llm_mode=True, role=_role_clean(jd.role), company=_company_of(jd),
        matched_keywords=matched[:6], highlight=hl, scripts=scripts,
        hr_insight=data.get("hr_insight", HR_INSIGHT), avoid=AVOID_LIST,
    )


async def draft_reply_llm(
    scenario: str, hr_message: str, jd: JDParsed, resume: ResumeParsed, analysis: MatchAnalysis
) -> ChatReplyResult | None:
    matched = [r.keyword for r in analysis.matched if r.weight in ("高", "中")]
    base = REPLY_SCENARIOS.get(scenario, REPLY_SCENARIOS["ask_resume"])
    user = (
        f"岗位：{jd.role}\n候选人：{resume.name}\n已命中关键词：{', '.join(matched[:8])}\n"
        f"简历要点：{resume.raw_text[:1000]}\n\n"
        f"HR 说的话/场景：{hr_message or base['label']}\n\n"
        "请先用一句话解读 HR 这句话背后的真实意图（hr_intent），"
        "然后给 3 条回复话术，语气依次为：专业型、诚恳型、热情型（舔狗式）。\n"
        "返回 JSON：{\"hr_intent\":\"\",\"scripts\":[{\"style\":\"\",\"tone\":\"\",\"content\":\"\",\"tip\":\"\"}]}"
    )
    data = await _llm_json(_PERSONA, user)
    if not data or not data.get("scripts"):
        return None
    scripts = [
        _script(s.get("style", f"版本{i+1}"), s.get("tone", ""), s.get("content", ""), s.get("tip", ""))
        for i, s in enumerate(data["scripts"]) if s.get("content")
    ]
    if not scripts:
        return None
    return ChatReplyResult(
        llm_mode=True, scenario=scenario, scenario_label=base["label"],
        hr_intent=data.get("hr_intent", base["intent"]), scripts=scripts,
    )


# ================================================================ 编排入口（LLM 优先 + 规则兜底）
async def generate_hellos(jd_raw: str, resume_raw: str) -> ChatHelloResult:
    jd = parse_jd_rule(jd_raw)
    resume = parse_resume_rule(resume_raw)
    analysis = analyze_match_rule(jd, resume)
    if settings.llm_enabled:
        r = await generate_hellos_llm(jd, resume, analysis)
        if r:
            return r
    return generate_hellos_rule(jd, resume, analysis)


async def draft_reply(jd_raw: str, resume_raw: str, scenario: str, hr_message: str = "") -> ChatReplyResult:
    jd = parse_jd_rule(jd_raw)
    resume = parse_resume_rule(resume_raw)
    analysis = analyze_match_rule(jd, resume)
    key = SCENARIO_ALIASES.get(scenario.strip(), scenario if scenario in REPLY_SCENARIOS else "ask_resume")
    if settings.llm_enabled:
        r = await draft_reply_llm(key, hr_message, jd, resume, analysis)
        if r:
            return r
    return draft_reply_rule(key, jd, resume, analysis)


async def draft_followup(jd_raw: str, resume_raw: str, round_no: int = 1) -> FollowupResult:
    jd = parse_jd_rule(jd_raw)
    resume = parse_resume_rule(resume_raw)
    analysis = analyze_match_rule(jd, resume)
    return draft_followup_rule(round_no, jd, resume, analysis)


async def diagnose_gaps(jd_raw: str, resume_raw: str) -> DiagnoseResult:
    jd = parse_jd_rule(jd_raw)
    resume = parse_resume_rule(resume_raw)
    analysis = analyze_match_rule(jd, resume)
    return diagnose_gaps_rule(jd, resume, analysis)
