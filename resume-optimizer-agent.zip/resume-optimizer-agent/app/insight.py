"""数据洞察引擎：让每次解析沉淀下来的数据，真正反哺简历优化。

闭环设计：
    每次 JD×简历解析 ──存档──▶ parse_runs 快照
                                    │
                    ┌───────────────┼───────────────┐
                    ▼               ▼               ▼
             ① 缺陷追踪        ② 项目推荐        ③ 竞争力评估
        （反复缺什么 = 真短板） （按 JD 挑最贴的项目） （分数趋势 + 短板变化）

三个能力都不是"看单次结果"，而是**看历史积累**：
- 缺陷追踪：同一个关键词在多次解析中反复缺失 = 长期短板，优先级按「权重 × 频次 × 连续次数」排
- 项目推荐：项目库 × JD 关键词匹配打分，并给出「这个项目描述该怎么改才更贴 JD」
- 竞争力：历史分数趋势 + 缺陷改善情况 + 项目覆盖度，输出下一步最该做的一件事

两条模式：LLM 优先（建议更个性化），规则兜底（离线可用）
"""
from __future__ import annotations

import json
import logging
import re
from typing import Any

from app import db, llm
from app.config import settings
from app.schemas import (
    Competitiveness,
    DefectItem,
    DefectReport,
    ProjectAdvice,
    ProjectRecommendation,
)
from app.tools.rule_engine import extract_keywords, parse_jd_rule

logger = logging.getLogger("resume-agent.insight")

_WEIGHT_SCORE = {"高": 3.0, "中": 2.0, "低": 1.0}

# 简历里最常见的「表达层」缺陷（与具体 JD 无关，任何时候都值得改）
_EXPRESSION_CHECKS: list[tuple[str, str, str]] = [
    ("缺少量化结果", lambda t: not re.search(r"\d", t),
     "整份简历没有一个数字。HR 对「负责 XX」无感，只对「把耗时从 3 小时降到 20 分钟」有反应。"),
    ("项目描述偏职责、缺成果", lambda t: t.count("负责") >= 2 and "提升" not in t and "降低" not in t,
     "多个条目都是「负责 XX」，看不出做成了什么。每条补一个结果：快了多少、省了多少、覆盖多少用户。"),
    ("没有作品/代码链接", lambda t: not re.search(r"github|github\.com|掘金|博客|作品集|https?://", t, re.I),
     "简历里没有可验证的链接。应届生对抗经验劣势的唯一办法，就是让 HR 能点进去看你的代码。"),
    ("技能栏未分层", lambda t: bool(re.search(r"技能", t)) and not re.search(r"熟练|精通|掌握|了解", t),
     "技能只列名词没标程度，HR 无法判断深浅。建议分「熟练 / 掌握 / 了解」三层，如实标注。"),
]

# JD 要求但没有对应项目时，建议补做的练手项目（贴合 AI 应用 / 后端方向）
_PROJECT_IDEAS: dict[str, str] = {
    "RAG": "企业知识库问答系统：文档解析 → 分块 → 向量化 → 检索 + 重排序 → FastAPI 对外问答接口，附带准确率评测脚本",
    "Agent": "多工具 Agent 助手：用 LangGraph 做任务编排，接入搜索/计算器/数据库等工具，实现 tool calling 与多轮记忆",
    "向量数据库": "向量检索服务：FAISS / Milvus 搭建百万级向量召回，对比不同索引类型的延迟与召回率，输出压测报告",
    "模型微调": "LoRA 微调实战：用垂直领域数据微调 Qwen，对比微调前后在该领域的回答质量，附训练日志与样例",
    "模型部署": "大模型推理服务部署：vLLM 部署 Qwen + Docker 容器化 + 并发压测，优化 KV-Cache 显存占用，出性能报告",
    "推理优化": "推理性能优化：量化（GPTQ/AWQ）+ 批处理 + KV-Cache 复用，把 P99 延迟和显存占用做成对比图表",
    "Prompt工程": "Prompt 版本管理与 A/B 评测：同一任务多版 Prompt 自动打分对比，沉淀可复用的提示词模板库",
    "LangChain": "LangChain 链路实战：实现一个带记忆、引用溯源和流式输出的文档问答应用",
    "LangGraph": "LangGraph 状态机应用：把「需求分析 → 检索 → 生成 → 自检」做成带条件分支与人工确认的图编排",
    "FastAPI": "高并发接口服务：FastAPI + 异步 + Redis 缓存 + 限流，JMeter 压测并输出 QPS/延迟报告",
    "Docker": "CI/CD 流水线：GitHub Actions 自动构建镜像 → 推送 → 服务器部署，附流水线配置与回滚方案",
    "自动化测试": "接口自动化框架：pytest + requests + Allure 报告，覆盖登录态、参数校验、异常场景",
    "数据分析": "数据分析看板：pandas 清洗业务数据 + 可视化图表 + 自动日报邮件",
    "Elasticsearch": "全文检索服务：ES 索引设计 + 中文分词 + 高亮与排序调优，对比 LIKE 查询的性能差异",
    "Kubernetes": "K8s 部署实践：Deployment/Service/Ingress 编排应用，配置 HPA 自动扩缩容与就绪探针",
    "Redis": "缓存体系设计：缓存穿透/击穿/雪崩三件套方案落地，附压测前后对比",
}


def _load_missing(run: dict) -> list[dict]:
    try:
        return json.loads(run.get("missing") or "[]")
    except Exception:  # noqa: BLE001
        return []


# ================================================================ ① 缺陷追踪
def analyze_defects_rule(runs: list[dict], resume_text: str = "") -> DefectReport:
    """聚合历史解析的 missing 项：频次 + 连续缺失次数 + 是否已改善。"""
    total = len(runs)
    if not total:
        return DefectReport(
            llm_mode=False, total_runs=0, summary="还没有解析记录 —— 先去「简历优化」跑一次，系统会自动存档",
            top_action="跑一次简历优化，之后每次解析都会沉淀成可追踪的数据",
        )

    # runs 是按 id DESC 排的（新的在前），翻转为时间正序便于算 streak
    ordered = list(reversed(runs))
    stat: dict[str, dict[str, Any]] = {}
    for idx, run in enumerate(ordered):
        for m in _load_missing(run):
            kw = (m.get("keyword") or "").strip()
            if not kw:
                continue
            w = m.get("weight", "中")
            s = stat.setdefault(kw, {"weight": w, "count": 0, "last_idx": idx, "streak": 0, "cur": 0})
            s["count"] += 1
            s["last_idx"] = idx
            # 连续计数：与上一次解析相邻才累加
            s["cur"] = s["cur"] + 1 if s.get("prev_idx") == idx - 1 else 1
            s["prev_idx"] = idx
            s["streak"] = max(s.get("streak", 0), s["cur"])

    last_idx_total = len(ordered) - 1
    defects: list[DefectItem] = []
    improved: list[str] = []
    for kw, s in stat.items():
        is_improved = s["last_idx"] < last_idx_total  # 最近一次不再缺失
        if is_improved:
            improved.append(kw)
        w = s["weight"]
        priority = round(_WEIGHT_SCORE.get(w, 2.0) * s["count"] * (1 + 0.2 * max(0, s["streak"] - 1)), 1)
        if is_improved:
            priority *= 0.3  # 已改善的降权
        defects.append(DefectItem(
            keyword=kw, weight=w, count=s["count"], streak=s["streak"],
            improved=is_improved, priority=priority,
            advice=_defect_advice(kw, w, s["count"], s["streak"], is_improved),
        ))

    defects.sort(key=lambda d: d.priority, reverse=True)

    # 表达层缺陷（与 JD 无关，基于最新简历文本判断）
    for name, test, msg in _EXPRESSION_CHECKS:
        if resume_text and test(resume_text):
            defects.append(DefectItem(
                keyword=name, weight="高", count=len(ordered), streak=len(ordered),
                improved=False, priority=_WEIGHT_SCORE["高"] * len(ordered),
                advice=msg,
            ))

    top = defects[0] if defects else None
    summary = (
        f"基于 {total} 次解析记录：发现 {len([d for d in defects if not d.improved])} 项待补短板、"
        f"{len(improved)} 项已改善。"
        + (f"最该先补的是「{top.keyword}」（出现 {top.count} 次）。" if top else "")
    )
    top_action = (
        f"优先补「{top.keyword}」：{top.advice}" if top else "继续保持，建议针对目标 JD 再跑一次解析验证"
    )
    return DefectReport(
        llm_mode=False, total_runs=total, defects=defects, improved=improved,
        summary=summary, top_action=top_action,
    )


def _defect_advice(kw: str, weight: str, count: int, streak: int, improved: bool) -> str:
    if improved:
        return f"「{kw}」最近一次解析已不再缺失，说明补上了 —— 记得在项目描述里保留这个关键词，别让它再掉回去。"
    if streak >= 3:
        return f"「{kw}」连续 {streak} 次解析都缺，是长期短板（JD 权重：{weight}）。建议做一个用到它的小项目并写进简历，而不是只在技能栏加个词。"
    if count >= 2:
        return f"「{kw}」在 {count} 次解析中缺失。若你实际用过，先补进简历对应项目描述；若没用过，花 3-5 天跑通最小示例再写「了解」。"
    return f"「{kw}」本次缺失（JD 权重：{weight}）。先确认是真不会还是没写上去 —— 没写上去最可惜。"


# ================================================================ ② 项目推荐
def recommend_projects_rule(jd_raw: str) -> ProjectAdvice:
    jd = parse_jd_rule(jd_raw)
    role = jd.role or "目标岗位"
    jd_kws = [r.keyword for r in jd.requirements]
    jd_weight = {r.keyword: r.weight for r in jd.requirements}
    jd_set = {k.lower() for k in jd_kws}

    projects = db.project_list()
    recs: list[ProjectRecommendation] = []
    covered: set[str] = set()

    for p in projects:
        tags_raw = (p.get("tags") or "") + "," + (p.get("name") or "") + "," + (p.get("summary") or "")
        tags = [t.strip() for t in tags_raw.split(",") if t.strip()]
        tag_low = {t.lower() for t in tags}
        hit = [k for k in jd_kws if k.lower() in tag_low or any(k.lower() in t or t in k.lower() for t in tag_low)]
        covered.update(h.lower() for h in hit)
        if not jd_kws:
            continue
        score = int(round(len(hit) / len(jd_kws) * 100))
        base = 100 if p.get("starred") else 0
        recs.append(ProjectRecommendation(
            project_id=p["id"], name=p.get("name") or "未命名项目",
            match_score=min(100, score * 2 + base // 2) if jd_kws else 0,
            hit_tags=hit,
            reason=_rec_reason(p, hit, jd_kws, jd_weight),
            rewrite_tip=_rewrite_tip(p, hit, jd_kws),
        ))
    recs.sort(key=lambda r: r.match_score, reverse=True)

    # JD 要求但项目库完全没覆盖的 → 建议补做
    gaps = [k for k in jd_kws if k.lower() not in covered]
    gaps.sort(key=lambda k: -_WEIGHT_SCORE.get(jd_weight.get(k, "中"), 2.0))
    ideas = [f"【{k}】{_PROJECT_IDEAS[k]}" for k in gaps if k in _PROJECT_IDEAS]
    for k in gaps:
        if k not in _PROJECT_IDEAS:
            ideas.append(f"【{k}】做一个用到 {k} 的最小可用项目，重点是能讲清「为什么用它、遇到什么问题、怎么解决的」")

    summary = (
        f"JD「{role}」共 {len(jd_kws)} 个技术要求；项目库 {len(projects)} 个项目，"
        f"最匹配的是「{recs[0].name}」（命中 {len(recs[0].hit_tags)} 个关键词）。"
        if recs else
        f"JD「{role}」共 {len(jd_kws)} 个技术要求，但项目库还是空的 —— 先去「项目库」录入你的真实项目，系统才能按 JD 帮你挑。"
    )
    if gaps:
        summary += f"未覆盖 {len(gaps)} 项：{'、'.join(gaps[:5])}。"

    return ProjectAdvice(
        llm_mode=False, role=role, jd_keywords=jd_kws,
        recommendations=recs[:6], new_project_ideas=ideas[:5], summary=summary,
    )


def _rec_reason(p: dict, hit: list[str], jd_kws: list[str], weight: dict[str, str]) -> str:
    if not hit:
        return "这个项目与当前 JD 的技术要求没有交集，若篇幅紧张可以后置或精简。"
    hi = [h for h in hit if weight.get(h) == "高"]
    if hi:
        return f"命中 JD 高优先要求 {('、'.join(hi))} —— 建议放在项目经历第一条，重点展开。"
    return f"命中 {('、'.join(hit[:4]))} 等 {len(hit)} 个 JD 关键词，与岗位方向吻合，建议保留并强化相关描述。"


def _rewrite_tip(p: dict, hit: list[str], jd_kws: list[str]) -> str:
    if not hit:
        return "若想保留，就在描述里补上与 JD 的关联点（比如把用到的通用技术点明），否则建议让位给更贴的项目。"
    miss = [k for k in jd_kws if k not in hit][:3]
    tip = f"描述里把 {('、'.join(hit[:3]))} 写在句首显眼位置，并补一句「用在什么场景、解决了什么问题」。"
    if miss:
        tip += f" 若项目里确实用过 {('、'.join(miss))}，务必点出来（能多命中 JD 关键词）。"
    return tip


# ================================================================ ③ 竞争力
def competitiveness_rule() -> Competitiveness:
    runs = db.parse_list(limit=30)
    if not runs:
        return Competitiveness(
            llm_mode=False, score=0, level="暂无数据", trend="—",
            summary="还没有解析记录，无法评估竞争力。先跑一次简历优化，系统会开始积累你的数据。",
            actions=["去「简历优化」跑一次 JD × 简历解析，之后每次都会自动存档形成趋势"],
        )

    scores = [r.get("score", 0) for r in reversed(runs)]  # 时间正序
    history = [{"label": r.get("label") or r.get("role") or f"第{i+1}次",
                "score": r.get("score", 0), "created_at": r.get("created_at", "")}
               for i, r in enumerate(reversed(runs))]
    latest = scores[-1]
    avg = sum(scores) / len(scores)

    if len(scores) >= 3:
        recent = sum(scores[-3:]) / 3
        prev = sum(scores[-6:-3]) / 3 if len(scores) >= 6 else scores[0]
        delta = recent - prev
        trend = "上升 ↑" if delta > 3 else ("下降 ↓" if delta < -3 else "持平 →")
    else:
        recent = latest
        delta = 0
        trend = "数据积累中"

    # 缺陷与项目覆盖
    defects = analyze_defects_rule(runs)
    open_defects = [d for d in defects.defects if not d.improved]
    projects = db.project_list()

    # 综合分 = 最近分数 60% + 均值 20% + 趋势加成 10% + 项目覆盖 10%
    proj_bonus = min(10, len(projects) * 2.5)
    trend_bonus = max(-10, min(10, delta * 2))
    score = int(round(latest * 0.6 + avg * 0.2 + trend_bonus + proj_bonus + 10))

    level = ("很强" if score >= 80 else "良好" if score >= 65 else
             "一般" if score >= 50 else "偏弱" if score >= 35 else "需要补课")

    strengths: list[str] = []
    weaknesses: list[str] = []
    actions: list[str] = []

    if latest >= 70:
        strengths.append(f"最近一次匹配度 {latest} 分，与目标 JD 对齐度不错，简历可以投了")
    elif latest >= 50:
        strengths.append(f"最近一次匹配度 {latest} 分，能过初筛，但还不够亮眼")
    else:
        weaknesses.append(f"最近一次匹配度只有 {latest} 分，直接海投性价比很低")
    if len(scores) >= 2 and delta > 3:
        strengths.append(f"匹配度呈上升趋势（近几次提升 {delta:.0f} 分），说明之前的调整有效")
    elif len(scores) >= 2 and delta < -3:
        weaknesses.append(f"匹配度在下滑（{delta:.0f} 分）—— 可能是换了更不匹配的岗位方向，注意确认方向")
    if defects.improved:
        strengths.append(f"已补齐 {len(defects.improved)} 项短板：{'、'.join(defects.improved[:4])}")

    for d in open_defects[:3]:
        weaknesses.append(f"「{d.keyword}」仍未解决（缺失 {d.count} 次，权重{d.weight}）")

    # 面试复盘：真实面试暴露的短板，可信度高于纯简历分析
    reviews = db.review_list(limit=10)
    interview_weak: list[str] = []
    for rv in reviews[:5]:
        try:
            interview_weak.extend([w for w in json.loads(rv.get("weaknesses") or "[]") if w])
        except Exception:  # noqa: BLE001
            continue
    uniq_weak = list(dict.fromkeys(interview_weak))
    if uniq_weak:
        weaknesses.append(f"面试实战暴露 {len(uniq_weak)} 个盲点（真刀真枪问出来的，优先级高于简历分析）")

    if open_defects:
        actions.append(f"① 优先补「{open_defects[0].keyword}」：{open_defects[0].advice}")
    if not projects:
        actions.append("② 去「项目库」录入你的真实项目 —— 没有项目数据，系统无法按 JD 帮你挑最贴的经历")
    elif len(projects) < 3:
        actions.append(f"② 项目库只有 {len(projects)} 个项目，建议再补 1-2 个（含课程设计、个人练手都算）")
    else:
        actions.append(f"② 项目库已有 {len(projects)} 个项目，用「项目推荐」按目标 JD 挑前 3 个重点展开")
    actions.append("③ 每次改完简历都回来跑一次解析 —— 让分数趋势和缺陷变化成为你调整的依据")
    if uniq_weak:
        actions.append("④ 优先补面试暴露的盲点（一手信息最值钱）：" + "；".join(uniq_weak[:2])[:90])
    if len(scores) >= 2 and trend == "持平 →":
        actions.append("⑤ 匹配度长期持平，说明小修小补没用，需要换策略：补一个硬缺口项目或调整目标岗位")

    summary = (
        f"综合竞争力 {score} 分（{level}）：最近一次匹配 {latest} 分，历史均值 {avg:.0f} 分，趋势{trend}。"
        f"累计 {len(runs)} 次解析，{len(open_defects)} 项短板待补、{len(defects.improved)} 项已改善。"
    )
    if reviews:
        summary += f" 另有 {len(reviews)} 次面试复盘，暴露 {len(uniq_weak)} 个真实盲点。"
    return Competitiveness(
        llm_mode=False, score=score, level=level, trend=trend, history=history,
        strengths=strengths or ["暂无明显优势项，先跑几次解析积累数据"],
        weaknesses=weaknesses, actions=actions, summary=summary,
    )


# ================================================================ LLM 增强（可选）
async def _llm_json(system: str, user: str) -> dict | None:
    try:
        return await llm.chat_json([{"role": "system", "content": system}, {"role": "user", "content": user}])
    except Exception as e:  # noqa: BLE001
        logger.warning("LLM 生成失败，回退规则模式: %s", e)
        return None


async def analyze_defects_llm(runs: list[dict], resume_text: str) -> DefectReport | None:
    base = analyze_defects_rule(runs, resume_text)
    if not base.defects:
        return None
    user = (
        f"候选人最近 {len(runs)} 次 JD×简历解析中反复缺失的能力项：\n"
        + "\n".join(f"- {d.keyword}（权重{d.weight}，缺失{d.count}次）" for d in base.defects[:8])
        + "\n\n请针对最高优先的 3 项，各给一句「具体到怎么做」的建议（30 字内，不要空话）。\n"
        "返回 JSON：{\"advices\":{\"关键词\":\"建议\"}}"
    )
    data = await _llm_json("你是资深技术面试官兼简历顾问，建议要具体可执行，禁止空话套话。", user)
    if not data or not data.get("advices"):
        return None
    for d in base.defects:
        if d.keyword in data["advices"]:
            d.advice = str(data["advices"][d.keyword])[:120]
    base.llm_mode = True
    return base


# ================================================================ 编排入口
async def save_parse_snapshot(
    jd_raw: str, resume_raw: str, result: Any, label: str = "", job_id: int = 0, resume_id: int = 0
) -> int:
    """把一次解析的原始数据与结论存档（缺陷追踪/竞争力趋势的数据源）。"""
    role = getattr(getattr(result, "jd", None), "role", "") or ""
    analysis = getattr(result, "analysis", None)
    score = getattr(analysis, "overall_score", 0) or 0
    matched = [r.keyword for r in getattr(analysis, "matched", [])]
    missing = [{"keyword": r.keyword, "weight": r.weight} for r in getattr(analysis, "missing", [])]
    optimized = getattr(getattr(result, "optimized", None), "content", "") or ""
    return db.parse_save(
        label=label or role or "未命名解析", role=role, jd_text=jd_raw, resume_text=resume_raw,
        score=score, matched=matched, missing=missing, optimized=optimized,
        job_id=job_id, resume_id=resume_id,
    )


async def analyze_defects(resume_text: str = "") -> DefectReport:
    runs = db.parse_list(limit=30)
    if settings.llm_enabled:
        r = await analyze_defects_llm(runs, resume_text)
        if r:
            return r
    return analyze_defects_rule(runs, resume_text)


async def recommend_projects(jd_raw: str) -> ProjectAdvice:
    if settings.llm_enabled:
        base = recommend_projects_rule(jd_raw)
        user = (
            f"目标 JD：\n{jd_raw[:1200]}\n\n候选人项目库：\n"
            + "\n".join(f"- {r.name}（命中：{'、'.join(r.hit_tags) or '无'}）" for r in base.recommendations)
            + "\n\n请为一句话说明「为什么这个 JD 下该项目该重点展示」，并给每个项目一句描述改写建议。\n"
            "返回 JSON：{\"reasons\":{\"项目名\":\"理由\"},\"tips\":{\"项目名\":\"改写建议\"}}"
        )
        data = await _llm_json("你是资深技术面试官，判断哪段经历最能打动招聘方。", user)
        if data:
            for r in base.recommendations:
                if data.get("reasons", {}).get(r.name):
                    r.reason = str(data["reasons"][r.name])[:160]
                if data.get("tips", {}).get(r.name):
                    r.rewrite_tip = str(data["tips"][r.name])[:160]
            base.llm_mode = True
            return base
    return recommend_projects_rule(jd_raw)


async def competitiveness() -> Competitiveness:
    return competitiveness_rule()
