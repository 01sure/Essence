"""智能投递 · 浏览器连接器（CLI）。

子命令：
  login   --platform boss|liepin|zhilian   手动扫码登录，保存 cookie 到 data/delivery/
  search  --platform ... --keyword ...      检索岗位（live 解析页面 / mock 返回样本）
  apply   --platform ... --job-id <id>      对指定岗位投递（需已登录）

模式：
  - 默认 mock：无需真实账号即可演示/测试完整流程（search 返回样本、apply 模拟成功）。
  - 设置环境变量 DELIVERY_LIVE=1 且已安装 playwright 时进入 live：真实驱动浏览器。
    登录由本进程打开有头浏览器，用户在弹窗中手动扫码；后续复用 cookie 自动投递。

⚠️ 诚实说明：Boss直聘/猎聘/智联均有反爬与风控。live 模式的页面选择器可能随官网改版失效，
   自动投递可能触发风控甚至封号，请由本人评估风险并遵守平台服务条款。本工具仅做"降低概率"
   的拟人化护栏，不保证不被拦截。选择器均为 best-effort，失效时请更新下方常量或反馈。
"""
from __future__ import annotations

import argparse
import json
import os
import random
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path

# 让脚本可直接运行（python app/delivery_runner.py）
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app import db  # noqa: E402
from app.delivery import PLATFORMS, generate_mock_jobs  # noqa: E402

LIVE = os.getenv("DELIVERY_LIVE", "0") == "1"
COOKIE_DIR = ROOT / "data" / "delivery"
COOKIE_DIR.mkdir(parents=True, exist_ok=True)

# live 模式：平台登录页与 best-effort「已登录」判定选择器（可能需随官网更新）
LOGIN_URLS = {
    "boss": "https://www.zhipin.com/web/user/?ka=header-login",
    "liepin": "https://www.liepin.com/",
    "zhilian": "https://www.zhaopin.com/",
}
# 已登录判定：页面出现这些选择器之一即视为登录成功（best-effort）
LOGGED_IN_SELECTORS = {
    "boss": ["div.user-info", "a[href*='/job/home']", "img.avatar"],
    "liepin": ["div.user-card", "a[href*='/personal']"],
    "zhilian": ["div.resume-center", "a[href*='/resume']", "img.user-avatar"],
}


def _out(obj: dict) -> None:
    print(json.dumps(obj, ensure_ascii=False))


def _get_cookies_path(platform: str) -> Path:
    return COOKIE_DIR / f"{platform}_cookies.json"


# ================================================================ login
def cmd_login(platform: str) -> None:
    if platform not in PLATFORMS:
        _out({"ok": False, "status": "error", "message": f"未知平台：{platform}"})
        return

    # mock：跳过真实登录
    if not LIVE:
        db.delivery_session_upsert(
            platform, status="ready", last_login=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            expires_at=(datetime.now() + timedelta(days=6)).strftime("%Y-%m-%d %H:%M:%S"),
            message="mock 模式：跳过真实扫码登录（开启 DELIVERY_LIVE=1 后需手动扫码）",
        )
        _out({"ok": True, "status": "ready", "message": "mock 模式已就绪（未连接真实账号）"})
        return

    try:
        from playwright.sync_api import sync_playwright  # type: ignore
    except ImportError:
        _out({"ok": False, "status": "error",
              "message": "未安装 playwright，请先：pip install playwright && playwright install chromium"})
        return

    db.delivery_session_upsert(platform, status="connecting", message="请在弹出的浏览器中手动扫码登录…")
    cookies_path = _get_cookies_path(platform)
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=False, slow_mo=random.randint(300, 800))
            ctx = browser.new_context(viewport={"width": 1280, "height": 900})
            page = ctx.new_page()
            page.goto(LOGIN_URLS[platform], wait_until="domcontentloaded")
            # 等待用户手动扫码；最长 180s 轮询「已登录」选择器
            logged = False
            deadline = time.time() + 180
            selectors = LOGGED_IN_SELECTORS.get(platform, [])
            while time.time() < deadline:
                for sel in selectors:
                    try:
                        if page.query_selector(sel):
                            logged = True
                            break
                    except Exception:  # noqa: BLE001
                        pass
                if logged:
                    break
                time.sleep(3)
            if not logged:
                db.delivery_session_upsert(platform, status="error", message="扫码登录超时（180s 内未检测到登录态）")
                browser.close()
                _out({"ok": False, "status": "error", "message": "扫码登录超时，请在 180s 内完成扫码"})
                return
            # 保存 cookie
            cookies = ctx.cookies()
            cookies_path.write_text(json.dumps(cookies, ensure_ascii=False), encoding="utf-8")
            db.delivery_session_upsert(
                platform, status="ready", cookies_path=str(cookies_path),
                last_login=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                expires_at=(datetime.now() + timedelta(days=6)).strftime("%Y-%m-%d %H:%M:%S"),
                message="已扫码登录，cookie 已保存",
            )
            browser.close()
        _out({"ok": True, "status": "ready", "message": "登录成功，cookie 已保存，可开始投递"})
    except Exception as e:  # noqa: BLE001
        db.delivery_session_upsert(platform, status="error", message=f"登录异常：{e}")
        _out({"ok": False, "status": "error", "message": f"登录异常：{e}"})


# ================================================================ search
def cmd_search(platform: str, keyword: str, city: str, pages: int) -> None:
    if platform not in PLATFORMS:
        _out({"ok": False, "jobs": [], "message": f"未知平台：{platform}"})
        return
    if not LIVE:
        jobs = generate_mock_jobs(platform, keyword, city, n=12)
        _out({"ok": True, "jobs": jobs, "message": f"mock 模式返回 {len(jobs)} 个样本岗位"})
        return

    # live：best-effort 解析（选择器可能随官网改版失效）
    try:
        from playwright.sync_api import sync_playwright  # type: ignore
    except ImportError:
        _out({"ok": False, "jobs": [], "message": "未安装 playwright"})
        return
    cookies_path = _get_cookies_path(platform)
    if not cookies_path.exists():
        _out({"ok": False, "jobs": [], "message": "尚未登录（请先 login）"})
        return
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True, slow_mo=300)
            ctx = browser.new_context()
            ctx.add_cookies(json.loads(cookies_path.read_text(encoding="utf-8")))
            page = ctx.new_page()
            q = (keyword or "AI 应用开发").replace(" ", "+")
            page.goto(f"https://www.zhipin.com/web/geek/job?query={q}&city={city or ''}",
                      wait_until="domcontentloaded")
            time.sleep(3)
            # best-effort：抽取职位卡片（Boss 卡片选择器，可能需更新）
            cards = page.query_selector_all("li.job-card-wrapper")
            jobs = []
            for c in cards[:30]:
                title = (c.query_selector("span.job-name") or {}).inner_text() if c.query_selector("span.job-name") else ""
                company = (c.query_selector("span.company-name") or {}).inner_text() if c.query_selector("span.company-name") else ""
                salary = (c.query_selector("span.salary") or {}).inner_text() if c.query_selector("span.salary") else ""
                jobs.append({
                    "platform": platform, "job_key": f"{platform}-{len(jobs)+1}",
                    "title": title.strip(), "company": company.strip(), "city": city,
                    "salary": salary.strip(), "url": "", "jd_text": f"{title} {company} {salary}",
                })
            browser.close()
        _out({"ok": True, "jobs": jobs, "message": f"live 解析到 {len(jobs)} 个岗位（best-effort）"})
    except Exception as e:  # noqa: BLE001
        _out({"ok": False, "jobs": [], "message": f"live 检索失败：{e}（选择器可能已变更）"})


# ================================================================ apply
def cmd_apply(platform: str, job_id: int) -> None:
    job = db.delivery_job_get(job_id)
    if not job:
        _out({"ok": False, "message": f"岗位不存在：{job_id}"})
        return
    if not LIVE:
        # mock：模拟成功（真实延时/风控在引擎的 run_campaign 中统一处理）
        time.sleep(random.uniform(0.2, 0.6))
        _out({"ok": True, "message": f"mock 模拟投递成功：{job.get('company')} {job.get('title')}"})
        return

    cookies_path = _get_cookies_path(platform)
    if not cookies_path.exists():
        _out({"ok": False, "message": "尚未登录（请先 login）"})
        return
    try:
        from playwright.sync_api import sync_playwright  # type: ignore
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True, slow_mo=random.randint(400, 900))
            ctx = browser.new_context()
            ctx.add_cookies(json.loads(cookies_path.read_text(encoding="utf-8")))
            page = ctx.new_page()
            page.goto(job.get("url") or LOGIN_URLS[platform], wait_until="domcontentloaded")
            time.sleep(random.uniform(2, 5))
            # best-effort：点击「立即沟通/投递」按钮
            btn = page.query_selector("a.btn-startchat, button.btn-apply, a.op-btn")
            if btn:
                btn.click()
                time.sleep(random.uniform(1, 3))
                ok = True
            else:
                ok = False
            browser.close()
        _out({"ok": ok, "message": "live 投递" + ("成功" if ok else "未找到投递按钮（选择器可能已变更）")})
    except Exception as e:  # noqa: BLE001
        _out({"ok": False, "message": f"live 投递异常：{e}"})


def main() -> None:
    ap = argparse.ArgumentParser(description="智能投递浏览器连接器")
    sub = ap.add_subparsers(dest="cmd", required=True)

    pl = argparse.ArgumentParser(add_help=False)
    pl.add_argument("--platform", required=True, choices=list(PLATFORMS.keys()))

    p_login = sub.add_parser("login", parents=[pl])
    p_search = sub.add_parser("search", parents=[pl])
    p_search.add_argument("--keyword", default="AI 应用开发")
    p_search.add_argument("--city", default="")
    p_search.add_argument("--pages", type=int, default=3)
    p_apply = sub.add_parser("apply", parents=[pl])
    p_apply.add_argument("--job-id", type=int, required=True)

    args = ap.parse_args()
    if args.cmd == "login":
        cmd_login(args.platform)
    elif args.cmd == "search":
        cmd_search(args.platform, args.keyword, args.city, args.pages)
    elif args.cmd == "apply":
        cmd_apply(args.platform, args.job_id)


if __name__ == "__main__":
    main()
