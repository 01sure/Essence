"""文档识别模块：图片 OCR / PDF / Word / Excel / PPT / 纯文本。

- 图片（png/jpg/jpeg/webp/bmp）：RapidOCR 离线中文 OCR（首次调用加载模型约 1-3s，之后常驻内存）
- PDF：pypdf 提取文本层；扫描版 PDF（无文本层）会返回空文本并在上层提示改走图片 OCR
- Word（docx）：python-docx 提取段落 + 表格
- Excel（xlsx/xlsm）：openpyxl 提取所有工作表单元格；旧版（xls）：xlrd 提取
- PPT（pptx）：python-pptx 提取所有页面的文本框 + 表格
- txt/md/csv：按 utf-8 → gbk 顺序解码

所有识别均为本地离线完成，文件不离开本机。
"""
from __future__ import annotations

import logging
from pathlib import Path

logger = logging.getLogger(__name__)

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}
TEXT_EXTS = {".txt", ".md", ".csv"}
DOCX_EXTS = {".docx"}
PDF_EXTS = {".pdf"}
XLSX_EXTS = {".xlsx", ".xlsm"}
XLS_EXTS = {".xls"}
PPTX_EXTS = {".pptx"}

_ocr_engine = None


def _get_ocr():
    """懒加载 RapidOCR 引擎（首次调用才初始化）。"""
    global _ocr_engine
    if _ocr_engine is None:
        from rapidocr_onnxruntime import RapidOCR

        _ocr_engine = RapidOCR()
        logger.info("RapidOCR 引擎已就绪（离线中文 OCR）")
    return _ocr_engine


def extract_docx(path: Path) -> str:
    """提取 Word(docx) 的段落与表格文本。"""
    import docx

    d = docx.Document(str(path))
    parts: list[str] = []
    for p in d.paragraphs:
        if p.text.strip():
            parts.append(p.text.strip())
    for table in d.tables:
        for row in table.rows:
            cells = [c.text.strip() for c in row.cells]
            line = " | ".join(c for c in cells if c)
            if line:
                parts.append(line)
    return "\n".join(parts)


def extract_pdf(path: Path) -> tuple[str, int]:
    """提取 PDF 文本层，返回 (文本, 页数)。"""
    from pypdf import PdfReader

    reader = PdfReader(str(path))
    parts: list[str] = []
    for page in reader.pages:
        t = (page.extract_text() or "").strip()
        if t:
            parts.append(t)
    return "\n\n".join(parts), len(reader.pages)


def extract_xlsx(path: Path) -> str:
    """提取 Excel(xlsx/xlsm) 所有工作表的单元格文本（按行用 | 连接）。"""
    import openpyxl

    wb = openpyxl.load_workbook(str(path), read_only=True, data_only=True)
    parts: list[str] = []
    try:
        for ws in wb.worksheets:
            if ws.max_row and ws.max_column:
                parts.append(f"[工作表: {ws.title}]")
            for row in ws.iter_rows(values_only=True):
                cells = [str(c).strip() for c in row if c is not None and str(c).strip()]
                if cells:
                    parts.append(" | ".join(cells))
    finally:
        wb.close()
    return "\n".join(parts)


def extract_xls(path: Path) -> str:
    """提取旧版 Excel(xls) 所有工作表的单元格文本。"""
    import xlrd

    book = xlrd.open_workbook(str(path))
    parts: list[str] = []
    for sheet in book.sheets():
        parts.append(f"[工作表: {sheet.name}]")
        for r in range(sheet.nrows):
            cells = [
                str(sheet.cell_value(r, c)).strip()
                for c in range(sheet.ncols)
                if str(sheet.cell_value(r, c)).strip()
            ]
            if cells:
                parts.append(" | ".join(cells))
    return "\n".join(parts)


def extract_pptx(path: Path) -> str:
    """提取 PPT(pptx) 所有页面的文本框与表格文本。"""
    from pptx import Presentation

    prs = Presentation(str(path))
    parts: list[str] = []
    for i, slide in enumerate(prs.slides, 1):
        slide_texts: list[str] = []
        for shape in slide.shapes:
            if shape.has_text_frame:
                for para in shape.text_frame.paragraphs:
                    t = "".join(run.text for run in para.runs).strip()
                    if t:
                        slide_texts.append(t)
            if getattr(shape, "has_table", False):
                for row in shape.table.rows:
                    cells = [cell.text.strip() for cell in row.cells if cell.text.strip()]
                    if cells:
                        slide_texts.append(" | ".join(cells))
        if slide_texts:
            parts.append(f"[第 {i} 页]\n" + "\n".join(slide_texts))
    return "\n\n".join(parts)


def ocr_image(path: Path) -> str:
    """RapidOCR 识别图片中的文字（中文优先，支持竖排/倾斜轻微矫正）。"""
    engine = _get_ocr()
    result, _elapse = engine(str(path))
    if not result:
        return ""
    lines = [item[1].strip() for item in result if item[1] and item[1].strip()]
    return "\n".join(lines)


def extract_file(path: Path, filename: str | None = None) -> tuple[str, str]:
    """按扩展名分发识别。

    返回 (文本, 识别方式)，识别方式 ∈ {ocr, pdf_text, docx_text, xlsx_text, xls_text,
    pptx_text, plain_text}。不支持的扩展名抛 ValueError。
    """
    name = filename or path.name
    ext = Path(name).suffix.lower()
    if ext in IMAGE_EXTS:
        return ocr_image(path), "ocr"
    if ext in PDF_EXTS:
        text, _pages = extract_pdf(path)
        return text, "pdf_text"
    if ext in DOCX_EXTS:
        return extract_docx(path), "docx_text"
    if ext in XLSX_EXTS:
        return extract_xlsx(path), "xlsx_text"
    if ext in XLS_EXTS:
        return extract_xls(path), "xls_text"
    if ext in PPTX_EXTS:
        return extract_pptx(path), "pptx_text"
    if ext in TEXT_EXTS:
        raw = path.read_bytes()
        for enc in ("utf-8", "gbk"):
            try:
                return raw.decode(enc), "plain_text"
            except UnicodeDecodeError:
                continue
        return raw.decode("utf-8", errors="replace"), "plain_text"
    raise ValueError(f"不支持的文件类型: {ext}")
