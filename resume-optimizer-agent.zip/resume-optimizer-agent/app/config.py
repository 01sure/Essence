"""全局配置：从环境变量 / .env 读取，支持 LLM 与规则引擎双模式。"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv

# 项目根目录（app/ 的上一级）
ROOT_DIR = Path(__file__).resolve().parent.parent
load_dotenv(ROOT_DIR / ".env")


@dataclass
class Settings:
    llm_base_url: str = field(default_factory=lambda: os.getenv("LLM_BASE_URL", "").strip())
    llm_api_key: str = field(default_factory=lambda: os.getenv("LLM_API_KEY", "").strip())
    llm_model: str = field(default_factory=lambda: os.getenv("LLM_MODEL", "deepseek-chat").strip())
    port: int = field(default_factory=lambda: int(os.getenv("PORT", "8000")))

    @property
    def llm_enabled(self) -> bool:
        """API Key 齐全才算启用 LLM，否则走规则引擎。"""
        return bool(self.llm_base_url and self.llm_api_key)


settings = Settings()
