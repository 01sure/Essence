"""FastAPI 入口：一站式求职 Agent 系统。

功能域：
- 简历优化：POST /api/optimize
- 打招呼语：POST /api/greeting、历史 POST /api/greetings/save、GET /api/greetings/history
- 上传识别：POST /api/extract（图片 OCR / PDF / Word / txt）
- 面试准备：POST /api/interview/prepare、计划历史 /api/interviews/*
- 知识库问答：POST /api/kb/ask、文档管理 /api/kb/*
- 后台管理：求职记录 /api/jobs/*、简历版本 /api/resumes/*、仪表盘 /api/dashboard
"""
from __future__ import annotations

import asyncio
import logging
import os
import subprocess
import sys
import tempfile
import uuid
from datetime import datetime, timedelta
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from app import db
from app.agent import run_greeting, run_optimizer
from app.chat_coach import diagnose_gaps, draft_followup, draft_reply, generate_hellos
from app.config import settings
from app.doc_parse import extract_file
from app.insight import (
    analyze_defects,
    competitiveness,
    recommend_projects,
    save_parse_snapshot,
)
from app.interview import prepare_interview
from app.kb import add_doc, ask_kb, compose_kb_content, kb_list, organize_text
from app.record import summarize_record
from app.review import analyze_review
from app.delivery import (
    PLATFORMS,
    analyze_targeting,
    campaign_status,
    generate_mock_jobs,
    get_profile,
    match_jobs,
    run_campaign,
    safety_config,
    safety_set,
    set_profile,
)
from app.schemas import (
    ChatHelloResult,
    ChatReplyResult,
    Competitiveness,
    DefectReport,
    DeliveryJob,
    DeliverySession,
    DeliveryStrategy,
    DiagnoseResult,
    ExtractResult,
    FollowupResult,
    GreetingResult,
    InterviewPlan,
    KBAskResult,
    KBIngestResult,
    OptimizeResult,
    ProjectAdvice,
    RecordResult,
    ReviewResult,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")

app = FastAPI(title="求职 Agent 系统（智能投递 · 记录中心 · 简历优化 · 沟通策略 · 面试复盘 · 数据洞察 · 知识库）", version="2.5.0")

STATIC_DIR = Path(__file__).resolve().parent / "static"

MAX_UPLOAD = 10 * 1024 * 1024  # 10MB
ALLOWED_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".pdf", ".docx",
                ".xlsx", ".xlsm", ".xls", ".pptx", ".txt", ".md", ".csv"}

# 启动时初始化数据库
db.init_db()


class OptimizeRequest(BaseModel):
    jd: str = Field(min_length=10, description="目标岗位 JD 文本")
    resume: str = Field(min_length=20, description="简历文本（Markdown/纯文本）")


class InterviewRequest(BaseModel):
    jd: str = Field(min_length=10)
    resume: str = Field(min_length=20)


class AskRequest(BaseModel):
    question: str = Field(min_length=2, max_length=500)


class JobCreate(BaseModel):
    company: str = Field(min_length=1)
    position: str = Field(min_length=1)
    jd: str = ""
    note: str = ""


class JobUpdate(BaseModel):
    company: str | None = None
    position: str | None = None
    jd: str | None = None
    status: str | None = None
    note: str | None = None


class ResumeCreate(BaseModel):
    label: str = ""
    content: str = Field(min_length=20)


class GreetingSave(BaseModel):
    job_id: int = 0
    style: str = ""
    content: str = Field(min_length=5)


class InterviewSave(BaseModel):
    job_id: int = 0
    resume_id: int = 0
    plan: InterviewPlan


class ChatHelloRequest(BaseModel):
    jd: str = Field(min_length=10)
    resume: str = Field(min_length=20)


class ChatReplyRequest(BaseModel):
    jd: str = Field(min_length=10)
    resume: str = Field(min_length=20)
    scenario: str = Field(default="ask_resume", description="场景 key，可用中文别名如「薪资」「面试」")
    hr_message: str = Field(default="", description="HR 的原话（可选，LLM 模式下更贴合）")


class FollowupRequest(BaseModel):
    jd: str = Field(min_length=10)
    resume: str = Field(min_length=20)
    round_no: int = Field(default=1, ge=1, le=3)


class ChatSave(BaseModel):
    kind: str = Field(description="hello / reply / followup / diagnose")
    scene: str = ""
    style: str = ""
    content: str = Field(min_length=2)
    role: str = ""
    job_id: int = 0


class JDOnly(BaseModel):
    jd: str = Field(min_length=10, description="目标 JD 文本")


class ResumeOnly(BaseModel):
    resume: str = Field(default="", description="简历文本（用于表达层缺陷检查）")


class ProjectCreate(BaseModel):
    name: str = Field(min_length=1)
    role: str = ""
    tags: str = Field(default="", description="技术标签，逗号分隔")
    summary: str = ""
    bullets: list[str] = Field(default_factory=list)
    starred: bool = False


class ProjectUpdate(BaseModel):
    name: str | None = None
    role: str | None = None
    tags: str | None = None
    summary: str | None = None
    bullets: list[str] | None = None
    starred: bool | None = None


class ReviewRequest(BaseModel):
    raw: str = Field(min_length=10, description="面试记录原文")
    company: str = ""
    position: str = ""
    resume: str = Field(default="", description="简历文本（用于交叉比对：被问到但简历没有的点）")


class ReviewSave(BaseModel):
    review: ReviewResult
    raw: str = ""
    job_id: int = 0


# ================================================================ 智能投递
class DeliveryProfileReq(BaseModel):
    content: str = Field(min_length=20, description="用户自己的简历画像文本（作为匹配基准）")


class DeliveryApproveReq(BaseModel):
    ids: list[int] = Field(default_factory=list, description="要批准的岗位 id 列表")
    auto_threshold: int | None = Field(default=None, description="若设置，自动批准匹配分≥该值的 pending 岗位")


@app.get("/")
async def index() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/api/health")
async def health() -> dict:
    return {
        "status": "ok",
        "llm_configured": settings.llm_enabled,
        "llm_model": settings.llm_model if settings.llm_enabled else None,
        "mode": "LLM + 规则引擎双模式" if settings.llm_enabled else "规则引擎（未配置 LLM，可离线演示）",
        "file_upload": "图片OCR / PDF / Word / Excel / PPT / txt 识别已启用",
        "modules": ["智能投递", "记录中心", "简历优化", "打招呼语", "沟通策略", "面试准备", "面试复盘",
                    "数据洞察", "知识库问答（含智能整理入库）", "后台管理"],
        "version": "2.5.0",
    }


# ================================================================ 简历优化 & 打招呼语
@app.post("/api/optimize", response_model=OptimizeResult)
async def optimize(req: OptimizeRequest) -> OptimizeResult:
    """Agent 主入口：输入 JD + 简历，返回匹配分析、优化后简历与执行轨迹。

    结果会自动存档为一次「解析快照」，供后续的缺陷追踪与竞争力趋势分析使用。
    """
    result = await run_optimizer(req.jd, req.resume)
    try:
        result.meta["parse_run_id"] = await save_parse_snapshot(req.jd, req.resume, result)
    except Exception as e:  # noqa: BLE001
        logger.warning("解析快照存档失败（不影响主流程）: %s", e)
    return result


@app.post("/api/greeting", response_model=GreetingResult)
async def greeting(req: OptimizeRequest) -> GreetingResult:
    """打招呼语入口：基于 JD×简历的交集生成 3 种风格的 HR 首条消息。"""
    return await run_greeting(req.jd, req.resume)


# ================================================================ 上传识别（图片 OCR / PDF / Word / txt）
@app.post("/api/extract", response_model=ExtractResult)
async def extract_api(file: UploadFile = File(...)) -> ExtractResult:
    """上传识别：图片 RapidOCR / PDF 文本层 / docx / txt，全部本地处理。"""
    filename = file.filename or "upload.bin"
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED_EXTS:
        raise HTTPException(400, f"不支持的文件类型「{ext}」，支持 png/jpg/jpeg/webp/bmp/pdf/docx/xlsx/xls/pptx/txt/md/csv")
    data = await file.read()
    if len(data) > MAX_UPLOAD:
        raise HTTPException(400, "文件超过 10MB 上限")
    tmp = Path(tempfile.gettempdir()) / f"roa_{uuid.uuid4().hex[:8]}{ext}"
    tmp.write_bytes(data)
    try:
        text, method = extract_file(tmp, filename)
    except HTTPException:
        raise
    except Exception as e:  # noqa: BLE001
        raise HTTPException(400, f"识别失败：{e}") from e
    finally:
        tmp.unlink(missing_ok=True)
    warn = "" if text.strip() else "未识别到文字：扫描版 PDF 无文本层时，请截图后以图片方式上传"
    return ExtractResult(filename=filename, method=method, text=text, chars=len(text), warn=warn)


# ================================================================ 面试准备
@app.post("/api/interview/prepare", response_model=InterviewPlan)
async def interview_prepare(req: InterviewRequest) -> InterviewPlan:
    """根据 JD × 简历 生成模拟面试问题清单（技术基础 / 项目深挖 / 开放问题）。"""
    return await prepare_interview(req.jd, req.resume)


@app.post("/api/interviews/save")
async def interview_save(req: InterviewSave) -> dict:
    """保存一份面试准备计划到后台。"""
    plan_id = db.interview_save(
        job_id=req.job_id,
        resume_id=req.resume_id,
        role=req.plan.role,
        questions=[q.model_dump() for q in req.plan.questions],
        llm_mode=req.plan.llm_mode,
    )
    return {"id": plan_id, "ok": True}


@app.get("/api/interviews")
async def interview_list(job_id: int = 0) -> list[dict]:
    return db.interview_list(job_id=job_id)


@app.delete("/api/interviews/{plan_id}")
async def interview_delete(plan_id: int) -> dict:
    if not db.interview_delete(plan_id):
        raise HTTPException(404, "面试计划不存在")
    return {"ok": True}


# ================================================================ 沟通策略（HR 换位思考）
@app.post("/api/chat/hello", response_model=ChatHelloResult)
async def chat_hello(req: ChatHelloRequest) -> ChatHelloResult:
    """打招呼语：5 种风格（含热情示好/舔狗式），附 HR 视角洞察与避雷清单。"""
    return await generate_hellos(req.jd, req.resume)


@app.post("/api/chat/reply", response_model=ChatReplyResult)
async def chat_reply(req: ChatReplyRequest) -> ChatReplyResult:
    """HR 回复后的应答：先解读 HR 真实意图，再给 3 种语气话术。"""
    return await draft_reply(req.jd, req.resume, req.scenario, req.hr_message)


@app.post("/api/chat/followup", response_model=FollowupResult)
async def chat_followup(req: FollowupRequest) -> FollowupResult:
    """已读不回追问：3 轮递进（轻量提醒 → 带新信息 → 体面收尾）。"""
    return await draft_followup(req.jd, req.resume, req.round_no)


@app.post("/api/chat/diagnose", response_model=DiagnoseResult)
async def chat_diagnose(req: ChatHelloRequest) -> DiagnoseResult:
    """不匹配诊断：区分简历包装问题与能力硬伤，给 30 天提升计划。"""
    return await diagnose_gaps(req.jd, req.resume)


@app.post("/api/chat/save")
async def chat_save(req: ChatSave) -> dict:
    """保存一条话术到后台历史。"""
    sid = db.chat_save(
        kind=req.kind, scene=req.scene, style=req.style,
        content=req.content, role=req.role, job_id=req.job_id,
    )
    return {"id": sid, "ok": True}


@app.get("/api/chat/scripts")
async def chat_scripts(kind: str = "") -> list[dict]:
    return db.chat_list(kind=kind)


@app.delete("/api/chat/scripts/{script_id}")
async def chat_script_delete(script_id: int) -> dict:
    if not db.chat_delete(script_id):
        raise HTTPException(404, "话术不存在")
    return {"ok": True}


# ================================================================ 数据洞察（解析存档 → 反哺简历）
@app.get("/api/parse/runs")
async def parse_runs() -> list[dict]:
    """解析历史：每次 JD×简历解析的快照（缺陷追踪与竞争力趋势的数据源）。"""
    return db.parse_list(limit=30)


@app.get("/api/parse/runs/{run_id}")
async def parse_run_get(run_id: int) -> dict:
    r = db.parse_get(run_id)
    if not r:
        raise HTTPException(404, "解析记录不存在")
    return r


@app.delete("/api/parse/runs/{run_id}")
async def parse_run_delete(run_id: int) -> dict:
    if not db.parse_delete(run_id):
        raise HTTPException(404, "解析记录不存在")
    return {"ok": True}


@app.post("/api/insight/defects", response_model=DefectReport)
async def insight_defects(req: ResumeOnly) -> DefectReport:
    """简历缺陷追踪：聚合历史解析，找出反复缺失的能力项。"""
    return await analyze_defects(req.resume)


@app.post("/api/insight/projects/recommend", response_model=ProjectAdvice)
async def insight_projects(req: JDOnly) -> ProjectAdvice:
    """按 JD 推荐更适合的项目：项目库匹配打分 + 描述改写建议 + 建议补做的项目。"""
    return await recommend_projects(req.jd)


@app.get("/api/insight/competitiveness", response_model=Competitiveness)
async def insight_competitiveness() -> Competitiveness:
    """竞争力评估：历史分数趋势 + 缺陷改善 + 项目覆盖 + 面试复盘。"""
    return await competitiveness()


# ================================================================ 项目库
@app.get("/api/projects")
async def project_list_api() -> list[dict]:
    return db.project_list()


@app.post("/api/projects")
async def project_create_api(req: ProjectCreate) -> dict:
    pid = db.project_create(
        name=req.name, role=req.role, tags=req.tags, summary=req.summary,
        bullets=req.bullets, starred=req.starred,
    )
    return {"id": pid, "ok": True}


@app.put("/api/projects/{project_id}")
async def project_update_api(project_id: int, req: ProjectUpdate) -> dict:
    fields = {k: v for k, v in req.model_dump().items() if v is not None}
    if not db.project_update(project_id, **fields):
        raise HTTPException(404, "项目不存在或无更新字段")
    return {"ok": True}


@app.delete("/api/projects/{project_id}")
async def project_delete_api(project_id: int) -> dict:
    if not db.project_delete(project_id):
        raise HTTPException(404, "项目不存在")
    return {"ok": True}


# ================================================================ 面试复盘
@app.post("/api/review/analyze", response_model=ReviewResult)
async def review_analyze(req: ReviewRequest) -> ReviewResult:
    """面试复盘：总结被问了什么、提炼盲点、给出改进项与简历反哺建议。"""
    return await analyze_review(req.raw, req.company, req.position, req.resume)


@app.post("/api/review/upload", response_model=ReviewResult)
async def review_upload(
    file: UploadFile = File(...),
    company: str = Form(""),
    position: str = Form(""),
    resume: str = Form(""),
) -> ReviewResult:
    """上传面试记录文件（图片 / PDF / Word / txt）→ 本地识别 → 复盘分析。"""
    filename = file.filename or "upload.bin"
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED_EXTS:
        raise HTTPException(400, f"不支持的文件类型「{ext}」")
    data = await file.read()
    if len(data) > MAX_UPLOAD:
        raise HTTPException(400, "文件超过 10MB 上限")
    tmp = Path(tempfile.gettempdir()) / f"roa_{uuid.uuid4().hex[:8]}{ext}"
    tmp.write_bytes(data)
    try:
        text, _method = extract_file(tmp, filename)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(400, f"识别失败：{e}") from e
    finally:
        tmp.unlink(missing_ok=True)
    if not text.strip():
        raise HTTPException(400, "未识别到文字，请改用文本粘贴或换一张清晰截图")
    return await analyze_review(text, company, position, resume)


@app.post("/api/review/save")
async def review_save_api(req: ReviewSave) -> dict:
    r = req.review
    rid = db.review_save(
        company=r.company, position=r.position, raw_text=req.raw, summary=r.summary,
        questions=r.questions, weaknesses=r.weaknesses, actions=r.actions,
        score=r.score, job_id=req.job_id,
    )
    return {"id": rid, "ok": True}


@app.get("/api/reviews")
async def reviews_list() -> list[dict]:
    return db.review_list(limit=30)


@app.get("/api/reviews/{rid}")
async def review_get(rid: int) -> dict:
    r = db.review_get(rid)
    if not r:
        raise HTTPException(404, "复盘记录不存在")
    return r


@app.delete("/api/reviews/{rid}")
async def review_delete(rid: int) -> dict:
    if not db.review_delete(rid):
        raise HTTPException(404, "复盘记录不存在")
    return {"ok": True}


# ================================================================ 知识库
@app.get("/api/kb/list")
async def kb_list_api() -> list[dict]:
    return kb_list()


@app.post("/api/kb/add")
async def kb_add(
    title: str = Form(...),
    content: str = Form(""),
    tags: str = Form(""),
    file: UploadFile | None = File(None),
) -> dict:
    """新增知识库文档：可纯文本粘贴，也可上传文件（复用本地识别）。"""
    text = (content or "").strip()
    source = "paste"
    if file is not None:
        filename = file.filename or "upload.bin"
        ext = Path(filename).suffix.lower()
        if ext not in ALLOWED_EXTS:
            raise HTTPException(400, f"不支持的文件类型「{ext}」")
        data = await file.read()
        if len(data) > MAX_UPLOAD:
            raise HTTPException(400, "文件超过 10MB 上限")
        tmp = Path(tempfile.gettempdir()) / f"roa_{uuid.uuid4().hex[:8]}{ext}"
        tmp.write_bytes(data)
        try:
            text, _method = extract_file(tmp, filename)
        except Exception as e:  # noqa: BLE001
            raise HTTPException(400, f"识别失败：{e}") from e
        finally:
            tmp.unlink(missing_ok=True)
        source = filename
    if len(text.strip()) < 10:
        raise HTTPException(400, "文档内容过少（<10 字），请粘贴更完整的文本或重新上传")

    doc_id = add_doc(title=title or source, content=text, source=source, tags=tags)
    return {"id": doc_id, "chars": len(text), "ok": True}


@app.post("/api/kb/ingest", response_model=KBIngestResult)
async def kb_ingest(
    raw: str = Form(""),
    hint: str = Form(""),
    files: list[UploadFile] = File(default=[]),
) -> KBIngestResult:
    """喂数据 → 自动识别（图片 OCR / PDF / Word / txt）→ 整理归纳 → 返回预览（不落库）。

    支持三种喂入方式，可同时混用：
    - raw：直接粘贴的文字
    - files：粘贴的图片 / 上传的 文字/图片/文档（多个文件会依次识别后拼接）
    返回 AI 生成的标题 / 摘要 / 要点 / 标签，前端展示预览，用户确认后再调用 /api/kb/add 入库。
    """
    text = (raw or "").strip()
    source = "paste"
    method = "paste"

    if files:
        for file in files:
            filename = file.filename or "upload.bin"
            ext = Path(filename).suffix.lower()
            if ext not in ALLOWED_EXTS:
                raise HTTPException(400, f"不支持的文件类型「{ext}」")
            data = await file.read()
            if len(data) > MAX_UPLOAD:
                raise HTTPException(400, "文件超过 10MB 上限")
            tmp = Path(tempfile.gettempdir()) / f"roa_{uuid.uuid4().hex[:8]}{ext}"
            tmp.write_bytes(data)
            try:
                ftext, fmethod = extract_file(tmp, filename)
            except Exception as e:  # noqa: BLE001
                raise HTTPException(400, f"识别失败：{e}") from e
            finally:
                tmp.unlink(missing_ok=True)
            if ftext.strip():
                text = (text + "\n\n" + ftext).strip() if text else ftext.strip()
            method = fmethod
            source = filename

    if len(text) < 10:
        raise HTTPException(400, "内容过少（<10 字），请粘贴更完整的文字、图片或上传文件")

    org = await organize_text(text, hint=hint, source=source)
    content = compose_kb_content(org["summary"], org["points"], text)

    return KBIngestResult(
        llm_mode=org.get("llm_mode", False),
        title=org["title"],
        summary=org["summary"],
        points=org["points"],
        tags=org["tags"],
        content=content,
        raw_text=text,
        chars=len(text),
        method=method,
        source=source,
    )


@app.delete("/api/kb/{doc_id}")
async def kb_delete_api(doc_id: int) -> dict:
    if not db.kb_delete(doc_id):
        raise HTTPException(404, "文档不存在")
    return {"ok": True}


@app.post("/api/kb/ask", response_model=KBAskResult)
async def kb_ask(req: AskRequest) -> KBAskResult:
    """知识库问答：检索知识库 → LLM 生成（无 LLM 返回可溯源片段）。"""
    return await ask_kb(req.question)


# ================================================================ 记录中心
@app.post("/api/record/add", response_model=RecordResult)
async def record_add(
    raw: str = Form(""),
    kind: str = Form(""),
    files: list[UploadFile] = File(default=[]),
) -> RecordResult:
    """随手记一条求职/面试 → 自动识别（图片 OCR / PDF / Word / 文档）+ 归纳 + 落库。

    三种喂入方式可混用：
    - raw：直接粘贴的文字
    - files：粘贴的图片 / 上传的文字·图片·文档（多个文件依次识别后拼接）
    - kind：可选类型提示（求职记录 / 面试记录），不填则由模型/规则自动判断
    返回结构化归纳结果，并直接落库（records 表）。
    """
    text = (raw or "").strip()
    source = "paste"
    method = "paste"

    if files:
        for file in files:
            filename = file.filename or "upload.bin"
            ext = Path(filename).suffix.lower()
            if ext not in ALLOWED_EXTS:
                raise HTTPException(400, f"不支持的文件类型「{ext}」")
            data = await file.read()
            if len(data) > MAX_UPLOAD:
                raise HTTPException(400, "文件超过 10MB 上限")
            tmp = Path(tempfile.gettempdir()) / f"roa_{uuid.uuid4().hex[:8]}{ext}"
            tmp.write_bytes(data)
            try:
                ftext, fmethod = extract_file(tmp, filename)
            except Exception as e:  # noqa: BLE001
                raise HTTPException(400, f"识别失败：{e}") from e
            finally:
                tmp.unlink(missing_ok=True)
            if ftext.strip():
                text = (text + "\n\n" + ftext).strip() if text else ftext.strip()
            method = fmethod
            source = filename

    if len(text) < 10:
        raise HTTPException(400, "内容过少（<10 字），请粘贴更完整的文字、图片或上传文件")

    org = await summarize_record(text, hint=kind, source=source)
    rid = db.record_create(
        kind=org["kind"],
        company=org["company"],
        position=org["position"],
        status=org["status"],
        title=org["title"],
        raw_text=text,
        summary=org["summary"],
        points=org["points"],
        tags=org["tags"],
        source=source,
    )
    return RecordResult(
        llm_mode=org.get("llm_mode", False),
        id=rid,
        kind=org["kind"],
        status=org["status"],
        company=org["company"],
        position=org["position"],
        title=org["title"],
        summary=org["summary"],
        points=org["points"],
        tags=org["tags"],
        raw_text=text,
        chars=len(text),
        method=method,
        source=source,
    )


@app.get("/api/records", response_model=list[dict])
async def records_list(kind: str = "", status: str = "") -> list[dict]:
    """记录列表（按类型/进度筛选，时间倒序）。"""
    return db.record_list(kind=kind, status=status, limit=300)


@app.delete("/api/records/{rid}")
async def record_delete_api(rid: int) -> dict:
    if not db.record_delete(rid):
        raise HTTPException(404, "记录不存在")
    return {"ok": True}


# ================================================================ 智能投递
@app.get("/api/delivery/profile")
async def delivery_profile() -> dict:
    """读取用户自己的简历画像（匹配基准）。"""
    content = get_profile()
    return {"content": content, "chars": len(content)}


@app.post("/api/delivery/profile")
async def delivery_profile_set(req: DeliveryProfileReq) -> dict:
    """保存简历画像（作为岗位匹配与定向策略的基准）。"""
    set_profile(req.content)
    return {"ok": True, "chars": len(req.content)}


@app.get("/api/delivery/strategy", response_model=DeliveryStrategy)
async def delivery_strategy() -> DeliveryStrategy:
    """基于简历画像 + 知识库/系统上下文，生成定向投递策略。"""
    profile = get_profile()
    if not profile.strip():
        raise HTTPException(400, "请先在「智能投递 → 我的简历」填写简历画像，再生成策略")
    kb_docs = db.kb_list()
    kb_context = "\n".join(f"- {d['title']}（{d.get('tags','')}）" for d in kb_docs[:20])
    return await analyze_targeting(profile, kb_context)


@app.get("/api/delivery/sessions")
async def delivery_sessions() -> list[dict]:
    """各平台登录会话状态（未连接也会返回默认占位）。"""
    existing = {s["platform"]: s for s in db.delivery_session_list()}
    result = []
    for p, meta in PLATFORMS.items():
        s = existing.get(p) or {"platform": p, "status": "disconnected", "last_login": "",
                                "expires_at": "", "message": ""}
        s = dict(s)
        s["label"] = meta["label"]
        s["login"] = meta["login"]
        s["daily_cap"] = meta["daily_cap"]
        result.append(s)
    return result


@app.post("/api/delivery/connect")
async def delivery_connect(platform: str = Form(...), live: bool = Form(False)) -> dict:
    """连接平台：live 模式打开浏览器手动扫码；mock 模式直接标记就绪。

    真实登录由 delivery_runner.py 子进程驱动，登录成功后回写会话状态，前端轮询即可。
    """
    if platform not in PLATFORMS:
        raise HTTPException(400, f"未知平台：{platform}")
    if live:
        db.delivery_session_upsert(platform, status="connecting", message="已启动浏览器，请手动扫码登录…")
        runner = Path(__file__).resolve().parent / "delivery_runner.py"
        subprocess.Popen(
            [sys.executable, str(runner), "login", "--platform", platform],
            env={**os.environ, "DELIVERY_LIVE": "1"},
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True,
        )
        return {"ok": True, "status": "connecting", "message": "已在弹出浏览器中打开登录页，请完成扫码"}
    db.delivery_session_upsert(
        platform, status="ready",
        last_login=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        expires_at=(datetime.now() + timedelta(days=6)).strftime("%Y-%m-%d %H:%M:%S"),
        message="mock 模式：跳过真实扫码登录（开启 live 后需手动扫码）",
    )
    return {"ok": True, "status": "ready", "message": "mock 模式已就绪（未连接真实账号）"}


@app.post("/api/delivery/search")
async def delivery_search(
    platform: str = Form(...), keyword: str = Form("AI 应用开发"), city: str = Form(""),
    live: bool = Form(False),
) -> dict:
    """检索岗位 → LLM/规则匹配打分 → 落库 → 返回匹配结果。"""
    if platform not in PLATFORMS:
        raise HTTPException(400, f"未知平台：{platform}")
    profile = get_profile()
    if not profile.strip():
        raise HTTPException(400, "请先填写简历画像，否则无法匹配")

    # 1) 取岗位（mock 直接生成样本；live 调用 runner 子进程解析）
    if live:
        runner = Path(__file__).resolve().parent / "delivery_runner.py"
        try:
            proc = subprocess.run(
                [sys.executable, str(runner), "search", "--platform", platform,
                 "--keyword", keyword, "--city", city],
                capture_output=True, text=True, timeout=120,
            )
            out = json.loads(proc.stdout) if proc.stdout.strip() else {"ok": False, "jobs": []}
        except Exception as e:  # noqa: BLE001
            out = {"ok": False, "jobs": [], "message": f"live 检索失败：{e}"}
        jobs = out.get("jobs", [])
    else:
        jobs = generate_mock_jobs(platform, keyword, city, n=12)

    # 2) 匹配打分（LLM 优先 + 规则兜底）
    kb_docs = db.kb_list()
    kb_context = "\n".join(f"- {d['title']}（{d.get('tags','')}）" for d in kb_docs[:20])
    jobs = await match_jobs(profile, kb_context, jobs)

    # 3) 落库（按 platform+job_key 去重）
    mode = "LLM" if settings.llm_enabled else "规则引擎"
    for j in jobs:
        j["id"] = db.delivery_job_create(
            platform=j["platform"], job_key=j["job_key"], title=j["title"], company=j["company"],
            city=j["city"], salary=j["salary"], url=j["url"], jd_text=j["jd_text"],
            match_score=j.get("match_score", 0), reasons=j.get("reasons", []), tags=j.get("tags", ""),
        )
    db.delivery_log_add(platform, "search", keyword, f"检索「{keyword}」返回 {len(jobs)} 个岗位，匹配模式={mode}")
    return {"ok": True, "platform": platform, "count": len(jobs), "mode": mode, "jobs": jobs}


@app.get("/api/delivery/jobs", response_model=list[DeliveryJob])
async def delivery_jobs(platform: str = "", status: str = "") -> list[dict]:
    """岗位列表（按平台 / 状态筛选，按匹配分倒序）。"""
    return db.delivery_job_list(platform=platform, status=status, limit=300)


@app.post("/api/delivery/approve")
async def delivery_approve(req: DeliveryApproveReq) -> dict:
    """批准岗位进入投递队列；可选 auto_threshold 批量自动批准。"""
    n = 0
    for jid in (req.ids or []):
        if db.delivery_job_update(jid, status="approved"):
            n += 1
    if req.auto_threshold is not None:
        for j in db.delivery_job_list(status="pending"):
            if j["match_score"] >= req.auto_threshold:
                if db.delivery_job_update(j["id"], status="approved"):
                    n += 1
    return {"ok": True, "approved": n}


@app.post("/api/delivery/skip")
async def delivery_skip(ids: list[int] = Form(...)) -> dict:
    """批量跳过（不投递）指定岗位。"""
    n = 0
    for jid in ids:
        if db.delivery_job_update(jid, status="skipped"):
            n += 1
    return {"ok": True, "skipped": n}


@app.post("/api/delivery/start")
async def delivery_start(platform: str = Form(...), live: bool = Form(False)) -> dict:
    """启动投递活动：对 approved 岗位按安全控制器拟人化投递。mock 模拟，live 真实驱动。"""
    if platform not in PLATFORMS:
        raise HTTPException(400, f"未知平台：{platform}")
    if campaign_status()["running"]:
        raise HTTPException(409, "已有投递活动进行中，请先停止")
    approved = db.delivery_job_list(platform=platform, status="approved")
    if not approved:
        raise HTTPException(400, "没有「已批准」的岗位，请先在匹配结果中批准（或设自动批准阈值）")
    asyncio.create_task(run_campaign(platform, live=live))
    return {"ok": True, "message": f"已启动投递活动（{platform}，待投递 {len(approved)} 个）"}


@app.post("/api/delivery/stop")
async def delivery_stop() -> dict:
    """停止进行中的投递活动。"""
    campaign_status()["running"] = False
    return {"ok": True, "message": "已发送停止信号"}


@app.get("/api/delivery/status")
async def delivery_status() -> dict:
    """活动运行状态（前端轮询）。"""
    st = campaign_status()
    return {"running": st["running"], "platform": st["platform"],
            "started_at": st["started_at"], "applied": st["applied"]}


@app.get("/api/delivery/logs")
async def delivery_logs(limit: int = 200) -> list[dict]:
    """投递审计日志（防拦截诊断 + 透明可追溯）。"""
    return db.delivery_log_list(limit=limit)


@app.get("/api/delivery/settings")
async def delivery_settings_get() -> dict:
    """读取防拦截安全配置。"""
    return safety_config()


@app.post("/api/delivery/settings")
async def delivery_settings_set(key: str = Form(...), value: str = Form(...)) -> dict:
    """修改单条安全配置（min_match_score / delay_min / delay_max / break_every / business_hours_only）。"""
    safety_set(key, value)
    return {"ok": True}


# ================================================================ 后台管理：求职记录
@app.get("/api/jobs")
async def job_list(status: str = "") -> list[dict]:
    return db.job_list(status=status)


@app.post("/api/jobs")
async def job_create(req: JobCreate) -> dict:
    job_id = db.job_create(req.company, req.position, req.jd, req.note)
    return {"id": job_id, "ok": True}


@app.get("/api/jobs/{job_id}")
async def job_detail(job_id: int) -> dict:
    row = db.job_get(job_id)
    if not row:
        raise HTTPException(404, "求职记录不存在")
    row["greetings"] = db.greeting_list(job_id=job_id)
    row["interviews"] = db.interview_list(job_id=job_id)
    return row


@app.put("/api/jobs/{job_id}")
async def job_update(job_id: int, req: JobUpdate) -> dict:
    if not db.job_update(job_id, **req.model_dump(exclude_none=True)):
        raise HTTPException(404, "求职记录不存在或未变更")
    return {"ok": True}


@app.delete("/api/jobs/{job_id}")
async def job_delete(job_id: int) -> dict:
    if not db.job_delete(job_id):
        raise HTTPException(404, "求职记录不存在")
    return {"ok": True}


# ================================================================ 后台管理：简历版本
@app.get("/api/resumes")
async def resume_list() -> list[dict]:
    return db.resume_list()


@app.post("/api/resumes")
async def resume_create(req: ResumeCreate) -> dict:
    resume_id = db.resume_create(req.label, req.content)
    return {"id": resume_id, "ok": True}


@app.put("/api/resumes/{resume_id}/activate")
async def resume_activate(resume_id: int) -> dict:
    if not db.resume_activate(resume_id):
        raise HTTPException(404, "简历版本不存在")
    return {"ok": True}


@app.delete("/api/resumes/{resume_id}")
async def resume_delete(resume_id: int) -> dict:
    if not db.resume_delete(resume_id):
        raise HTTPException(404, "简历版本不存在")
    return {"ok": True}


# ================================================================ 后台管理：打招呼语历史
@app.post("/api/greetings/save")
async def greeting_save(req: GreetingSave) -> dict:
    gid = db.greeting_save(req.job_id, req.style, req.content)
    return {"id": gid, "ok": True}


@app.get("/api/greetings/history")
async def greeting_history(job_id: int = 0) -> list[dict]:
    return db.greeting_list(job_id=job_id)


@app.delete("/api/greetings/{greeting_id}")
async def greeting_delete(greeting_id: int) -> dict:
    if not db.greeting_delete(greeting_id):
        raise HTTPException(404, "记录不存在")
    return {"ok": True}


# ================================================================ 仪表盘
@app.get("/api/dashboard")
async def dashboard() -> dict:
    return db.dashboard()


app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
