"""面试复盘：面试后把记录喂进来，自动总结、提炼盲点，并反哺简历与知识库。

分析链路：
    面试记录原文 ─▶ ① 提取被问到的问题
                 ─▶ ② 识别「没答好」的信号
                 ─▶ ③ 抽取涉及的技术关键词
                 ─▶ ④ 与简历/历史缺陷库交叉比对，找出「被问到但没有」的能力
                 ─▶ ⑤ 输出总结 + 盲点 + 下次改进项 + 简历反哺建议

关键点：复盘不是写日记，而是要**落到下一次能改的动作上**，并把「被问到但简历没有」
的关键词回写给缺陷库 —— 这样面试数据就进入了简历优化的闭环。

两条模式：LLM 优先（理解更准），规则兜底（离线可用）
"""
from __future__ import annotations

import logging
import re
from typing import Any

from app import db, llm
from app.config import settings
from app.schemas import ReviewResult
from app.tools.rule_engine import extract_keywords

logger = logging.getLogger("resume-agent.review")

# ---------- 「没答好」的信号词：出现即认为是当场卡壳的点
_BAD_SIGNALS = [
    "没答上来", "没答上", "答不上来", "答不出", "不知道", "不太清楚", "不清楚",
    "卡住了", "卡了", "懵了", "蒙了", "忘了", "忘记了", "记不清", "没准备",
    "不太会", "没接触过", "没用过", "说不出来", "答得不好", "答得一般",
    "没说出来", "有点慌", "不太熟", "不熟", "被问住了", "问住了",
]
# ---------- 「答得不错」的信号词
_GOOD_SIGNALS = ["答得不错", "答得挺好", "对答如流", "讲得很清楚", "回答得很好", "顺利答出", "答上了", "说清楚了"]

_Q_RE = re.compile(r"[^\n。！？；]{6,90}[？?]")
_LINE_SPLIT = re.compile(r"[\n。；;!！]+")


def _sentences(text: str) -> list[str]:
    return [s.strip() for s in _LINE_SPLIT.split(text) if len(s.strip()) >= 4]


def _around(text: str, word: str, window: int = 34) -> str:
    """取关键词前后的一段文字，作为「卡在哪」的证据。"""
    i = text.find(word)
    if i < 0:
        return ""
    seg = text[max(0, i - window): i + len(word) + window]
    seg = re.sub(r"\s+", " ", seg).strip()
    return ("…" if i - window > 0 else "") + seg + ("…" if i + len(word) + window < len(text) else "")


def analyze_review_rule(
    raw: str, company: str = "", position: str = "", resume_text: str = ""
) -> ReviewResult:
    raw = (raw or "").strip()
    if len(raw) < 15:
        return ReviewResult(
            llm_mode=False, company=company, position=position, score=0,
            summary="面试记录太短（少于 15 字），没法分析。把面试中被问到的问题、你怎么答的、哪里卡住了都写下来，越具体分析越准。",
            actions=["补充面试记录：至少写清「问了什么 / 我是怎么答的 / 哪里没答好」三部分"],
        )

    # ① 被问到的问题
    questions: list[str] = []
    for m in _Q_RE.findall(raw):
        q = m.strip().lstrip("0123456789.、)）•- ").strip()
        if q and q not in questions:
            questions.append(q)
    questions = questions[:12]

    # ② 卡壳点
    weaknesses: list[str] = []
    for sig in _BAD_SIGNALS:
        if sig in raw:
            ev = _around(raw, sig)
            if ev and ev not in weaknesses:
                weaknesses.append(ev)
    weaknesses = weaknesses[:8]

    # ③ 涉及的技术点
    kw_map = extract_keywords(raw)
    tech_points = list(kw_map.keys())

    # ④ 与简历交叉：被问到但简历里没有 → 真实短板
    resume_low = (resume_text or "").lower()
    asked_but_absent = [k for k in tech_points if k.lower() not in resume_low]

    # 与历史缺陷库交叉：如果这个点是老问题，重点提示
    defect_kws: set[str] = set()
    for run in db.parse_list(limit=20):
        try:
            import json
            for m in json.loads(run.get("missing") or "[]"):
                defect_kws.add((m.get("keyword") or "").strip())
        except Exception:  # noqa: BLE001
            continue
    old_problems = [k for k in asked_but_absent if k in defect_kws]

    # ⑤ 表现评分
    score = 72
    score -= min(30, len(weaknesses) * 5)
    score += min(15, sum(1 for g in _GOOD_SIGNALS if g in raw) * 5)
    if len(raw) < 120:
        score -= 5  # 记录太简略，可信度打折
    score = max(25, min(95, score))

    answered_well = [_around(raw, g, 30) for g in _GOOD_SIGNALS if g in raw][:5]
    if not answered_well and tech_points:
        answered_well = [f"涉及 {('、'.join(tech_points[:5]))} 等技术点，能聊起来说明有底子"]

    # 总结
    if weaknesses:
        head = f"本次面试共记录 {len(questions)} 个问题，识别到 {len(weaknesses)} 处卡壳，表现约 {score} 分。"
    else:
        head = f"本次面试共记录 {len(questions)} 个问题，未发现明显卡壳，表现约 {score} 分。"
    if tech_points:
        head += f" 考察重点是：{'、'.join(tech_points[:6])}。"
    if old_problems:
        head += f" ⚠️ 其中 {'、'.join(old_problems[:3])} 是你简历里反复出现的老短板 —— 这次又被问到了。"

    # 改进项
    actions: list[str] = []
    for w in weaknesses[:3]:
        actions.append(f"把这个点补到能讲 3 分钟的深度：{w[:40]}…（讲清原理 + 你踩过的坑 + 怎么解决的）")
    for k in (old_problems or asked_but_absent)[:3]:
        actions.append(f"「{k}」面试被问到但简历里没有 —— 补一个用到它的项目或学习记录，下次才能有的聊")
    if not actions:
        actions.append("整体答得不错。把这次被问到的高频问题存进知识库，下次面试前翻一遍")
    actions.append("把这次的面试记录存进知识库 —— 同一家公司的二面/三面很可能接着问这些")

    # 简历反哺
    resume_feedback: list[str] = []
    for k in asked_but_absent[:5]:
        resume_feedback.append(f"面试问到了「{k}」，但你的简历里没有 —— 若实际用过，务必补进项目描述（这是最直接的加分项）")
    if not resume_feedback:
        resume_feedback.append("面试涉及的技术点简历里都有覆盖，说明简历与岗位描述是一致的，保持")
    if len(questions) >= 6:
        resume_feedback.append("被问问题较多，说明简历写得够吸引人、HR 想深挖 —— 但要确保每个写上去的点都能讲到底")

    return ReviewResult(
        llm_mode=False, company=company, position=position, score=score,
        summary=head, questions=questions,
        answered_well=list(dict.fromkeys(answered_well)) or answered_well,
        weaknesses=list(dict.fromkeys(weaknesses)) or weaknesses or ["未识别到明显卡壳（如果确实有，把「哪里没答好」写得更明确些）"],
        actions=actions, resume_feedback=resume_feedback,
    )


# ================================================================ LLM 模式
async def analyze_review_llm(
    raw: str, company: str, position: str, resume_text: str
) -> ReviewResult | None:
    system = (
        "你是一位资深技术面试官，擅长从候选人的面试记录里找出真正的问题。"
        "要求：结论具体、可执行，禁止空话套话；只根据记录内容判断，不臆测。"
    )
    user = (
        f"公司：{company}\n岗位：{position}\n\n面试记录原文：\n{raw[:3000]}\n\n"
        f"{('候选人简历要点：' + resume_text[:1000]) if resume_text else ''}\n\n"
        "请分析并输出 JSON：\n"
        "{\"score\":0-100,\"summary\":\"整体总结\",\"questions\":[\"被问到的问题\"],"
        "\"answered_well\":[\"答得不错的地方\"],\"weaknesses\":[\"暴露的知识盲点\"],"
        "\"actions\":[\"下次面试前的改进项\"],\"resume_feedback\":[\"简历该调整的地方\"]}"
    )
    try:
        data = await llm.chat_json([{"role": "system", "content": system}, {"role": "user", "content": user}])
    except Exception as e:  # noqa: BLE001
        logger.warning("LLM 复盘失败，回退规则模式: %s", e)
        return None
    if not data or not data.get("summary"):
        return None
    return ReviewResult(
        llm_mode=True, company=company, position=position,
        score=int(data.get("score") or 70), summary=str(data.get("summary", "")),
        questions=[str(x) for x in data.get("questions", [])][:12],
        answered_well=[str(x) for x in data.get("answered_well", [])][:8],
        weaknesses=[str(x) for x in data.get("weaknesses", [])][:8],
        actions=[str(x) for x in data.get("actions", [])][:8],
        resume_feedback=[str(x) for x in data.get("resume_feedback", [])][:6],
    )


async def analyze_review(
    raw: str, company: str = "", position: str = "", resume_text: str = ""
) -> ReviewResult:
    if settings.llm_enabled:
        r = await analyze_review_llm(raw, company, position, resume_text)
        if r:
            return r
    return analyze_review_rule(raw, company, position, resume_text)


def to_db_payload(r: ReviewResult, raw: str) -> dict[str, Any]:
    return {
        "company": r.company, "position": r.position, "raw_text": raw,
        "summary": r.summary, "questions": r.questions,
        "weaknesses": r.weaknesses, "actions": r.actions, "score": r.score,
    }
