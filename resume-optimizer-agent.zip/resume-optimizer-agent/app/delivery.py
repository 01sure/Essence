"""智能投递引擎：简历画像 × 岗位匹配 × 定向策略 × 防拦截安全控制器。

设计要点：
- 简历画像（delivery_profile）作为匹配基准；知识库 + 系统上下文作为「定向策略」输入。
- 岗位匹配：LLM 优先（批量打分 + 理由 + 针对性备注），失败回退规则引擎（关键词交集）。
- 防拦截（诚实说明）：本模块只做「降低被拦截概率」的拟人化护栏，无法 100% 保证不被风控。
  措施包括：单平台每日上限、最低匹配阈值、拟人化随机延时、渐入式节奏、长间隔休息、
  单会话串行、遇到验证码/异常自动暂停。真实自动投递需在用户手动扫码登录后由其本人承担风险。
- mock 模式：无需真实账号即可演示/测试完整流程；live 模式由 delivery_runner.py 驱动浏览器。
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import random
import re
from datetime import datetime, timedelta
from typing import Any, Iterable

from app import db
from app.config import settings
from app.llm import LLMError, chat_json

logger = logging.getLogger("resume-agent.delivery")

# 平台元数据：默认日上限来自 auto-resume-submitter 技能的合规建议
PLATFORMS: dict[str, dict[str, Any]] = {
    "boss":    {"label": "Boss直聘", "daily_cap": 30, "login": "App 扫码登录", "default_city": "全国"},
    "liepin":  {"label": "猎聘", "daily_cap": 20, "login": "App 扫码 / 短信登录", "default_city": "全国"},
    "zhilian": {"label": "智联招聘", "daily_cap": 20, "login": "App 扫码 / 短信登录", "default_city": "全国"},
}

DELIVERY_SYSTEM = (
    "你是一名求职投递策略助手。你的任务是根据候选人的简历画像，"
    "对招聘平台检索到的岗位做匹配度评估，并给出针对性的投递策略。"
    "坚持真实原则：理由必须基于简历中真实存在的内容，不得虚构技能或经历。"
)

# 模块级活动状态（内存态，配合 DB 日志与岗位状态持久化）
CAMPAIGN: dict[str, Any] = {"running": False, "platform": "", "started_at": "", "applied": 0, "task": None}

_KW_RE = re.compile(r"[\u4e00-\u9fa5]{2,}|[A-Za-z][A-Za-z0-9+.#]{1,}")


# ================================================================ 简历画像
def get_profile() -> str:
    return db.delivery_profile_get()


def set_profile(content: str) -> None:
    db.delivery_profile_set(content or "")


# ================================================================ 安全控制器
def safety_config() -> dict[str, Any]:
    """读取防拦截安全配置（DB 覆盖默认值）。"""
    return {
        "min_match_score": int(db.delivery_setting_get("min_match_score", "60") or 60),
        "delay_min": int(db.delivery_setting_get("delay_min", "15") or 15),
        "delay_max": int(db.delivery_setting_get("delay_max", "45") or 45),
        "break_every": int(db.delivery_setting_get("break_every", "8") or 8),
        "business_hours_only": db.delivery_setting_get("business_hours_only", "0") == "1",
    }


def safety_set(key: str, value: str) -> None:
    db.delivery_setting_set(key, str(value))


def _next_delay(cfg: dict[str, Any], step: int) -> int:
    """拟人化随机延时：前 3 步渐入（更长），之后在 [min,max] 间抖动。"""
    base = random.randint(cfg["delay_min"], cfg["delay_max"])
    if step < 3:
        base = int(base * 1.8)
    return base


def _is_business_hours() -> bool:
    h = datetime.now().hour
    return 9 <= h < 21


def _daily_applied(platform: str) -> int:
    """今天已投递数量（按 applied_at 日期统计）。"""
    today = datetime.now().strftime("%Y-%m-%d")
    with db._conn() as conn:  # noqa: SLF001 复用连接辅助
        n = conn.execute(
            "SELECT COUNT(*) c FROM delivery_jobs WHERE platform=? AND status='applied' AND applied_at>=?",
            (platform, today),
        ).fetchone()["c"]
    return int(n)


# ================================================================ 关键词提取（规则兜底用）
def _keywords(text: str) -> set[str]:
    toks = set(_KW_RE.findall(text or ""))
    # 过滤纯停用/过短噪声
    stop = {"公司", "有限", "股份", "科技", "网络", "集团", "岗位", "职位", "招聘", "经验", "本科", "硕士",
            "负责", "相关", "以上", "优先", "熟悉", "使用", "能力", "团队", "开发", "工程师", "良好", "沟通"}
    return {t for t in toks if t not in stop and len(t) >= 2}


def _rule_score(resume_kw: set[str], jd_text: str) -> tuple[int, list[str]]:
    jd_kw = _keywords(jd_text)
    if not jd_kw:
        return 50, []
    hit = sorted(resume_kw & jd_kw, key=lambda k: -len(k))
    # 命中即加分：每个命中 22 分（封顶 100）；弱匹配（1~2 命中）自然低于阈值，便于阈值筛选
    score = min(100, len(hit) * 22)
    return score, hit[:6]


# ================================================================ 岗位匹配（LLM 优先 + 规则兜底）
async def match_jobs(resume_text: str, kb_context: str, jobs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """对检索到的岗位批量打分 + 理由 + 针对性备注。

    返回时在入参 job dict 上补充：match_score / reasons / tags / note。
    """
    resume_kw = _keywords(resume_text)
    if not jobs:
        return jobs

    if settings.llm_enabled:
        try:
            payload = {
                "resume": (resume_text or "")[:4000],
                "kb_context": (kb_context or "")[:2000],
                "jobs": [
                    {"job_key": j.get("job_key"), "title": j.get("title"),
                     "company": j.get("company"), "jd": (j.get("jd_text") or "")[:1500]}
                    for j in jobs
                ],
            }
            out = await chat_json(
                [{"role": "user", "content": json.dumps(payload, ensure_ascii=False)}],
                system=DELIVERY_SYSTEM,
                temperature=0.2,
                max_tokens=4000,
            )
            scored = {item.get("job_key"): item for item in (out.get("jobs") or [])}
            for j in jobs:
                s = scored.get(j.get("job_key"))
                if s and isinstance(s, dict):
                    j["match_score"] = int(s.get("score", j.get("match_score", 0)) or 0)
                    j["reasons"] = s.get("reasons") or []
                    j["tags"] = s.get("tags") or ""
                    j["note"] = s.get("note") or ""
                else:
                    sc, hit = _rule_score(resume_kw, j.get("jd_text", ""))
                    j.setdefault("match_score", sc)
                    j.setdefault("reasons", [f"命中关键词：{h}" for h in hit] or ["（规则兜底）未提取到明确命中"])
                    j.setdefault("tags", ",".join(hit[:5]))
                    j.setdefault("note", "")
            return jobs
        except (LLMError, Exception) as e:  # noqa: BLE001
            logger.warning("岗位 LLM 匹配失败，回退规则引擎：%s", e)

    # 规则兜底
    for j in jobs:
        sc, hit = _rule_score(resume_kw, j.get("jd_text", ""))
        j["match_score"] = sc
        j["reasons"] = [f"简历命中关键词：{h}" for h in hit] or ["（规则兜底）未提取到明确命中"]
        j["tags"] = ",".join(hit[:5])
        j["note"] = "（规则引擎）建议突出：" + "、".join(hit[:3]) if hit else ""
    return jobs


async def analyze_targeting(resume_text: str, kb_context: str) -> dict[str, Any]:
    """基于简历画像 + 知识库/系统上下文，给出定向投递策略。"""
    if settings.llm_enabled:
        try:
            out = await chat_json(
                [{"role": "user", "content": json.dumps(
                    {"resume": (resume_text or "")[:4000], "kb_context": (kb_context or "")[:2500]},
                    ensure_ascii=False)}],
                system=DELIVERY_SYSTEM,
                temperature=0.3, max_tokens=1500,
            )
            return {
                "platforms": out.get("platforms") or list(PLATFORMS.keys()),
                "keywords": out.get("keywords") or [],
                "salary_expectation": out.get("salary_expectation") or "",
                "blacklist": out.get("blacklist") or [],
                "summary": out.get("summary") or "",
                "llm_mode": True,
            }
        except (LLMError, Exception) as e:  # noqa: BLE001
            logger.warning("定向策略 LLM 分析失败，回退规则：%s", e)

    # 规则兜底：从简历抽取高频技能作为关键词，平台全开
    kw = sorted(_keywords(resume_text), key=lambda k: -len(k))[:10]
    return {
        "platforms": list(PLATFORMS.keys()),
        "keywords": kw,
        "salary_expectation": "",
        "blacklist": ["外包", "驻场"],
        "summary": "（规则引擎）根据简历画像自动抽取高频技能作为检索关键词，建议优先 Boss直聘/猎聘的 AI 应用开发类岗位。",
        "llm_mode": False,
    }


# ================================================================ mock 岗位生成（演示/测试）
def generate_mock_jobs(platform: str, keyword: str, city: str, n: int = 12) -> list[dict[str, Any]]:
    """生成贴近真实结构的样本岗位，使 mock 模式也能完整演示匹配→审批→投递。"""
    samples = [
        ("AI应用开发工程师", "腾讯", "25-45K·14薪", "本科·3-5年",
         "负责 AI 应用平台的设计与开发，熟练 Python、FastAPI、LangChain，有 RAG / 向量数据库落地经验，熟悉大模型微调与 Agent 编排。"),
        ("大模型应用工程师", "字节跳动", "30-50K·15薪", "本科·3-5年",
         "基于大语言模型构建企业级 Agent，要求 Python、LangChain、RAG 检索增强，掌握向量库（Milvus/FAISS）与 FastAPI 服务化部署。"),
        ("Python后端开发工程师", "美团", "20-35K·13薪", "本科·1-3年",
         "使用 Python + FastAPI 开发高并发后端服务，熟悉 MySQL/Redis，有 LLM 应用或 RAG 经验者优先。"),
        ("AI Agent 开发工程师", "阿里云", "28-48K·16薪", "硕士·3-5年",
         "研发智能体编排框架，要求深入理解 LLM、Agent、RAG 与工具调用，精通 Python 与 FastAPI，有生产级落地案例。"),
        ("算法工程师（大模型方向）", "百度", "30-55K·14薪", "硕士·经验不限",
         "大模型微调、Prompt 工程与 RAG 系统建设，熟悉 LangChain、PyTorch，有检索增强生成项目经验。"),
        ("AI实施工程师", "360", "15-25K·13薪", "本科·1-3年",
         "负责 AI 产品交付与部署，熟悉 Docker、Linux，能独立部署 Qwen 等开源大模型，有客户驻场经验优先。"),
        ("后端开发工程师（AI方向）", "京东", "22-38K·14薪", "本科·3-5年",
         "参与 AI 中台后端开发，Python/FastAPI，掌握 RAG 与向量检索，理解 Agent 工作流。"),
        ("智能办公产品后端", "金山", "18-30K·13薪", "本科·1-3年",
         "Python 后端，参与 AI 自动化办公平台，熟悉 FastAPI、RAG，有文档解析/知识库经验优先。"),
        ("NLP 工程师", "科大讯飞", "25-45K·14薪", "硕士·3-5年",
         "自然语言处理与大模型应用，Python、LangChain、RAG，熟悉中文 NLP 与意图识别。"),
        ("AI交付工程师", "商汤", "20-35K·13薪", "本科·1-3年",
         "AI 解决方案交付，Docker 部署大模型，Linux 运维，能与客户沟通需求并落地。"),
        ("高级Python开发", "小红书", "28-50K·15薪", "本科·3-5年",
         "核心业务后端，Python + FastAPI，有 LLM/Agent 落地经验，熟悉向量数据库与检索增强。"),
        ("RAG 应用开发", "智谱AI", "30-50K·14薪", "硕士·经验不限",
         "专注检索增强生成应用，LangChain、Milvus、FastAPI，有大模型应用端到端经验。"),
    ]
    out = []
    for i in range(min(n, len(samples))):
        title, company, salary, exp, jd = samples[i]
        # 关键词检索：标题或 JD 含检索词则权重更高
        base = title if not keyword or (keyword in title or keyword in jd) else title
        out.append({
            "platform": platform,
            "job_key": f"{platform}-{i+1}-{hashlib.md5((company+title).encode()).hexdigest()[:10]}",
            "title": base,
            "company": company,
            "city": city or PLATFORMS[platform]["default_city"],
            "salary": salary,
            "url": f"https://example.com/{platform}/job/{i+1}",
            "jd_text": f"【{title}】{exp} | 薪资 {salary}\n{jd}",
        })
    return out


# ================================================================ 投递活动（mock 模拟 + live 钩子）
async def run_campaign(platform: str, live: bool = False) -> None:
    """对状态为 approved 的岗位执行投递，遵守安全控制器；mock 模式为模拟应用。"""
    cfg = safety_config()
    cap = PLATFORMS.get(platform, {}).get("daily_cap", 20)
    CAMPAIGN["running"] = True
    CAMPAIGN["platform"] = platform
    CAMPAIGN["started_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    CAMPAIGN["applied"] = 0

    approved = [j for j in db.delivery_job_list(platform=platform, status="approved")]
    total = len(approved)
    db.delivery_log_add(platform, "start", "", f"启动投递活动，待投递 {total} 个岗位（min_score={cfg['min_match_score']}）")
    if not total:
        db.delivery_log_add(platform, "warn", "", "没有处于「已批准」状态的岗位，活动结束")
        CAMPAIGN["running"] = False
        return

    step = 0
    for job in approved:
        if not CAMPAIGN["running"]:
            db.delivery_log_add(platform, "pause", "", "用户手动停止，活动结束")
            break
        if _daily_applied(platform) >= cap:
            db.delivery_log_add(platform, "pause", "", f"已达今日平台上限 {cap}，活动结束", level="warn")
            CAMPAIGN["running"] = False
            break
        if cfg["business_hours_only"] and not _is_business_hours():
            db.delivery_log_add(platform, "pause", "", "非工作时间（业务时段限制），活动暂停", level="warn")
            CAMPAIGN["running"] = False
            break

        step += 1
        delay = _next_delay(cfg, step)
        # 长间隔休息：每 N 个来一次拟人化大停顿
        if cfg["break_every"] and step % cfg["break_every"] == 0:
            big = random.randint(60, 180)
            db.delivery_log_add(platform, "pause", "", f"节奏休息 {big}s（防拦截：模拟真人间歇）")
            await asyncio.sleep(min(big, 5))  # 演示时压缩，真实环境按 big
        else:
            db.delivery_log_add(platform, "wait", job.get("title", ""), f"拟人化间隔 {delay}s（防拦截）")
            await asyncio.sleep(min(delay, 2))  # 演示时压缩延时

        try:
            if live:
                ok = await _apply_live(platform, job)
            else:
                ok = True  # mock：模拟成功投递
            if ok:
                db.delivery_job_update(job["id"], status="applied", applied_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                CAMPAIGN["applied"] += 1
                db.delivery_log_add(platform, "apply", job.get("title", ""), f"已投递：{job.get('company','')} · {job.get('title','')}")
            else:
                db.delivery_job_update(job["id"], status="failed")
                db.delivery_log_add(platform, "error", job.get("title", ""), "投递失败（live 返回未成功）", level="error")
        except Exception as e:  # noqa: BLE001
            db.delivery_job_update(job["id"], status="failed")
            db.delivery_log_add(platform, "error", job.get("title", ""), f"投递异常：{e}", level="error")

    CAMPAIGN["running"] = False
    db.delivery_log_add(platform, "done", "", f"活动结束，本次成功投递 {CAMPAIGN['applied']} 个")


async def _apply_live(platform: str, job: dict[str, Any]) -> bool:
    """live 模式：调用 delivery_runner.py 执行真实投递（需已扫码登录）。

    真实环境通过子进程驱动 Playwright；此处为钩子，失败返回 False 由上层记录。
    """
    import subprocess
    import sys
    from pathlib import Path

    runner = Path(__file__).resolve().parent / "delivery_runner.py"
    try:
        proc = subprocess.run(
            [sys.executable, str(runner), "apply", "--platform", platform, "--job-id", str(job["id"])],
            capture_output=True, text=True, timeout=120,
        )
        return proc.returncode == 0 and '"ok": true' in proc.stdout
    except Exception as e:  # noqa: BLE001
        logger.error("live apply 失败：%s", e)
        return False


def campaign_status() -> dict[str, Any]:
    return dict(CAMPAIGN)
