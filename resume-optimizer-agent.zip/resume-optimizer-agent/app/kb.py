"""知识库问答模块：文档入库 → 分块 → 检索 → 问答。

业务场景：把目标公司的介绍、岗位说明、面经、技术文档等资料入库，
面试前问「这家公司主要做什么产品」「这个岗位可能考什么」等，系统从知识库检索并作答。

两条模式：
- 规则模式（无 LLM）：检索命中的原文片段直接返回（可溯源、可离线演示）
- LLM 模式：检索结果作为上下文（RAG），由大模型生成自然语言回答

检索算法（轻量、零依赖）：
1. 文档按段落切块（超长段落按句号/逗号二次切分，保留重叠）
2. 查询词 = 规则引擎技术关键词 + 中文连续片段 + 英文单词
3. 块打分 = 命中查询词数加权（技术关键词权重更高）+ 标题命中加分
"""
from __future__ import annotations

import logging
import re
from typing import Any

from app import llm
from app.config import settings
from app.db import kb_create, kb_get, kb_list
from app.schemas import KBAskResult, KBChunk
from app.tools import rule_engine as rule

logger = logging.getLogger("resume-agent.kb")

MAX_CHUNK = 400
CHUNK_OVERLAP = 40
TOP_K = 5


# ================================================================ 分块
def _split_paragraphs(text: str) -> list[str]:
    """按空行/换行拆段，过滤太短的片段。"""
    paras: list[str] = []
    for block in re.split(r"\n\s*\n|\r\n\s*\r\n", text):
        for p in block.split("\n"):
            p = p.strip().lstrip("-*•·#").strip()
            if len(p) >= 8:
                paras.append(p)
    return paras


def _split_long(para: str) -> list[str]:
    """超长段落按句号/分号二次切分，块间保留 overlap。"""
    if len(para) <= MAX_CHUNK:
        return [para]
    # 优先在标点处切
    sentences = re.split(r"(?<=[。；;！？!?])", para)
    chunks: list[str] = []
    buf = ""
    for s in sentences:
        if len(buf) + len(s) > MAX_CHUNK and buf:
            chunks.append(buf.strip())
            buf = buf[-CHUNK_OVERLAP:] if len(buf) > CHUNK_OVERLAP else buf
        buf += s
    if buf.strip():
        chunks.append(buf.strip())
    # 若仍有超长（无标点），硬切
    final: list[str] = []
    for c in chunks:
        while len(c) > MAX_CHUNK:
            final.append(c[:MAX_CHUNK])
            c = c[MAX_CHUNK - CHUNK_OVERLAP:]
        if c.strip():
            final.append(c)
    return final or [para[:MAX_CHUNK]]


def chunk_doc(content: str, title: str, doc_id: int) -> list[KBChunk]:
    """把一个文档切成带来源的块。"""
    chunks: list[KBChunk] = []
    seen: set[str] = set()
    for para in _split_paragraphs(content):
        for c in _split_long(para):
            key = c[:60]
            if key in seen:
                continue
            seen.add(key)
            chunks.append(KBChunk(doc_id=doc_id, title=title, content=c, score=0.0))
    return chunks


# ================================================================ 查询词提取
# 常见疑问/虚词，不作为检索词
_STOP_WORDS = {
    "这家", "那个", "什么", "怎么", "为什么", "如何", "一个", "请问", "你们",
    "贵司", "我们", "多少", "哪些", "哪个", "时候", "东西", "大概", "主要",
    "这个", "那里", "哪里", "有什", "做什", "是什", "是什", "些什", "请帮",
    "帮我", "介绍", "说说", "讲讲", "知道", "想要", "可以", "能帮",
}


def _query_terms(query: str) -> tuple[list[str], list[str]]:
    """返回 (技术关键词, 通用词)。技术关键词权重更高。"""
    tech = list(rule.extract_keywords(query).keys())
    common: set[str] = set()
    # 中文片段按 2-4 字滑动窗口切词（跳过疑问/虚词）
    for seg in re.findall(r"[\u4e00-\u9fa5]+", query):
        for wlen in (4, 3, 2):
            for i in range(len(seg) - wlen + 1):
                w = seg[i:i + wlen]
                if w not in _STOP_WORDS and len(w) >= 2:
                    common.add(w)
    # 英文单词（>=3 字母，转小写）
    for w in re.findall(r"[A-Za-z]{3,}", query):
        common.add(w.lower())
    # 去重技术词里过于宽泛的
    tech = [t for t in tech if len(t) >= 2]
    return tech, list(common)


# ================================================================ 检索
def _score_chunk(chunk: KBChunk, tech: list[str], common: list[str]) -> float:
    low = chunk.content.lower()
    score = 0.0
    for t in tech:
        tl = t.lower()
        if tl in low:
            score += 3.0
            # 出现在前 80 字内再加分（摘要往往在开头）
            if tl in low[:80]:
                score += 1.0
    for c in common:
        if c.lower() in low:
            score += 1.0
    if any(t.lower() in chunk.title.lower() for t in tech):
        score += 2.0
    return score


def search_kb(query: str, top_k: int = TOP_K) -> list[KBChunk]:
    """全库检索：遍历所有文档的块，返回打分最高的 top_k 块。"""
    tech, common = _query_terms(query)
    scored: list[KBChunk] = []
    for doc in kb_list():
        full = kb_get(doc["id"])
        if not full or not full.get("content"):
            continue
        for chunk in chunk_doc(full["content"], full.get("title", ""), full["id"]):
            s = _score_chunk(chunk, tech, common)
            if s > 0:
                chunk.score = round(s, 2)
                scored.append(chunk)
    scored.sort(key=lambda c: c.score, reverse=True)
    return scored[:top_k]


# ================================================================ 问答
def _rule_answer(question: str, chunks: list[KBChunk]) -> str:
    if not chunks:
        return (
            "知识库中暂时没有检索到与「%s」相关的内容。\n"
            "建议：① 上传更多相关资料（公司介绍/面经/岗位说明）；② 换个问法，用岗位或技术关键词提问。"
        ) % question.strip()[:30]
    lines = ["根据知识库检索到以下相关内容（可溯源）：", ""]
    for i, c in enumerate(chunks[:4], 1):
        lines.append(f"【{i}】来自《{c.title}》")
        lines.append(c.content)
        lines.append("")
    return "\n".join(lines)


async def _llm_answer(question: str, chunks: list[KBChunk]) -> tuple[str, bool]:
    context = "\n\n".join(f"【文档《{c.title}》】\n{c.content}" for c in chunks[:5])
    data = await llm.chat_json(
        [
            {
                "role": "user",
                "content": (
                    "你是求职助手。根据提供的知识库资料回答用户问题，输出 JSON："
                    '{"answer": "完整回答"}\n\n'
                    "要求：\n"
                    "1. 优先基于知识库内容作答，可注明依据来源\n"
                    "2. 知识库没有的内容，明确说明「资料中未找到」，不要编造\n"
                    "3. 回答结构清晰，重点突出，300 字以内\n\n"
                    f"用户问题：{question}\n\n知识库资料：\n{context}"
                ),
            }
        ],
        max_tokens=1500,
        temperature=0.3,
    )
    return data.get("answer", ""), True


async def ask_kb(question: str) -> KBAskResult:
    """知识库问答主入口：检索 → LLM 优先 / 规则兜底。"""
    chunks = search_kb(question)
    used_llm = False
    answer = _rule_answer(question, chunks)

    if settings.llm_enabled and chunks:
        try:
            llm_answer, used_llm = await _llm_answer(question, chunks)
            if llm_answer.strip():
                answer = llm_answer
        except llm.LLMError as e:
            logger.warning("kb ask 走 LLM 失败，回退规则: %s", e)
            used_llm = False

    return KBAskResult(
        llm_mode=used_llm,
        question=question,
        answer=answer,
        chunks=chunks,
        fallback=not chunks,
    )


# ================================================================ 入库辅助
def add_doc(title: str, content: str, source: str = "", tags: str = "") -> int:
    """新增文档到知识库。content 为已提取的文本。"""
    return kb_create(title=title, content=content, source=source, tags=tags)


# ================================================================ 智能整理归纳
def _first_title(text: str, max_len: int = 24) -> str:
    """从文本里取一个自然的分句做标题（优先句号/逗号断句，避免硬截断）。"""
    seg = re.split(r"[。；;！？!?，,]", text.strip())[0].strip()
    if len(seg) >= 4:
        return seg[:max_len]
    return text.strip()[:max_len]


def _rule_organize(raw: str, hint: str = "", source: str = "") -> dict:
    """规则模式兜底：从杂乱文本中确定性提炼标题 / 摘要 / 要点 / 标签。"""
    lines = [ln.strip().lstrip("-*•·#").strip() for ln in raw.splitlines() if ln.strip()]

    title = (hint or "").strip()
    if not title and lines:
        title = _first_title(lines[0])
    if not title:
        title = _first_title(source or "未命名资料")

    flat = re.sub(r"\s+", " ", raw).strip()
    summary = flat[:120] + ("…" if len(flat) > 120 else "")

    # 要点：优先按行；单段文本则按句号/分号/叹号切句
    candidates = [ln for ln in lines[1:]]
    if not candidates:
        candidates = [s.strip() for s in re.split(r"[。；;！？!?]", flat) if len(s.strip()) >= 4]
    points: list[str] = []
    for c in candidates:
        c = c.strip()
        if len(c) < 4:
            continue
        points.append(c[:40] + ("…" if len(c) > 40 else ""))
        if len(points) >= 6:
            break

    tags = ",".join(list(rule.extract_keywords(raw).keys())[:6])

    return {"title": title, "summary": summary, "points": points, "tags": tags}


def _normalize_organize(data: dict, raw: str, hint: str, source: str) -> dict:
    """把 LLM 返回的 JSON 规整成统一结构，缺字段时用规则结果兜底。"""
    fallback = _rule_organize(raw, hint, source)
    title = str(data.get("title", "")).strip() or fallback["title"]
    summary = str(data.get("summary", "")).strip() or fallback["summary"]
    points = data.get("points") or []
    if isinstance(points, str):
        points = [p.strip() for p in re.split(r"[;\n]", points) if p.strip()]
    points = [str(p).strip() for p in points if str(p).strip()][:10] or fallback["points"]
    tags = data.get("tags") or ""
    if isinstance(tags, list):
        tags = ",".join(str(t) for t in tags)
    tags = str(tags).strip() or fallback["tags"]
    return {"title": title, "summary": summary, "points": points, "tags": tags}


async def organize_text(raw: str, hint: str = "", source: str = "") -> dict:
    """喂数据入口：把杂乱文本自动「识别 + 整理 + 归纳」成结构化笔记。

    返回 {title, summary, points, tags, llm_mode}。
    LLM 模式由大模型提炼标题/摘要/要点/标签；未配置 LLM 或调用失败时走规则兜底。
    """
    raw = (raw or "").strip()
    if settings.llm_enabled:
        try:
            data = await llm.chat_json(
                [
                    {
                        "role": "user",
                        "content": (
                            "你是一名知识库整理助手。请把用户喂入的求职相关资料"
                            "（公司介绍 / 岗位说明 / 面经 / 技术文档）自动识别、整理、归纳，"
                            "输出 JSON："
                            '{"title": "精炼标题(≤20字)", "summary": "1-2句摘要", '
                            '"points": ["要点1","要点2",...], "tags": "技术标签,逗号分隔"}\n\n'
                            "要求：\n"
                            "1. title 概括核心主题，不要照抄原标题\n"
                            "2. summary 说清这份资料「是什么、有什么用」\n"
                            "3. points 提炼 3-8 条最有价值的信息（求职者关心的：业务/技术栈/考点/门槛）\n"
                            "4. tags 只列出现的技术关键词（如 FastAPI、RAG、LangChain），无则留空\n"
                            "5. 忠于原文，不编造\n\n"
                            f"资料原文：\n{raw[:6000]}"
                        ),
                    }
                ],
                max_tokens=1200,
                temperature=0.2,
            )
            return {**_normalize_organize(data, raw, hint, source), "llm_mode": True}
        except llm.LLMError as e:
            logger.warning("知识库整理走 LLM 失败，回退规则: %s", e)
    return {**_rule_organize(raw, hint, source), "llm_mode": False}


def compose_kb_content(summary: str, points: list[str], raw: str) -> str:
    """把整理结果 + 原文组合成结构化 Markdown，用于入库（保留原文便于 RAG 溯源）。"""
    blocks: list[str] = []
    if summary:
        blocks.append(summary)
    if points:
        blocks.append("## 要点\n" + "\n".join(f"- {p}" for p in points))
    if raw:
        blocks.append("## 原文\n" + raw)
    return "\n\n".join(blocks)
