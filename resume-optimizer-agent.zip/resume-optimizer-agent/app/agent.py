"""简历优化 Agent：工具 + 编排循环。

设计（学习要点）：
1. Agent 持有 5 个工具：parse_jd / parse_resume / match_analysis / rewrite_section / assemble
2. 每个工具「LLM 优先、规则引擎兜底」——配了 API Key 走大模型，没配也能离线演示
3. 编排器按依赖关系规划步骤，逐步执行并记录 trace（思考-行动-结果），前端可视化
4. 全程遵守「真实原则」：不虚构经历与数据，只重构表达、对齐关键词、提示补量化
"""
from __future__ import annotations

import json
import logging
from typing import Callable

from app import llm
from app.config import settings
from app.schemas import (
    AgentStep,
    Change,
    GapItem,
    Greeting,
    GreetingResult,
    JDParsed,
    MatchAnalysis,
    OptimizeResult,
    OptimizedResume,
    Requirement,
    ResumeParsed,
    ResumeSection,
)
from app.tools import rule_engine as rule

logger = logging.getLogger("resume-agent.agent")


# ================================================================ 工具实现
# 每个工具：async def xxx(原始输入) -> (模型对象, 元信息: 是否 LLM)
# 调用方统一捕获 LLMError 后回退规则引擎。

async def tool_parse_jd(raw: str) -> tuple[JDParsed, bool]:
    if settings.llm_enabled:
        try:
            data = await llm.chat_json(
                [
                    {
                        "role": "user",
                        "content": (
                            "请解析以下招聘 JD，输出 JSON："
                            '{"role": "岗位名称", '
                            '"requirements": [{"keyword": "技能/能力关键词", "weight": "高|中|低", "matched": false, "found_in": "", "evidence": ""}]}'
                            "\n\nJD 文本：\n" + raw
                        ),
                    }
                ],
                max_tokens=3000,
            )
            reqs = [
                Requirement(keyword=r.get("keyword", ""), weight=r.get("weight", "中"))
                for r in data.get("requirements", [])
                if r.get("keyword")
            ]
            return JDParsed(role=data.get("role", ""), requirements=reqs, raw_text=raw), True
        except llm.LLMError as e:
            logger.warning("parse_jd 走 LLM 失败，回退规则引擎: %s", e)
    return rule.parse_jd_rule(raw), False


async def tool_parse_resume(raw: str) -> tuple[ResumeParsed, bool]:
    if settings.llm_enabled:
        try:
            data = await llm.chat_json(
                [
                    {
                        "role": "user",
                        "content": (
                            "请把以下简历文本解析为 JSON："
                            '{"name": "姓名", "sections": [{"title": "章节名", "lines": ["每行原文"]}]}'
                            "\n注意：不要改写内容，逐行保留原文。\n\n简历文本：\n" + raw
                        ),
                    }
                ],
                max_tokens=4000,
            )
            secs = [
                ResumeSection(title=s.get("title", "未命名"), lines=[str(l) for l in s.get("lines", [])])
                for s in data.get("sections", [])
            ]
            return ResumeParsed(name=data.get("name", ""), sections=secs, raw_text=raw), True
        except llm.LLMError as e:
            logger.warning("parse_resume 走 LLM 失败，回退规则引擎: %s", e)
    return rule.parse_resume_rule(raw), False


async def tool_match_analysis(jd: JDParsed, resume: ResumeParsed) -> tuple[MatchAnalysis, bool]:
    if settings.llm_enabled:
        try:
            jd_summary = "\n".join(f"- {r.keyword}({r.weight})" for r in jd.requirements)
            resume_text = resume.all_text
            data = await llm.chat_json(
                [
                    {
                        "role": "user",
                        "content": (
                            "你是简历匹配分析专家。根据 JD 要求与简历内容，输出 JSON：\n"
                            '{"overall_score": 0-100整数, '
                            '"matched": [{"keyword": "...", "weight": "...", "found_in": "命中章节", "evidence": "原文片段"}], '
                            '"missing": [{"keyword": "...", "weight": "..."}], '
                            '"suggestions": [{"level": "高|中|低", "section": "简历章节", "message": "建议"}]}\n'
                            f"\nJD 要求：\n{jd_summary}\n\n简历全文：\n{resume_text}"
                        ),
                    }
                ],
                max_tokens=3000,
            )
            matched = [Requirement(keyword=r.get("keyword", ""), weight=r.get("weight", "中"),
                                   matched=True, found_in=r.get("found_in", ""), evidence=r.get("evidence", ""))
                       for r in data.get("matched", []) if r.get("keyword")]
            missing = [Requirement(keyword=r.get("keyword", ""), weight=r.get("weight", "中"))
                       for r in data.get("missing", []) if r.get("keyword")]
            suggestions = [GapItem(level=s.get("level", "中"), section=s.get("section", ""), message=s.get("message", ""))
                           for s in data.get("suggestions", []) if s.get("message")]
            coverage: dict[str, list[str]] = {}
            for r in matched:
                if r.found_in:
                    coverage.setdefault(r.found_in, []).append(r.keyword)
            return MatchAnalysis(
                overall_score=int(data.get("overall_score", 0)),
                matched=matched, missing=missing,
                section_coverage=coverage, suggestions=suggestions,
            ), True
        except llm.LLMError as e:
            logger.warning("match_analysis 走 LLM 失败，回退规则引擎: %s", e)
    return rule.analyze_match_rule(jd, resume), False


async def tool_rewrite_and_assemble(
    resume: ResumeParsed, jd: JDParsed, analysis: MatchAnalysis
) -> tuple[OptimizedResume, bool]:
    if settings.llm_enabled:
        try:
            jd_summary = "\n".join(f"- {r.keyword}({r.weight})" for r in jd.requirements)
            resume_text = resume.all_text
            missing_summary = ", ".join(r.keyword for r in analysis.missing) or "无"
            data = await llm.chat_json(
                [
                    {
                        "role": "user",
                        "content": (
                            "你是资深简历改写专家。请把简历针对目标 JD 改写优化，输出 JSON：\n"
                            '{"content": "优化后的完整简历（Markdown 格式，## 分章节）", '
                            '"changes": [{"section": "章节", "original": "原文要点", "optimized": "改写后要点", "reason": "改写理由"}]}\n\n'
                            "改写守则：\n"
                            "1. 不虚构经历、不编造数据；原简历没有的内容不添加\n"
                            "2. 对项目/实习要点：动词开头、技术点前置、与 JD 关键词对齐；缺数字的用『（补充：真实量化结果）』占位提示\n"
                            "3. 技能栏按 JD 命中度排序置顶\n"
                            "4. 章节顺序：基本信息→项目经历→实习经历→技能→教育经历→自我评价\n"
                            "5. 保持简洁，一页纸可容纳\n\n"
                            f"目标 JD 要求：\n{jd_summary}\n\n"
                            f"简历现状（JD 中缺失的关键词：{missing_summary}）：\n{resume_text}"
                        ),
                    }
                ],
                max_tokens=6000,
            )
            content = data.get("content", "")
            changes = [
                Change(section=c.get("section", ""), original=c.get("original", ""),
                       optimized=c.get("optimized", ""), reason=c.get("reason", ""))
                for c in data.get("changes", []) if c.get("optimized")
            ]
            if content.strip():
                return OptimizedResume(content=content, changes=changes), True
            logger.warning("LLM 未返回有效简历内容，回退规则引擎")
        except llm.LLMError as e:
            logger.warning("rewrite 走 LLM 失败，回退规则引擎: %s", e)
    return rule.assemble_rule(resume, jd, analysis), False


# ================================================================ 编排器
async def run_optimizer(jd_raw: str, resume_raw: str) -> OptimizeResult:
    """Agent 主流程：规划 → 逐步执行 → 记录 trace → 汇总结果。"""
    trace: list[AgentStep] = []
    used_llm = False

    async def step(n: int, tool: str, thought: str, action: str, coro: Callable) -> object:
        nonlocal used_llm
        trace.append(AgentStep(step=n, tool=tool, thought=thought, action=action, result="执行中…"))
        result = await coro()
        # 元信息里标记是否 LLM 完成
        meta_used_llm = False
        if isinstance(result, tuple):
            result, meta_used_llm = result
        used_llm = used_llm or meta_used_llm
        trace[-1].result = _summarize(result)
        return result

    # 1. 解析 JD
    jd = await step(
        1, "parse_jd",
        "先读取 JD，识别岗位名称与硬性技术要求，为后续匹配做准备。",
        "调用 parse_jd(raw_jd)",
        lambda: tool_parse_jd(jd_raw),
    )

    # 2. 解析简历
    resume = await step(
        2, "parse_resume",
        "把简历切分为结构化章节（基本信息/技能/项目/实习/教育…），保留原文。",
        "调用 parse_resume(raw_resume)",
        lambda: tool_parse_resume(resume_raw),
    )

    # 3. 匹配分析
    analysis = await step(
        3, "match_analysis",
        f"岗位「{jd.role}」共识别 {len(jd.requirements)} 项要求，逐项与简历比对，计算匹配分并找差距。",
        "调用 match_analysis(jd, resume)",
        lambda: tool_match_analysis(jd, resume),
    )

    # 4. 改写 + 组装
    optimized = await step(
        4, "rewrite + assemble",
        f"当前匹配分 {analysis.overall_score}/100，缺失 {len(analysis.missing)} 项。"
        "按 JD 相关度重排章节，对项目/实习要点做动词锚定与关键词对齐，技能置顶。",
        "调用 rewrite_section → assemble",
        lambda: tool_rewrite_and_assemble(resume, jd, analysis),
    )

    # 5. 质检（轻量自检）
    quality_issues: list[str] = []
    if "（补充：真实量化结果）" in optimized.content or "（建议补充真实量化结果" in optimized.content:
        quality_issues.append("存在多处量化占位符，需补充真实数据")
    if not analysis.matched:
        quality_issues.append("JD 关键词零命中，建议先补强技能栈")
    trace.append(AgentStep(
        step=5, tool="self_check",
        thought="输出前自检：内容是否虚构、占位符是否残留、匹配是否为空。",
        action="调用 self_check(optimized, analysis)",
        result="发现 " + ("；".join(quality_issues) if quality_issues else "无问题：未虚构内容，输出合规。"),
    ))

    return OptimizeResult(
        llm_mode=used_llm,
        jd=jd,
        resume=resume,
        analysis=analysis,
        optimized=optimized,
        trace=trace,
        meta={"llm_configured": settings.llm_enabled},
    )


def _summarize(obj: object) -> str:
    """把工具结果压缩成一行摘要，写入 trace。"""
    if isinstance(obj, JDParsed):
        reqs = ", ".join(r.keyword for r in obj.requirements[:12])
        return f"岗位={obj.role or '未识别'}，识别要求 {len(obj.requirements)} 项：{reqs}"
    if isinstance(obj, ResumeParsed):
        secs = ", ".join(s.title for s in obj.sections)
        return f"切分章节 {len(obj.sections)} 个：{secs}"
    if isinstance(obj, MatchAnalysis):
        return f"匹配分 {obj.overall_score}/100，命中 {len(obj.matched)} 项，缺失 {len(obj.missing)} 项"
    if isinstance(obj, OptimizedResume):
        return f"生成简历 {len(obj.content)} 字符，改写动作 {len(obj.changes)} 处"
    if isinstance(obj, (list, dict)):
        return json.dumps(obj, ensure_ascii=False)[:200]
    return str(obj)[:200]


# ================================================================ 打招呼语
async def tool_generate_greeting(
    jd: JDParsed, resume: ResumeParsed, analysis: MatchAnalysis
) -> tuple[list[Greeting], bool]:
    """生成 3 种风格的 HR 打招呼语：LLM 优先，规则模板兜底。"""
    if settings.llm_enabled:
        try:
            matched_summary = "、".join(r.keyword for r in analysis.matched[:6]) or "无"
            hl = rule._best_highlight(resume, [r.keyword for r in analysis.matched])
            data = await llm.chat_json(
                [
                    {
                        "role": "user",
                        "content": (
                            "你是求职沟通专家。根据目标 JD 与候选人简历，生成 3 条发给 HR 的打招呼语，输出 JSON：\n"
                            '{"greetings": [{"style": "简洁版", "content": "..."}, {"style": "亮点版", "content": "..."}, {"style": "诚恳版", "content": "..."}]}\n\n'
                            "要求：\n"
                            "1. 每条 60-160 字，适合 Boss 直聘首条消息，口语自然、礼貌不卑微\n"
                            "2. 必须基于简历真实内容，不得虚构经历与数据\n"
                            "3. 突出与 JD 匹配的技术关键词（见下），并自然融入一条真实亮点\n"
                            "4. 结尾留一个轻量 CTA（如：期待与您进一步沟通）\n"
                            "5. 三种风格差异化：简洁版直接利落；亮点版以最强实践开场；诚恳版强调匹配度与学习力\n\n"
                            f"目标岗位：{jd.role}\n"
                            f"JD 中简历已命中的关键词：{matched_summary}\n"
                            f"简历最强亮点句：{hl}\n"
                            f"候选人姓名：{resume.name}"
                        ),
                    }
                ],
                max_tokens=1500,
                temperature=0.7,
            )
            greetings = [
                Greeting(style=g.get("style", "未命名"), content=g.get("content", ""))
                for g in data.get("greetings", [])
                if g.get("content", "").strip()
            ]
            if greetings:
                return greetings, True
            logger.warning("LLM 未返回有效打招呼语，回退规则模板")
        except llm.LLMError as e:
            logger.warning("generate_greeting 走 LLM 失败，回退规则模板: %s", e)
    return rule.generate_greetings_rule(jd, resume, analysis), False


async def run_greeting(jd_raw: str, resume_raw: str) -> GreetingResult:
    """打招呼语主流程：复用 解析JD → 解析简历 → 匹配分析 → 生成打招呼语。"""
    jd, _ = await tool_parse_jd(jd_raw)
    resume, _ = await tool_parse_resume(resume_raw)
    analysis, _ = await tool_match_analysis(jd, resume)
    greetings, used_llm = await tool_generate_greeting(jd, resume, analysis)
    hl = rule._best_highlight(resume, [r.keyword for r in analysis.matched])

    return GreetingResult(
        llm_mode=used_llm,
        role=jd.role,
        matched_keywords=[r.keyword for r in analysis.matched],
        highlight=hl,
        greetings=greetings,
    )
