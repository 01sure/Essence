"""记录中心归纳引擎：把用户随手记的求职 / 面试文字（图片 OCR / 文件 / 粘贴）自动提取归纳。

业务场景：
- 用户上传截图 / 图片 / 文字 / 文档 → 提取有效文字 → 自动识别「公司 / 岗位 / 类型 / 进度」
  → 提炼摘要 + 要点 + 标签 → 形成一条结构化记录，卡片墙展示，方便回顾。

两条模式：
- LLM 模式（配置了 LLM）：由大模型从杂乱文本中结构化抽取字段
- 规则模式（未配置 LLM）：确定性启发式兜底，保证离线也能用

输入是「已经提取好的纯文本」（文件/图片识别在上层 /api/record/add 完成，复用 doc_parse.extract_file），
本模块只负责把文本归纳成结构化记录。
"""
from __future__ import annotations

import logging
import re
from typing import Any

from app import llm
from app.config import settings
from app.tools import rule_engine as rule

logger = logging.getLogger("resume-agent.record")

RECORD_KINDS = ["求职记录", "面试记录"]
# 进度识别关键词（按优先级，命中即定）
_STATUS_KEYWORDS = [
    ("offer", ["offer", "录用", "拿到offer", "已录用", "入职通知", "发offer", "oc"]),
    ("已投递", ["已投递", "已投", "投递了", "投了", "提交简历", "已申请", "申请了"]),
    ("面试中", ["面试", "二面", "三面", "一面", "终面", "约面", "技术面", "hr面"]),
    ("拒信", ["拒", "未通过", "淘汰", "凉了", "没过", "不合适", "祝您", "感谢您应聘"]),
    ("已复盘", ["复盘", "面经", "总结一下", "回顾"]),
]


def _first_title(text: str, max_len: int = 24) -> str:
    """从文本里取一个自然的分句做标题（优先句号/逗号断句，避免硬截断）。"""
    seg = re.split(r"[。；;！？!?，,]", text.strip())[0].strip()
    if len(seg) >= 4:
        return seg[:max_len]
    return text.strip()[:max_len]


def _detect_kind(text: str, hint: str = "") -> str:
    """判断这是求职记录还是面试记录。"""
    if hint in RECORD_KINDS:
        return hint
    t = text.lower()
    # 只有明确的面试/复盘信号才判为面试记录；「笔试/测评」属于投递后流程，仍算求职记录
    if any(k in t for k in ["面试", "面经", "复盘", "技术面", "hr面", "终面", "二面", "一面", "约面"]):
        return "面试记录"
    return "求职记录"


def _detect_status(text: str, kind: str) -> str:
    """从文本识别当前进度。"""
    low = text.lower()
    for status, kws in _STATUS_KEYWORDS:
        if any(k in low for k in kws):
            return status
    return "面试中" if kind == "面试记录" else "待投递"


def _detect_company(text: str) -> str:
    """启发式抽取公司名。"""
    # 1) 显式「公司：XXX」
    m = re.search(r"公司[名称]?[：:]\s*([^，,。；;：:\n\s]{1,20})", text)
    if m:
        return m.group(1).strip()
    m = re.search(r"(?:应聘单位|面试单位|雇主|企业)[：:]\s*([^，,。；;：:\n\s]{1,20})", text)
    if m:
        return m.group(1).strip()
    # 2) 「XX公司 / XX科技 / XX网络 / XX集团」——前缀排除「的/了/去/到」等填充词，避免连句
    m = re.search(
        r"([^\s，,。；;：:、的了去到在前刚]{1,16}?(?:公司|科技|网络|集团|股份|实验室|研究院|有限))",
        text,
    )
    if m:
        name = m.group(1).strip()
        # 去掉尾随的「有限公司 / 股份」等过长后缀，保留主体
        name = re.sub(r"(股份有限公司|有限公司|有限责任公司|有限合伙)$", "", name)
        return name
    return ""


def _detect_position(text: str) -> str:
    """启发式抽取岗位名。"""
    # 1) 显式「岗位：XXX」
    m = re.search(r"(?:岗位|职位|应聘|招聘|方向|投递)[名称]?[：:]\s*([^，,。；;：:\n\s]{1,20})", text)
    if m:
        return m.group(1).strip()
    # 2) 「XX工程师 / XX开发 …」——前缀排除「的/了/了」等填充词，只取贴近岗位词的真实名称
    m = re.search(
        r"([^\s，,。；;：:、的了我你他她它们这那此该当把被将请]{1,12}?"
        r"(?:工程师|开发|架构师|架构|专家|实习生?|经理|专员|主管|负责人|测评|分析师|设计师|管培生|技术))",
        text,
    )
    if m:
        return m.group(1).strip()
    return ""


def _rule_summarize(raw: str, hint: str = "", source: str = "") -> dict[str, Any]:
    """规则模式兜底：确定性地从杂乱文本提炼结构化记录。"""
    kind = _detect_kind(raw, hint)
    status = _detect_status(raw, kind)
    company = _detect_company(raw)
    position = _detect_position(raw)

    lines = [ln.strip().lstrip("-*•·#").strip() for ln in raw.splitlines() if ln.strip()]
    title = _first_title(lines[0] if lines else (source or (company + ((" · " + position) if position else "")) or "未命名记录"))

    flat = re.sub(r"\s+", " ", raw).strip()
    summary = flat[:120] + ("…" if len(flat) > 120 else "")

    candidates = lines[1:] if lines else []
    if not candidates:
        candidates = [s.strip() for s in re.split(r"[。；;！？!?]", flat) if len(s.strip()) >= 4]
    points: list[str] = []
    for c in candidates:
        c = c.strip()
        if len(c) < 4:
            continue
        points.append(c[:48] + ("…" if len(c) > 48 else ""))
        if len(points) >= 6:
            break

    tags = ",".join(list(rule.extract_keywords(raw).keys())[:6])

    return {
        "kind": kind,
        "status": status,
        "company": company,
        "position": position,
        "title": title,
        "summary": summary,
        "points": points,
        "tags": tags,
    }


def _normalize_record(data: dict, raw: str, hint: str, source: str) -> dict:
    """把 LLM 返回的 JSON 规整成统一结构，缺字段时用规则结果兜底。"""
    fb = _rule_summarize(raw, hint, source)
    kind = data.get("kind") if data.get("kind") in RECORD_KINDS else fb["kind"]
    status = str(data.get("status", "")).strip() or fb["status"]
    company = str(data.get("company", "")).strip() or fb["company"]
    position = str(data.get("position", "")).strip() or fb["position"]
    title = str(data.get("title", "")).strip() or fb["title"]
    summary = str(data.get("summary", "")).strip() or fb["summary"]
    points = data.get("points") or []
    if isinstance(points, str):
        points = [p.strip() for p in re.split(r"[;\n]", points) if p.strip()]
    points = [str(p).strip() for p in points if str(p).strip()][:10] or fb["points"]
    tags = data.get("tags") or ""
    if isinstance(tags, list):
        tags = ",".join(str(t) for t in tags)
    tags = str(tags).strip() or fb["tags"]
    return {
        "kind": kind, "status": status, "company": company, "position": position,
        "title": title, "summary": summary, "points": points, "tags": tags,
    }


async def summarize_record(raw: str, hint: str = "", source: str = "") -> dict[str, Any]:
    """把杂乱文本归纳成结构化求职/面试记录。

    返回 {kind, status, company, position, title, summary, points, tags, llm_mode}。
    LLM 优先，未配置 LLM 或调用失败时走规则兜底。
    """
    raw = (raw or "").strip()
    if settings.llm_enabled:
        try:
            data = await llm.chat_json(
                [
                    {
                        "role": "user",
                        "content": (
                            "你是一名求职记录整理助手。用户会随手记下一条求职或面试相关的文字"
                            "（可能来自截图、聊天记录、邮件或口头记录，内容杂乱）。请从中自动提取并归纳，"
                            "输出 JSON：\n"
                            '{"kind": "求职记录 或 面试记录", "status": "进度(待投递/已投递/面试中/offer/拒信/已复盘 之一)", '
                            '"company": "公司名(无则留空)", "position": "岗位名(无则留空)", '
                            '"title": "精炼标题(≤20字)", "summary": "1-2句摘要", '
                            '"points": ["要点1","要点2",...], "tags": "标签,逗号分隔"}\n\n'
                            "要求：\n"
                            "1. kind：涉及面试/笔试/复盘/面经判为「面试记录」，其余判为「求职记录」\n"
                            "2. status：根据文本里的信号判断（已投递/约面/拿到offer/被拒/已复盘），判断不出用「待投递」\n"
                            "3. company/position：尽量从文本抓取真实名称；抓不到就留空，不要编造\n"
                            "4. title：概括这次记录的核心（如「投递腾讯·AI应用工程师」「字节一面复盘」）\n"
                            "5. summary：说清「做了什么、结果/下一步是什么」\n"
                            "6. points：3-6 条最有价值的信息（岗位要求/面试考点/对方反馈/待办）\n"
                            "7. tags：只列技术或业务关键词，无则留空\n"
                            "8. 忠于原文，绝不编造公司、岗位或结果\n\n"
                            f"记录原文：\n{raw[:6000]}"
                        ),
                    }
                ],
                max_tokens=1200,
                temperature=0.2,
            )
            return {**_normalize_record(data, raw, hint, source), "llm_mode": True}
        except llm.LLMError as e:
            logger.warning("记录归纳走 LLM 失败，回退规则: %s", e)
    return {**_rule_summarize(raw, hint, source), "llm_mode": False}
