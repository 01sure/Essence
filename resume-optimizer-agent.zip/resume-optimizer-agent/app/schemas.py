"""Agent 各工具输入/输出的数据模型（Pydantic）。"""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class Requirement(BaseModel):
    """JD 中的一条硬性要求 / 关键词。"""

    keyword: str = Field(description="技能或能力关键词")
    weight: str = Field(default="中", description="高/中/低")
    matched: bool = False
    found_in: str = Field(default="", description="在简历中的命中位置（章节名）")
    evidence: str = Field(default="", description="命中的原文片段")


class JDParsed(BaseModel):
    """JD 解析结果。"""

    role: str = Field(default="", description="目标岗位名称")
    company_hint: str = Field(default="")
    requirements: list[Requirement] = Field(default_factory=list)
    raw_text: str = ""


class ResumeSection(BaseModel):
    title: str
    lines: list[str] = Field(default_factory=list)

    @property
    def text(self) -> str:
        return "\n".join(self.lines)


class ResumeParsed(BaseModel):
    """简历解析结果。"""

    name: str = Field(default="", description="候选人姓名（若可识别）")
    sections: list[ResumeSection] = Field(default_factory=list)
    raw_text: str = ""

    @property
    def all_text(self) -> str:
        return "\n".join(s.text for s in self.sections)


class GapItem(BaseModel):
    """一条差距/优化建议。"""

    level: str = Field(description="高/中/低")
    section: str = Field(description="建议作用到的简历章节")
    message: str = Field(description="具体建议")


class MatchAnalysis(BaseModel):
    overall_score: int = Field(description="0-100 综合匹配分")
    matched: list[Requirement] = Field(default_factory=list)
    missing: list[Requirement] = Field(default_factory=list)
    section_coverage: dict[str, list[str]] = Field(default_factory=dict)
    suggestions: list[GapItem] = Field(default_factory=list)


class Change(BaseModel):
    """一次具体的改写动作（用于对比视图）。"""

    section: str
    original: str = ""
    optimized: str = ""
    reason: str = ""


class OptimizedResume(BaseModel):
    content: str = Field(description="优化后的简历 Markdown 全文")
    changes: list[Change] = Field(default_factory=list)


class AgentStep(BaseModel):
    """Agent 执行轨迹中的一步。"""

    step: int
    tool: str
    thought: str = ""
    action: str = ""
    result: str = ""


class OptimizeResult(BaseModel):
    llm_mode: bool
    jd: JDParsed
    resume: ResumeParsed
    analysis: MatchAnalysis
    optimized: OptimizedResume
    trace: list[AgentStep] = Field(default_factory=list)
    meta: dict[str, Any] = Field(default_factory=dict)


class Greeting(BaseModel):
    """一条打招呼语变体。"""

    style: str = Field(description="风格：简洁版/亮点版/诚恳版等")
    content: str = Field(description="打招呼语正文（适合 Boss 直聘等平台首条消息）")


class GreetingResult(BaseModel):
    """打招呼语生成结果。"""

    llm_mode: bool
    role: str
    matched_keywords: list[str] = Field(default_factory=list)
    highlight: str = Field(default="", description="从简历中挑出的最强亮点句")
    greetings: list[Greeting] = Field(default_factory=list)


class ExtractResult(BaseModel):
    """文件上传识别结果。"""

    filename: str = Field(description="原始文件名")
    method: str = Field(description="识别方式：ocr / pdf_text / docx_text / plain_text")
    text: str = Field(description="识别出的完整文本")
    chars: int = Field(description="识别出的字符数")
    warn: str = Field(default="", description="提示信息（如扫描版 PDF 无文本层）")


class InterviewQuestion(BaseModel):
    """一道面试题。"""

    category: str = Field(description="技术基础 / 项目深挖 / 开放问题")
    question: str
    keywords: list[str] = Field(default_factory=list)
    difficulty: str = Field(default="中", description="易/中/难")
    answer_points: list[str] = Field(default_factory=list, description="参考回答要点")
    related_resume: str = Field(default="", description="若是项目深挖题，对应的简历原文素材")


class InterviewPlan(BaseModel):
    """面试准备计划。"""

    llm_mode: bool
    role: str = Field(default="", description="目标岗位")
    total: int = 0
    stats: dict[str, int] = Field(default_factory=dict, description="各分类题量统计")
    questions: list[InterviewQuestion] = Field(default_factory=list)


class KBChunk(BaseModel):
    """知识库中的一个检索块。"""

    doc_id: int
    title: str
    content: str
    score: float = 0.0


class KBAskResult(BaseModel):
    """知识库问答结果。"""

    llm_mode: bool
    question: str
    answer: str
    chunks: list[KBChunk] = Field(default_factory=list, description="命中的检索片段（可溯源）")
    fallback: bool = Field(default=False, description="是否无命中走兜底话术")


class KBIngestResult(BaseModel):
    """知识库「喂数据」智能整理结果：自动识别 + 归纳（标题/摘要/要点/标签）预览。"""

    llm_mode: bool
    title: str = Field(default="", description="AI 生成的标题")
    summary: str = Field(default="", description="自动提炼的摘要")
    points: list[str] = Field(default_factory=list, description="归纳出的要点")
    tags: str = Field(default="", description="自动识别的技术标签（逗号分隔）")
    content: str = Field(default="", description="已组合好的结构化 Markdown（可直接入库）")
    raw_text: str = Field(default="", description="识别出的原文")
    chars: int = Field(default=0, description="原文字符数")
    method: str = Field(default="paste", description="来源方式：paste/ocr/pdf_text/docx_text/plain_text")
    source: str = Field(default="", description="来源说明（文件名或 paste）")


# ================================================================ 沟通策略
class ChatScript(BaseModel):
    """一条沟通话术。"""

    style: str = Field(description="风格：简洁专业 / 亮点冲击 / 诚恳真诚 / 热情示好 / 提问互动")
    tone: str = Field(default="", description="语气标签：专业 / 诚恳 / 热情")
    content: str = Field(description="话术正文（可直接复制发送）")
    tip: str = Field(default="", description="使用提示：为什么这样写、注意什么")
    chars: int = Field(default=0, description="字数")


class ChatHelloResult(BaseModel):
    """打招呼语生成结果（HR 换位思考版）。"""

    llm_mode: bool
    role: str = ""
    company: str = ""
    matched_keywords: list[str] = Field(default_factory=list)
    highlight: str = ""
    scripts: list[ChatScript] = Field(default_factory=list)
    hr_insight: str = Field(default="", description="HR 视角洞察：这条消息为什么会被点开")
    avoid: list[str] = Field(default_factory=list, description="HR 最反感的写法，务必避开")


class ChatReplyResult(BaseModel):
    """HR 回复后的应答话术。"""

    llm_mode: bool
    scenario: str = Field(default="", description="场景 key")
    scenario_label: str = Field(default="", description="场景名称")
    hr_intent: str = Field(default="", description="HR 这句话背后的真实意图")
    scripts: list[ChatScript] = Field(default_factory=list)


class FollowupResult(BaseModel):
    """已读不回时的追问话术。"""

    llm_mode: bool
    round_no: int = Field(default=1, description="第几轮追问")
    timing: str = Field(default="", description="建议发送时机")
    scripts: list[ChatScript] = Field(default_factory=list)
    closing_note: str = Field(default="", description="本轮策略说明/心态建议")


class GapAdvice(BaseModel):
    """一条差距与提升建议。"""

    keyword: str = ""
    weight: str = Field(default="中", description="高/中/低")
    kind: str = Field(default="能力补强", description="简历包装 / 能力补强 / 表达优化")
    advice: str = ""
    action: str = Field(default="", description="可执行的 30 天行动")


class DiagnoseResult(BaseModel):
    """不匹配诊断与提升建议。"""

    llm_mode: bool
    role: str = ""
    score: int = 0
    hard_gaps: list[GapAdvice] = Field(default_factory=list, description="硬伤：JD 高优先但简历没有")
    soft_gaps: list[GapAdvice] = Field(default_factory=list, description="软差距：可包装或短期补齐")
    plan_30d: list[str] = Field(default_factory=list, description="30 天提升计划")
    summary: str = ""
    hr_verdict: str = Field(default="", description="HR 视角：这份简历会被怎么处理")


# ================================================================ 数据洞察
class DefectItem(BaseModel):
    """一条从历史解析中沉淀出来的简历缺陷。"""

    keyword: str
    weight: str = Field(default="中", description="高/中/低")
    count: int = Field(default=1, description="在历史解析中缺失的次数")
    streak: int = Field(default=0, description="连续缺失次数（判断是否为长期短板）")
    improved: bool = Field(default=False, description="最近一次是否已补上")
    priority: float = Field(default=0.0, description="优先级 = 权重×频次")
    advice: str = ""


class DefectReport(BaseModel):
    """简历缺陷追踪报告。"""

    llm_mode: bool
    total_runs: int = 0
    defects: list[DefectItem] = Field(default_factory=list)
    improved: list[str] = Field(default_factory=list, description="已改善的关键词")
    summary: str = ""
    top_action: str = Field(default="", description="最该做的一件事")


class ProjectRecommendation(BaseModel):
    """一个项目推荐。"""

    project_id: int = 0
    name: str = ""
    match_score: int = 0
    hit_tags: list[str] = Field(default_factory=list)
    reason: str = ""
    rewrite_tip: str = Field(default="", description="这个项目描述该怎么改才更贴 JD")


class ProjectAdvice(BaseModel):
    """按 JD 推荐更适合的项目。"""

    llm_mode: bool
    role: str = ""
    jd_keywords: list[str] = Field(default_factory=list)
    recommendations: list[ProjectRecommendation] = Field(default_factory=list)
    new_project_ideas: list[str] = Field(default_factory=list, description="项目库里没有、建议补做的项目")
    summary: str = ""


class Competitiveness(BaseModel):
    """竞争力评估（基于历史解析数据的趋势）。"""

    llm_mode: bool
    score: int = 0
    level: str = ""
    trend: str = Field(default="", description="上升/持平/下降")
    history: list[dict] = Field(default_factory=list, description="历史分数 [{label, score, created_at}]")
    strengths: list[str] = Field(default_factory=list)
    weaknesses: list[str] = Field(default_factory=list)
    actions: list[str] = Field(default_factory=list)
    summary: str = ""


# ================================================================ 面试复盘
class ReviewResult(BaseModel):
    """面试复盘分析结果。"""

    llm_mode: bool
    company: str = ""
    position: str = ""
    score: int = Field(default=0, description="本次面试表现评分 0-100")
    summary: str = ""
    questions: list[str] = Field(default_factory=list, description="被问到的问题")
    answered_well: list[str] = Field(default_factory=list, description="答得不错的部分")
    weaknesses: list[str] = Field(default_factory=list, description="暴露的知识盲点")
    actions: list[str] = Field(default_factory=list, description="下次面试前的改进项")
    resume_feedback: list[str] = Field(default_factory=list, description="反哺简历的调整建议")


# ================================================================ 记录中心
class RecordResult(BaseModel):
    """记录中心：随手记一条求职/面试 → 自动提取归纳后的结构化结果。"""

    llm_mode: bool
    id: int = Field(default=0, description="落库后的记录 id（仅 /api/record/add 返回时填充）")
    kind: str = Field(default="求职记录", description="求职记录 / 面试记录")
    status: str = Field(default="", description="进度：待投递/已投递/面试中/offer/拒信/已复盘")
    company: str = Field(default="", description="自动识别的公司名")
    position: str = Field(default="", description="自动识别的岗位名")
    title: str = Field(default="", description="自动生成的标题")
    summary: str = Field(default="", description="自动归纳摘要")
    points: list[str] = Field(default_factory=list, description="归纳要点")
    tags: str = Field(default="", description="标签，逗号分隔")
    raw_text: str = Field(default="", description="识别出的原文")
    chars: int = Field(default=0, description="原文字符数")
    method: str = Field(default="paste", description="来源方式：paste/ocr/pdf_text/docx_text/plain_text")
    source: str = Field(default="", description="来源说明（文件名或 paste）")


# ================================================================ 智能投递
class DeliveryJob(BaseModel):
    """一条检索到的岗位 + 匹配结果 + 审批/投递状态。"""
    id: int = Field(default=0, description="落库 id（仅列表返回时填充）")
    platform: str = Field(default="")
    job_key: str = Field(default="")
    title: str = Field(default="")
    company: str = Field(default="")
    city: str = Field(default="")
    salary: str = Field(default="")
    url: str = Field(default="")
    jd_text: str = Field(default="")
    match_score: int = Field(default=0, description="匹配度 0-100")
    reasons: list[str] = Field(default_factory=list, description="匹配理由")
    tags: str = Field(default="", description="命中标签，逗号分隔")
    status: str = Field(default="pending", description="pending/approved/skipped/applied/failed")
    note: str = Field(default="", description="针对性投递备注（打招呼语/简历亮点）")
    applied_at: str = Field(default="")
    created_at: str = Field(default="")


class DeliverySession(BaseModel):
    """平台登录会话状态。"""
    platform: str
    status: str = Field(default="disconnected", description="disconnected/connecting/qr_ready/ready/expired/error")
    last_login: str = Field(default="")
    expires_at: str = Field(default="")
    message: str = Field(default="")


class DeliveryStrategy(BaseModel):
    """基于简历画像 + 知识库/系统上下文的定向投递策略。"""
    llm_mode: bool
    platforms: list[str] = Field(default_factory=list)
    keywords: list[str] = Field(default_factory=list)
    salary_expectation: str = Field(default="")
    blacklist: list[str] = Field(default_factory=list)
    summary: str = Field(default="")
