# 一站式求职 Agent 系统（Resume Optimizer Agent）

> 面向 **AI 应用 / AI Agent 开发**岗位求职的一站式系统，覆盖求职全链路：
> **智能投递 → 记录中心 → 简历优化 → 沟通中心 → 面试准备 → 面试复盘 → 数据洞察 → 知识库问答 → 后台管理**。
>
> v2.5.0 核心：**智能投递**——连接 Boss直聘/猎聘（手动扫码登录后系统全权接手），按简历画像自动匹配岗位、结合知识库生成定向策略、拟人化防拦截自动投递（日上限/匹配阈值/随机延时/渐入/间歇休息/单会话串行）。同页内置风险告知，真实自动投递由本人承担风控风险。
> v2.4.0 核心：**记录中心（默认主页）**——随手记一条求职/面试（粘贴文字 / Ctrl+V 粘贴截图 / 上传图片·PDF·Word·Excel·PPT），自动识别（OCR/解析）后由 AI 归纳出 **公司·岗位·类型·进度·摘要·要点·标签**，一键落库；时间线卡片墙按日期分组、支持类型筛选与原文展开，右下角常驻「＋记一笔」浮层全站随手记。
> v2.3.0 核心：**知识库「喂数据」智能整理**——粘贴文字 / Ctrl+V 粘贴图片 / 上传文字·图片·文档，自动识别（OCR/解析）后
> AI 归纳出标题·摘要·要点·标签，确认即入库，知识库从此不再是一堆原始文本。
> 承接 v2.2.0 的**数据反哺闭环**（解析快照 → 缺陷追踪/项目推荐/竞争力评估），以及 v2.1.0 的
> **沟通中心**（顶尖 HR 换位思考：打招呼/回复/追问/差距诊断，含「热情示好（舔狗式）」风格）。
>
> 双模式运行：配了 OpenAI 兼容 LLM（DeepSeek/Qwen/GLM…）走大模型，没配也能用内置规则引擎离线跑通全流程。
> 支持**上传识别**：JD/简历/面试记录截图、PDF、Word、Excel、PPT、txt 直接上传，本地离线识别后自动填入；输入框支持 **Ctrl+V 粘贴图片**。
> 界面为**侧边主导航栏 + 顶部辅助导航栏**布局，**记录中心为默认主页**；JD/简历共享输入区仅在「简历优化 / 沟通中心 / 面试准备」展示，其余页面隐藏以减少干扰。

## 功能总览

- 📌 **记录中心（v2.4.0，默认主页）**：随手记一条求职/面试——粘贴文字 / Ctrl+V 粘贴截图 / 上传图片·PDF·Word·Excel·PPT，**自动识别（OCR/解析）后由 AI 归纳出公司·岗位·类型·进度·摘要·要点·标签**，一键落库；时间线卡片墙按日期分组展示，支持「求职记录 / 面试记录」类型筛选与原文展开；右下角常驻「＋记一笔」浮层，全站任意页面都能随手记。未配 LLM 时用规则引擎兜底（自动判断类型/进度、提取公司岗位、技术词做标签）
- 🚀 **智能投递（v2.5.0 新增板块）**：求职投递的「自动驾驶」闭环——① 填写**简历画像**（匹配基准）② **连接平台**（Boss直聘/猎聘，live 模式弹窗手动扫码、mock 模式直接就绪）③ **搜索+智能匹配**（按简历×知识库对岗位打分 0-100，LLM 优先+规则兜底）④ **审批岗位**（勾选/按阈值批量批准进入投递队列）⑤ **启动投递**（拟人化防拦截：日上限·匹配阈值·随机延时·渐入·间歇休息·单会话串行；实时日志透明可追溯）。内置**定向策略**：基于简历画像+知识库/系统上下文给出建议平台·检索关键词·薪资预期·黑名单。⚠️ 真实自动投递需本人扫码登录并承担平台风控风险，模块仅做「降低被拦截概率」护栏，不保证不被拦截。

```
┌──────────────────────────────────────────────────────────────────────┐
│                      一站式求职 Agent 系统 v2.5.0                       │
│           侧边主导航 + 顶部辅助栏 · 全模块共享同一份 JD / 简历            │
├───────────────┬───────────────┬───────────────┬──────────────────────┤
│   ① 简历优化    │   ② 沟通中心    │   ③ 面试准备    │      ④ 知识库问答      │
│  Agent 工具链  │ 打招呼 / 回复   │ JD+简历 智能出题 │    喂数据智能整理      │
│  匹配分析/改写  │ 追问 / 差距诊断  │ 17 类题库/STAR  │   粘贴/上传→归纳入库   │
│  逐条对比/轨迹  │ 舔狗式/避雷清单  │ 参考要点/存计划  │   分块检索可溯源       │
├───────────────┴───────────────┴───────────────┴──────────────────────┤
│              ⑤ 后台管理 · 面试复盘 · 数据洞察（SQLite 持久化）            │
│   求职记录台账 · 简历版本 · 话术 · 面试计划 · 复盘反哺 · 缺陷追踪 · 仪表盘   │
└──────────────────────────────────────────────────────────────────────┘
```

- 🤖 **Agent 化简历优化**：5 工具编排（parse_jd / parse_resume / match_analysis / rewrite+assemble / self_check），前端展示完整思考轨迹；匹配分析加权打分（0-100）、命中/缺失清单、逐条改写对比（原文→优化后→理由）
- 💬 **沟通中心（HR 换位思考）**：四大能力，话术全部真人化、可直接复制发送
  - **打招呼语**：简洁专业 / 亮点冲击 / 诚恳真诚 / **热情示好（舔狗式）** / 提问互动 5 种风格，附 HR 视角洞察与「最反感的 5 种开场」避雷清单
  - **HR 回复应对**：7 类场景（要简历 / 问到岗时间 / 问薪资 / 约面试 / 质疑学历年限 / 说你没经验 / 婉拒），**先解读 HR 真实意图**，再给专业型 / 诚恳型 / 热情型 3 种语气
  - **已读不回追问**：3 轮递进（轻量提醒 → 带新信息 → 体面收尾），每轮标注建议时机与策略，发完第 3 轮就停
  - **差距诊断**：区分「简历没写好（可包装）」与「能力真缺（硬伤）」，输出 30 天提升计划与 HR 判定
- 💬 **打招呼语生成（旧）**：基于 JD × 简历交集要点 + 最强亮点句，生成 简洁版 / 亮点版 / 诚恳版 3 种风格，一键复制；历史记录入库可查可删
- 📚 **知识库问答**：文档按段落+标点分块（重叠窗口），中文 n-gram 滑动窗口检索 + 技术关键词加权打分，LLM 模式生成回答，规则模式返回可溯源片段
- 🧠 **知识库「喂数据」智能整理（v2.3.0）**：粘贴文字 / Ctrl+V 粘贴图片 / 上传 文字·图片·PDF·Word·Excel·PPT，自动 OCR/解析后由 AI 归纳出 **标题·摘要·要点·标签**，预览可编辑再一键入库；未配 LLM 时用规则引擎兜底（首句做标题、首段做摘要、技术词做标签）
- 🎯 **智能面试准备**：内置 17 类技术题库（含 RAG/Agent/FastAPI/向量库…）+ 别名映射 + 简历项目 STAR 深挖 + 开放题；LLM 模式生成更贴合 JD 的真实题目；每题附参考要点，可一键存入面试计划
- 🗄️ **后台管理**：求职记录台账（状态流转：投递→面试→Offer→入职）、简历版本管理、打招呼历史、面试计划、仪表盘统计，全部 SQLite 持久化
- 📎 **上传识别**：图片（RapidOCR 离线中文 OCR）/ PDF / Word（docx）/ Excel（xlsx·xls）/ PPT（pptx）/ txt 上传识别；输入框 **Ctrl+V 粘贴截图**，点击优化/打招呼语/面试时自动 OCR 后执行
- 💾 **简历持久化**：JD 与简历自动存入浏览器 localStorage，简历没变动就一直是这一份，换公司只需改 JD
- 🛡️ **真实原则**：不虚构经历、不编造数据，缺数字只做占位提示
- 💻 **双模式**：OpenAI 兼容 LLM 或内置规则引擎，无 Key 可离线演示

## 快速开始

> ⚠️ 图片 OCR（RapidOCR）依赖 `pyclipper`，该包在 Python 3.13 无预编译 wheel，建议使用 **Python 3.10-3.12**。

```bash
# 1.（推荐）创建 Python 3.10 venv
python3.10 -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate

# 2. 安装依赖
pip install -r requirements.txt

# 3.（可选）配置 LLM，不配置则自动使用规则引擎
cp .env.example .env   # 填入 LLM_API_KEY

# 4. 启动
python -m uvicorn app.main:app --port 8000

# 5. 打开 http://127.0.0.1:8000
```

> VSCode 用户：直接打开项目根目录，F5 即可启动（已配置 `.vscode/launch.json`）。

## 项目结构

```
resume-optimizer-agent/
├── app/
│   ├── main.py            # FastAPI 入口（v2.5.0：约 40+ 接口 + 静态页）
│   ├── config.py          # .env 配置
│   ├── llm.py             # OpenAI 兼容 Chat Completions 客户端（JSON 模式）
│   ├── schemas.py         # Pydantic 数据模型
│   ├── agent.py           # Agent 编排循环（工具 + 轨迹）
│   ├── db.py              # SQLite 数据层（15 张表：上述 10 张 + delivery_profile / delivery_sessions /
│   │                      #   delivery_jobs / delivery_log / delivery_settings）
│   ├── chat_coach.py      # 沟通策略引擎：打招呼 5 风格 / HR 回复 7 场景 / 追问 3 轮 / 差距诊断
│   ├── insight.py         # 数据洞察：解析存档 / 缺陷追踪 / 项目推荐 / 竞争力（数据反哺闭环）
│   ├── review.py          # 面试复盘：提问抽取 / 弱点识别 / 简历反哺 / 与历史缺陷库交叉
│   ├── interview.py       # 面试准备（17 类技术题库 + 别名映射 + STAR 深挖）
│   ├── kb.py              # 知识库（分块 / n-gram 检索 / 加权打分 / 问答 / 智能整理归纳）
│   ├── record.py          # 记录中心归纳引擎：文本 → 公司/岗位/类型/进度/摘要/要点/标签（LLM 优先 + 规则兜底）
│   ├── delivery.py        # 智能投递引擎：简历画像 / 岗位匹配（LLM+规则）/ 定向策略 / 防拦截安全控制器 / 投递活动
│   ├── delivery_runner.py # 浏览器连接器 CLI（login/search/apply）：mock 演示 + live 真实驱动（Playwright 手动扫码）
│   ├── doc_parse.py       # 文档识别：图片 OCR / PDF / Word / Excel / PPT / txt（本地离线）
│   ├── tools/
│   │   └── rule_engine.py # 规则引擎：关键词库 / 解析 / 匹配 / 改写 / 打招呼语模板
│   └── static/index.html  # 前端 SPA（10 页导航 + 全局输入区 + 记录中心默认主页 + 记一笔浮层 + 智能投递页）
├── examples/              # 示例 JD/简历 + make_test_files.py + e2e_check / e2e_chat / e2e_insight / e2e_kb / e2e_record / e2e_delivery（端到端验证）
├── data/agent.db          # SQLite 数据文件（自动创建）
├── requirements.txt
└── .env.example
```

## API

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/api/optimize` | `{jd, resume}` → 匹配分析 + 优化简历 + 执行轨迹 |
| POST | `/api/greeting` | `{jd, resume}` → 3 种风格打招呼语 + 命中关键词 + 最强亮点 |
| POST | `/api/extract` | multipart `file`（图片/PDF/docx/xlsx/xls/pptx/txt）→ 本地识别文本 + 识别方式 |
| GET | `/api/health` | 运行模式检测（版本 / 模块 / LLM 状态） |
| **沟通策略** | | |
| POST | `/api/chat/hello` | `{jd, resume}` → 5 种风格打招呼语 + HR 洞察 + 避雷清单 |
| POST | `/api/chat/reply` | `{jd, resume, scenario, hr_message}` → HR 意图解读 + 3 种语气话术 |
| POST | `/api/chat/followup` | `{jd, resume, round_no(1-3)}` → 追问话术 + 时机与策略 |
| POST | `/api/chat/diagnose` | `{jd, resume}` → 硬伤 / 可包装项 / 30 天计划 / HR 判定 |
| POST | `/api/chat/save` | 保存话术到后台历史 |
| GET | `/api/chat/scripts` | 话术历史列表（可按 kind 过滤） |
| DELETE | `/api/chat/scripts/{id}` | 删除话术 |
| **数据洞察** | | |
| POST | `/api/optimize` | **自动保存**解析快照（meta.parse_run_id） |
| GET / DELETE | `/api/parse/runs[/{id}]` | 解析历史列表 / 单条 / 删除 |
| POST | `/api/insight/defects` | 简历缺陷追踪（聚合历史 missing） |
| POST | `/api/insight/projects/recommend` | 按 JD 推荐项目 + 改写建议 + 补做项目 |
| GET | `/api/insight/competitiveness` | 竞争力评估（分数趋势 + 缺陷 + 项目 + 面试复盘） |
| GET / POST / PUT / DELETE | `/api/projects[/{id}]` | 项目库 CRUD（按 starred 排序） |
| **面试复盘** | | |
| POST | `/api/review/analyze` | 复盘分析（输入：面试记录文本 + 公司岗位） |
| POST | `/api/review/upload` | 上传面试记录（图片/PDF/Word/Excel/PPT）→ 识别 → 分析 |
| POST | `/api/review/save` | 保存复盘到历史 |
| GET / DELETE | `/api/reviews[/{id}]` | 复盘历史 |
| **面试准备** | | |
| POST | `/api/interview/prepare` | `{jd, resume}` → 面试题目列表（技术基础/项目深挖/开放） |
| POST | `/api/interviews/save` | 保存面试计划（含题目） |
| GET | `/api/interviews` | 面试计划列表 |
| DELETE | `/api/interviews/{id}` | 删除面试计划 |
| **知识库** | | |
| POST | `/api/kb/ingest` | **喂数据智能整理**：multipart `raw` + `files[]`（可多个）→ 识别+归纳标题/摘要/要点/标签，返回预览（不落库） |
| POST | `/api/kb/add` | 新增文档（multipart：title/content/tags/file） |
| GET | `/api/kb/list` | 文档列表 |
| DELETE | `/api/kb/{id}` | 删除文档 |
| POST | `/api/kb/ask` | `{question}` → 回答 + 可溯源片段 |
| **记录中心** | | |
| POST | `/api/record/add` | **随手记**：multipart `raw` + `kind`（可选）+ `files[]`（可多个）→ 识别（OCR/解析）+ 归纳公司/岗位/类型/进度/摘要/要点/标签，返回并落库 |
| GET | `/api/records` | 记录列表（可按 `kind` / `status` 筛选，时间倒序，points 已反序列化为数组） |
| DELETE | `/api/records/{id}` | 删除记录 |
| **智能投递** | | |
| GET / POST | `/api/delivery/profile` | 读取 / 保存「我的简历画像」（岗位匹配与定向策略的基准，需 ≥20 字） |
| GET | `/api/delivery/strategy` | 基于简历画像 + 知识库/系统上下文，生成定向投递策略（建议平台·检索关键词·薪资预期·黑名单） |
| GET | `/api/delivery/sessions` | 各平台登录会话状态（Boss直聘/猎聘/智联，含默认占位） |
| POST | `/api/delivery/connect` | 连接平台：`live=false` 直接标记就绪（mock）；`live=true` 启动浏览器手动扫码（回写会话状态） |
| POST | `/api/delivery/search` | `platform` + `keyword` + `city` → 检索岗位 → LLM/规则匹配打分 → 落库 → 返回匹配结果 |
| GET | `/api/delivery/jobs` | 岗位列表（可按 `platform` / `status` 筛选，按匹配分倒序） |
| POST | `/api/delivery/approve` | 批准岗位进入投递队列（可 `auto_threshold` 批量自动批准） |
| POST | `/api/delivery/skip` | 批量跳过指定岗位（不投递） |
| POST | `/api/delivery/start` | 启动投递活动：对 approved 岗位按安全控制器拟人化投递（mock 模拟 / live 真实驱动） |
| POST | `/api/delivery/stop` | 停止进行中的投递活动 |
| GET | `/api/delivery/status` | 活动运行状态（前端轮询） |
| GET | `/api/delivery/logs` | 投递审计日志（防拦截诊断 + 透明可追溯） |
| GET / POST | `/api/delivery/settings` | 读取 / 修改防拦截安全配置（min_match_score / delay_min / delay_max / break_every / business_hours_only） |
| **后台管理** | | |
| GET/POST | `/api/jobs` | 求职记录列表 / 新增 |
| GET/PUT/DELETE | `/api/jobs/{id}` | 求职记录 详情 / 更新（含状态流转）/ 删除 |
| GET/POST | `/api/resumes` | 简历版本列表 / 新增（可激活） |
| GET/PUT/DELETE | `/api/resumes/{id}` | 简历版本 详情 / 更新 / 删除 |
| POST | `/api/greetings/save` | 保存打招呼语历史 |
| GET | `/api/greetings/history` | 打招呼历史列表 |
| DELETE | `/api/greetings/{id}` | 删除打招呼历史 |
| GET | `/api/dashboard` | 仪表盘统计 |
| GET | `/` | Web 界面 |

## 学习要点（面向 AI Agent 开发）

1. **工具抽象**：每个工具输入/输出用 Pydantic 模型约束，LLM 与规则引擎实现同一接口，可互相替换
2. **LLM 优先 + 规则兜底**：`try LLM → 捕获失败 → 回退规则`，保证可用性
3. **JSON 模式约束输出**：`response_format={"type":"json_object"}` + 提示词中给出精确字段
4. **轨迹可观测**：编排器记录每步的 thought/action/result，前端可视化——这是 Agent 应用与普通脚本的核心区别
5. **能力复用**：打招呼语直接复用 解析JD/解析简历/匹配分析 三个工具；面试准备复用 JD/简历解析 + 题库/STAR 深挖，每个工具都是可拼装的能力单元
6. **轻量 RAG**：段落分块 + 中文 n-gram 滑动窗口检索 + 技术词加权，不依赖外部向量库即可实现可溯源问答
7. **本地持久化**：零依赖 `sqlite3` 短连接模式，5 张业务表支撑后台管理，无需数据库服务
8. **文档识别即新工具**：图片 OCR / PDF / Word / Excel / PPT 解析作为独立 `doc_parse` 能力接入，多模态输入与主链路解耦
9. **真实原则**：Agent 只重构表达、对齐关键词、提示补量化，不虚构事实——这是简历工具必须守住的底线
10. **换位思考式 Prompt**：沟通模块让模型扮演「顶尖 HR」而非候选人，并要求先输出「HR 这句话的真实意图」再生成话术。把任务拆成「意图理解 → 策略选择 → 话术生成」三步，比直接索要话术的质量高一个档次
11. **真人感是可以工程化的**：中英文自动加空格、亮点句截断到 22 字、单条话术锁 60-120 字、省略号后不跟标点——这些细节加起来才是「像人写的」而不是「像 AI 生成的」
12. **「喂数据自动整理归纳」= 结构化 JSON 生成 + 规则兜底**：把杂乱文本丢给 LLM 要 `{title, summary, points, tags}` 结构化结果，未配 LLM 时用「首句做标题 / 首段做摘要 / 句号切要点 / 技术词做标签」确定性兜底，两套实现同一接口——这正是「LLM 优先、规则兜底」在非问答场景的又一落地

## 升级方向

- 接入 LangGraph 做真正的图编排（条件分支、人工确认节点）
- 用向量库（如 chromadb）替换 n-gram 检索，支持语义相似度召回
- 扫描版多页 PDF 的「先 OCR 再组装」流水线（当前 PDF 仅提取文本层）
- 接入 TextIn 等云解析增强版面还原能力（表格/多栏简历）
- 多版本 A/B 对比，输出 2-3 版差异化简历
- 打招呼语接入求职平台自动化发送（配合 auto-resume-submitter 技能）
- 面试模拟对话模式：AI 扮演面试官逐题追问并评分
